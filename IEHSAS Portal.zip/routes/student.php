<?php
/**
 * This code is wirtten and 
 * copyright by TechCodeX Team
 * http://www.techcodex.net
 */
Route::get('dashboard','StudentHome@index')->name('student.dashboard');
Route::get('logout','StudentLogin@logout')->name('student.logout');
Route::get('notifications','StudentsPortal@notifications')->name('student.notification');
Route::get('/courses','StudentsPortal@RegisterCourses')->name('student.registerCourses');
Route::get('/exam_result/{id}','StudentsPortal@examResult')->name('student.examResult');
Route::get('/profile','StudentsPortal@profile')->name('student.profile');
Route::get('/feedback/{id}','BatchFeedbacks@create')->name('batchFeedback.create');
Route::post('/feedback','BatchFeedbacks@store')->name('batchFeedback.store');

//batch assessment route
Route::get('/batch/assessment/{batch_id}/{student_id}','StudentBatchAssessments@showStudent')->name('student.batchAssessment');

//quiz routes
Route::get('/quiz/show/{id}','Quizes@show')->name('quiz.show');

//student studentQuiz routes
Route::get('/quiz/create/{id}','StudentQuizzes@create')->name('studentQuiz.create');
Route::post('/quiz/store','StudentQuizzes@store')->name('studentQuiz.store');

//student quiz results route
Route::get('/quiz_result/index/{id}','QuizResults@index')->name('quizResult.index');
//course documents
Route::get('/course/documents/{id}','DocumentTypes@showCourseTypes')->name('student.course.type');

//student teacher chat
Route::get('/chat/batch/{id}','StudentChat@index')->name('student.chat');

//random feedback 
Route::get('/batch_random_feedback/create/{id}','StudentBatchRandomFeedbacks@create')->name('random.create');
Route::post('/batch_random_feedback/store/{id}','StudentBatchRandomFeedbacks@store')->name('random.store');

//complain Form
Route::get('/complain/create','Complains@create')->name('complain.create');
Route::post('complain/store','Complains@store')->name('complain.store');