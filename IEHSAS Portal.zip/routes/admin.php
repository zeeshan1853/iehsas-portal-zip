<?php
/**
 * This code is wirtten and 
 * copyright by TechCodeX Team
 * http://www.techcodex.net
 */
/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Auth::routes();


//Home Controller
Route::get('/home', 'HomeController@index')->name('home');

//Setting route
Route::get('settings/index','Settings@index')->name('setting.index');
Route::post('settings/save','Settings@update')->name('setting.update');

//Users Routes
Route::get('/users/add_user','Users@create')->name('user.add_user');
Route::post('/users/save_user','Users@store')->name('user.save_user');
Route::get('/users/users_list','Users@index')->name('user.user_list');
Route::get('/users/make_admin/{id}','Users@make_admin')->name('user.make_admin');
Route::get('users/remove_admin/{id}','Users@remove_admin')->name('user.remove_admin');
Route::get('users/delete_user/{id}','Users@destroy')->name('user.delete_user');
Route::get('users/edit_profile/{id}','Users@edit')->name('user.edit_profile');
Route::post('users/update/{id}','Users@update')->name('user.update_profile');
Route::get('/password/change','Users@changePassword')->name('user.changePassword');
Route::post('/password/update','Users@updatePassword')->name('user.updatePassword');
Route::get('/user/activate/{id}','Users@activate')->name('user.activate');
Route::get('/user/deactive/{id}','Users@deactive')->name('user.deactive');
//Teacher Routes

Route::get('/teachers/create','Teachers@create')->name('teacher.create');
Route::post('teachers/save_teacher','Teachers@store')->name('teacher.save_teacher');
Route::get('teachers/teachers_list','Teachers@index')->name('teacher.teachers_list');
Route::get('teachers/delete_teacher/{id}','Teachers@destroy')->name('teacher.delete_teacher');
Route::get('teachers/edit_teacher/{id}','Teachers@edit')->name('teacher.edit_teacher');
Route::post('teachers/update_teacher/{id}','Teachers@update')->name('teacher.update_teacher');
Route::get('/teachers/get/ajax','Teachers@getTeachersAjax')->name('teacher.getTeachersAjax');
Route::get('/teacher/deactive/{id}','Teachers@deactive')->name('teacher.deactive');
Route::get('/teacher/active/{id}','Teachers@active')->name('teacher.active');
//courses route

Route::get('courses/add_course','Courses@create')->name('course.add_course');
Route::post('courses/store_course','Courses@store')->name('course.save_course');
Route::get('courses/courses_list','Courses@index')->name('course.courses_list');
Route::get('courses/delete_course/{id}','Courses@destroy')->name('course.delete_course');
Route::get('courses/edit_course/{id}','Courses@edit')->name('course.edit_course');
Route::post('courses/update_course/{id}','Courses@update')->name('course.update_course');
Route::get('courses/course_by_id/{id}','Courses@show_courses_by_id')->name('course.course_by_id');
Route::post('/courses/store/ajax','Courses@storeAjax')->name('course.storeAjax');

Route::get('course/document/types/{id}','Courses@documentTypes')->name('course.documentTypes');
Route::get('course/document/types/ajax/{id}','Courses@documentTypesAjax')->name('course.documentTypesAjax');

//testing api
Route::get('api/courses/','Courses@courses')->name('course.get_courses_ajax');

//Batches route

//testing api
Route::post('/api/batches','Batches@getBatchesAjax')->name('batch.get_batch_ajax');
Route::post('/api/get-batches-list','Batches@batchesList')->name('batch.batchList');

Route::get('batches/add_batch','Batches@create')->name('batch.add_batch');
Route::post('batches/store_batch','Batches@store')->name('batch.store_batch');
Route::get('batches/batches_list','Batches@index')->name('batch.batches_list');
Route::get('batches/batch_delete/{id}','Batches@destroy')->name('batch.delete_batch');
Route::get('batches/edit_batch/{id}','Batches@edit')->name('batch.edit_batch');
Route::post('batches/update_batch/{id}','Batches@update')->name('batch.update_batch');
Route::post('batches/get_batches','Batches@get_batches')->name('batch.get_batch');
Route::post('get_active_batches','Batches@get_active_batches')->name('batch.get_active_batch');
Route::post('/batches/store/ajax','Batches@storeAjax')->name('batch.storeAjax');
Route::post('/batches/branch_batches','Batches@getBranchBatches')->name('batch.get_branch_batches');
Route::get('/batches/print','Batches@print')->name('batch.print');
Route::get('/batch/delete/ajax/{id}','Batches@destroyAjax')->name('batch.deleteAjax');
Route::get('/batch/batch_students/{id}','Batches@BatchStudents')->name('batch.getBatchStudents');
Route::get('/batch/print/batch_students','Batches@printBatchStudents')->name('batch.printBatchStudents');
Route::get('/batches/result/{id}','Batches@result')->name('batch.result');


//students Route

//testing api students of batch
Route::post('/api/students','Students@batchStudentsAjax')->name('student.batch_student_ajax');
Route::post('/api/students/find','Students@index')->name('student.find');

Route::get('students/add_student','Students@create')->name('student.add_student');
Route::post('students/save_student','Students@store')->name('student.save_student');
Route::get('/students/batch_students/{id}','Students@batch_students')->name('student.batch_students');
Route::get('/students/student_instalments/{student_id}/{batch_id}','Students@instalments')->name('student.student_instalments');
Route::post('/students/get_batch_student','Students@get_batch_student')->name('student.get_batch_student');
Route::post('/student/show','Students@show')->name('student.show');
Route::get('/student/enrol','Students@enrollStudentToCourse')->name('student.enroll');
Route::get('/student/edit/{id}','Students@edit')->name('student.edit');
Route::post('student/update/{id}','Students@update')->name('student.update');
Route::get('/student/print/{id}','Students@print')->name('student.print');

Route::post('/student/store/ajax','Students@storeAjax')->name('student.storeAjax');
Route::get('/student/list','Students@studentList')->name('student.studentList');
Route::post('/student/batch_instalments','Students@studentBatchInstalments')->name('student.batchInstalments');
Route::get('/student/deactive/{id}','Students@deactive')->name('student.deactive');
Route::get('/student/active/{id}','Students@active')->name('student.active');
/*--------------------------------------------------------------------------------------------------- */
//instalments Route

Route::get('instalments/add_instalment','Instalments@create')->name('instalment.add');
Route::post('instalments/save_instalment','Instalments@store')->name('instalment.save');
Route::get('/instalments/print_and_save','Instalments@printInstalment')->name('instalment.print');
Route::post('instalment/add/ajax','Instalments@storeAjax')->name('instalment.storeAjax');
Route::get('instalment/delete/{id}','Instalments@destroy')->name('instalment.destroy');
Route::get('instalment/edit/{id}','Instalments@edit')->name('instalment.edit');
Route::post('instalment/update/{id}','Instalments@update')->name('instalment.update');
//print saved Instalment
Route::get('instalment/print/{id}','Instalments@print')->name('instalment.printInstalment');
//student instalment History
Route::get('/instalment/student/history/{id}','Instalments@studentInstalmentHistory')->name('instalment.studentHistory');
//print instalment challan form
Route::get('/instalment/challa_form/','Instalments@createInstalmentChallan')->name('instalment.challanForm');
/*---------------------------------------------------------------------------------------------------*/

/* ------------------------------------------------------------------------------------------------*/
//Education Route

Route::get('/education/create','Educations@create')->name('education.create');
Route::post('/education/store','Educations@store')->name('education.store');
Route::get('/education/index','Educations@index')->name('education.index');
Route::get('/education/get/ajax','Educations@getEducationsAjax')->name('education.getEducationsAjax');
/*----------------------------------------------------------------------------------------------- */
//branches route

Route::get('/barnch/create','Branches@create')->name('branch.create');
Route::post('branch/store','Branches@store')->name('branch.store');
Route::get('/branch','Branches@index')->name('branch.index');
Route::get('branch/edit/{id}','Branches@edit')->name('branch.edit');
Route::post('branch/update/{id}','Branches@update')->name('branch.update');

//payments route

//payment Api
Route::get('/api/payments','Payments@getPaymentsAjax')->name('payment.ajax');
Route::get('/payment/create','Payments@create')->name('payment.create');
Route::post('/payment/store','Payments@store')->name('payment.store');
Route::get('/payment','Payments@index')->name('payment.index');
Route::get('/payment/edit/{id}','Payments@edit')->name('payment.edit');
Route::post('/payment/update/{id}','Payments@update')->name('payment.update');
Route::get('/payment/deactive/{id}','Payments@deactive')->name('payment.deactive');
Route::get('/payment/active/{id}','Payments@active')->name('payment.active');

//Student Courses Enrolment
Route::post('/api/students/enrolment','StudentCourses@store')->name('student.enrolment');
Route::get('/student/course/edit/{id}','StudentCourses@edit')->name('studentCourses.edit');
Route::post('/student/course/update/{id}','StudentCourses@update')->name('studentCourses.update');
Route::get('student/feedback/google/{id}','StudentCourses@googleFeedback')->name('studentCourse.googleFeedback');
Route::get('student/feedback/facebook/{id}','StudentCourses@facebookFeedback')->name('studentCourse.facebookFeedback');
Route::get('/student/course/delete/{id}','StudentCourses@destroy')->name('studentCourse.delete');

//Cash Account
Route::get('cash/edit','CashAccounts@edit')->name('cash_account.edit');
Route::post('cash/upadte/{id}','CashAccounts@update')->name('cash_account.update');

//Cash Book
Route::get('/cash/book/','CashBooks@index')->name('cash_book.index');
Route::get('/cash/daily_book/','CashBooks@dailyBook')->name('cash_book.daily');

//branch payment
Route::get('/branch_recoveries/create','BranchRecoveries@create')->name('branchRecovery.create');
Route::post('/branch_recoveries/store','BranchRecoveries@store')->name('branchRecovery.store');
Route::get('/branch_recoveries/index','BranchRecoveries@index')->name('branchRecovery.index');
Route::get('/branch_recoveries/delete/{id}','BranchRecoveries@destroy')->name('branchRecovery.delete');

/* -------------------------------------------------- Expenses Route-------------------------------------- */

Route::get('expense/create','Expenses@create')->name('expense.create');
Route::post('/expense/store','Expenses@store')->name('expense.store');
Route::get('/expense/index','Expenses@index')->name('expense.index');
Route::post('/expense/get_list_ajax','Expenses@getExpenseList')->name('expense.getExpenseList');
Route::get('/expense/print','Expenses@print')->name('expense.print');
Route::get('/expense/delete/ajax/{id}','Expenses@destroyAjax')->name('expense.deleteAjax');

/* -------------------------------------------------- End Expenses Route-------------------------------------- */


/* ------------------------------------------------- Expense Type Routes ----------------------------------- */
Route::post('expensetype/store/ajax','ExpenseTypes@store')->name('expenseType.store');

/* ------------------------------------------------- End Expense Type Routes ----------------------------------- */

/* ------------------------------------------------- Expense Name Routes ----------------------------------- */
Route::post('expensename/store/ajax','ExpenseNames@store')->name('expenseName.store');
Route::post('exepnsename/show/ajax','ExpenseNames@showAjax')->name('expenseName.showAjax');

/* ------------------------------------------------- End Expense Name Routes ----------------------------------- */

/*----------------------------------------------Hostel Recoveries Routes ------------------------------------- */
Route::get('/hostel/create','HostelRecoveries@create')->name('hostelRecovery.create');
Route::post('/hostel/store','HostelRecoveries@store')->name('hostelRecovery.store');
Route::post('/hostel/store/ajax','HostelRecoveries@storeAjax')->name('hostelRecovery.storeAjax');
Route::get('/hostel/print','HostelRecoveries@print')->name('hostelRecovery.print');


/*-------------------------------------------- Mails Route ------------------------------------------------- */
Route::get('/emails/create','Emails@create')->name('email.create');
Route::post('/email/store','Emails@store')->name('email.store');
Route::get('email/index','Emails@index')->name('email.index');
Route::get('email/delete/{id}','Emails@destroy')->name('email.delete');
Route::get('email/edit/{id}','Emails@edit')->name('email.edit');
Route::post('email/update/{id}','Emails@update')->name('email.update');

/*---------------------------------------- Document Route ------------------------------------------------- */
Route::get('/document/create','Documents@create')->name('document.create');
Route::post('/document/store','Documents@store')->name('document.store');
Route::get('/document/index','Documents@index')->name('document.index');
Route::get('/document/delete/{id}','Documents@destroy')->name('document.delete');
Route::get('document/edit/{id}','Documents@edit')->name('document.edit');
Route::post('/document/update/{id}','Documents@update')->name('document.update');


/*------------------------------------- Bank Route ---------------------------------------------- */
Route::get('/banks/create','Banks@create')->name('bank.create');
Route::post('/banks/store','Banks@store')->name('bank.store');
Route::get('/banks/index','Banks@index')->name('bank.index');
Route::get('/bank/activate/{id}','Banks@activate')->name('bank.activate');
Route::get('bank/edit/{id}','Banks@edit')->name('bank.edit');
Route::post('bank/update/{id}','Banks@update')->name('bank.update');
Route::get('bank/delete/{id}','Banks@destroy')->name('bank.delete');

/*-------------------------------------Bank Book Routes ------------------------------------------ */
Route::get('/bank_books/index','BankBooks@index')->name('bankBook.index');
Route::get('/bank_book/show/{id}','BankBooks@show')->name('bankBook.show');

/*-----------------------------------Transfers---------------------------------------- */
Route::get('/transfer/cash_to_bank/','CashAccounts@createTrasnfer')->name('cashAccount.createTransfer');
Route::post('/transfer/cash_to_bank/','CashAccounts@storeTrasnfer')->name('cashAccount.storeTransfer');
Route::get('/transfer/bank_to_cash/','Banks@createTransfer')->name('book.createTransfer');
Route::post('/transfer/bank_to_cash/','Banks@storeTransfer')->name('book.storeTransfer');

/*-------------------------------- Chalan Forms ------------------------------- */
Route::post('/api/enrolment/save','ChallanForms@saveEnrolStudent')->name('enrolemnt.save');
Route::get('/challan_form/print','ChallanForms@printChallanForm')->name('challan.print');
Route::post('/instalment/challan_form/','ChallanForms@instalmentChallanForm')->name('challan.instalment');
Route::get('/challan_form/empty','ChallanForms@EmptyChallanForm')->name('challan.empty');

/*-------------------------------- Incoming Mails Route -----------------------------*/
Route::get('/incoming_mail/create','IncomingMails@create')->name('mail.create');
Route::post('/incoming_mail/store/','IncomingMails@store')->name('mail.store');
Route::get('/incoming_mail/index','IncomingMails@index')->name('mail.index');
Route::get('/incoming_mail/delete/{id}','IncomingMails@destroy')->name('mail.delete');
Route::get('/incoming_mail/edit/{id}','IncomingMails@edit')->name('mail.edit');
Route::post('/incoming_mail/update/{id}','IncomingMails@update')->name('mail.update');

/*------------------------------ Outgoing Mails Route ----------------------------------- */
Route::post('/outgoing_mail/store/ajax','OutgoingMails@storeAjax')->name('outgoingMail.storeAjax');
Route::get('/outgoing/index','OutgoingMails@index')->name('outgoingMail.index');
Route::get('/outgoing/create','OutgoingMails@create')->name('outgoingMail.create');
Route::post('outgoing/store','OutgoingMails@store')->name('outgoingMail.store');
Route::get('/outgoing/delete/{id}','OutgoingMails@destroy')->name('outgoingMail.delete');
Route::get('/outgoing/edit/{id}','OutgoingMails@edit')->name('outgoingMail.edit');
Route::post('/outgoing/update/{id}','OutgoingMails@update')->name('outgoingMail.update');

/*-------------------------------- Certificates Route --------------------------------- */
Route::get('/certificate/create','Certificates@create')->name('certificate.create');
Route::post('certificate/store','Certificates@store')->name('certificate.store');
Route::get('/certificate/index','Certificates@index')->name('certificate.index');
Route::get('/certificate/delete/{id}','Certificates@destroy')->name('certificate.delete');
Route::get('/certificate/edit/{id}','Certificates@edit')->name('certificate.edit');
Route::post('/certificate/update/{id}','Certificates@update')->name('certificate.update');
Route::get('/certificate/stacked','Certificates@stacked')->name('certificate.stacked');
Route::get('/certificate/dispacthed','Certificates@dispatched')->name('certificate.dispatched');

/*------------------------------------ Certificate types ----------------------------- */
Route::get('/certificate-type/create','CertificateTypes@create')->name('certificateType.create');
Route::post('/certificate-type/store','CertificateTypes@store')->name('certificateType.store');
Route::get('/certificate-type/index','CertificateTypes@index')->name('certificateType.index');
Route::get('/certificate-type/delete/{id}','CertificateTypes@destroy')->name('certificateType.delete');
Route::get('/certificate-type/edit/{id}','CertificateTypes@edit')->name('certificateType.edit');
Route::post('/certificate-type/update/{id}','CertificateTypes@update')->name('certificateType.update');

/*------------------------------------ Outgoing Certificates --------------------------- */
Route::post('/outgoing-certificates/store/ajax','OutgoingCertificates@storeAjax')->name('outgoingCertificate.storeAjax');
Route::get('/outgoing-certificate/delete/{id}','OutgoingCertificates@destroy')->name('outgoingCertificate.delete');
Route::get('/outgoing-certificate/show/{id}','OutgoingCertificates@show')->name('outgoingCertificate.show');
Route::get('/outgoing-certificate/edit/{id}','OutgoingCertificates@edit')->name('outgoingCertificate.edit');
Route::post('outgoing-certificate/update/{id}','OutgoingCertificates@update')->name('outgoingCertificate.update');


/*---------------------------------- Enquiries Route ---------------------------------- */
Route::get('/enquiries/create','Enquiries@create')->name('enquiry.create');
Route::post('/enquiries/store','Enquiries@store')->name('enquiry.store');
Route::get('/enquries/index','Enquiries@index')->name('enquiry.index');
Route::get('/enquiries/delete/{id}','Enquiries@destroy')->name('enquiry.delete');
Route::get('/enquiries/edit/{id}','Enquiries@edit')->name('enquiry.edit');
Route::post('/enquiries/update/{id}','Enquiries@update')->name('enquiry.update');

/* ------------------------------- Course Advertisement --------------------------------- */
Route::get('/advertisement/create','Advertisements@create')->name('advertisement.create');
Route::post('/advertisement/store','Advertisements@store')->name('advertisement.store');
Route::get('/advertisement/index','Advertisements@index')->name('advertisement.index');
Route::get('/advertisement/delete/{id}','Advertisements@destroy')->name('advertisement.delete');
Route::get('/advertisement/edit/{id}','Advertisements@edit')->name('advertisement.edit');
Route::post('/advertisement/update/{id}','Advertisements@update')->name('advertisement.update');
Route::get('/advertisement/custom','Advertisements@createCustomAdvertisement')->name('advertisement.create_custom');
Route::post('/advertisement/custom','Advertisements@sendCustomAdvertisement')->name('advertisement.sendCustomAdvertisement');


/* ----------------------------------- Location Controller --------------------------- */
Route::get('/location/country','Locations@getCountries')->name('location.countries');
Route::post('/location/state','Locations@getStates')->name('location.states');
Route::post('/location/city','Locations@getCities')->name('location.cities');

/* --------------------------------- Result Announcment ------------------------------- */
Route::get('student/result/create/{id}','StudentResults@create')->name('studentResult.create');
Route::post('student/result/store','StudentResults@store')->name('studentResult.store');
Route::get('/student/result/show/{id}','StudentResults@show')->name('studentResult.show');
Route::get('student/result/edit/{id}','StudentResults@edit')->name('studentResult.edit');
Route::post('student/result/update/{id}','StudentResults@update')->name('studentResult.update');

/* --------------------------------- Course Exam Dates ------------------------------ */
Route::get('/exam_dates/course_exam_date/{id}','CourseExamDates@courseExamDates')->name('ExamDate.courseExamDate');
Route::get('/exam_date/send_admission/{id}','CourseExamDates@sendAdmission')->name('ExamDate.sendAdmission');

/*---------------------------------- batch feedbacks -------------------------------- */
Route::get('batch_feedback/show/{id}','BatchFeedbacks@show')->name('batchFeedback.show');

/*--------------------------------- Student Attendance ----------------------------- */
Route::post('student/attendance','StudentAttendances@showStudentAttendance')->name('attendance.showStudentAttendance');
Route::post('/batch/attendance','StudentAttendances@showBatchAttendance')->name('attendance.showBatchAttendance');

/*----------------------------- Course Documents --------------------------------- */
Route::get('/document/type/create','DocumentTypes@create')->name('documentType.create');
Route::post('document/type/store','DocumentTypes@store')->name('documentType.store');
Route::get('document/type/index','DocumentTypes@index')->name('documentType.index');
Route::get('document/type/edit/{id}','DocumentTypes@edit')->name('documentType.edit');
Route::post('document/type/update/{id}','DocumentTypes@update')->name('documentType.update');
Route::get('document/type/delete/{id}','DocumentTypes@destroy')->name('documentType.delete');
Route::get('document/type/show/{id}','DocumentTypes@show')->name('documentType.show');

/*-------------------------- Batch Daily Activity Router ------------------------- */
Route::get('batch/daily_activity/{id}','BatchDailyActivities@showBatchDailyActivity')->name('activity.showBatchActivity');\

/* ----------------------------Batch Assessment Report ------------------------------- */
Route::get('/batch_assessment/{id}','BatchAssessments@showBatchAssessments')->name('assessment.showBatchAssessments');


/* --------------------------- Student Batch assessment Report Routes ---------------------- */
Route::get('student_batch_assessment/{batch_id}/{student_id}','StudentBatchAssessments@showAdmin')->name('studentAssessment.showAdmin');
Route::get('student_batch_assessment/print','StudentBatchAssessments@print')->name('studentAssessment.print');

/** -------------------------------------------- Agents Route ----------------------------------------- */
Route::get('/agents/create','Agents@create')->name('agent.create');
Route::post('/agents/store','Agents@store')->name('agent.store');
Route::get('/agents/index','Agents@index')->name('agent.index');
Route::get('/agents/delete/{id}','Agents@destroy')->name('agent.delete');
Route::get('/agents/edit/{id}','Agents@edit')->name('agent.edit');
Route::post('/agents/update/{id}','Agents@update')->name('agent.update');
Route::get('agents/show/{id}','Agents@show')->name('agent.show');
Route::get('/agents/index_ajax/','Agents@indexAjax')->name('agent.indexAjax');

/* -----------------------------------------------------Agent payments Router ------------------------------ */
Route::get('/agent_payments/create','AgentPayments@create')->name('agentPayment.create');
Route::post('/agent_payment/store','AgentPayments@store')->name('agentPayment.store');
Route::get('/agent_payment/index','AgentPayments@index')->name('agentPayment.index');
Route::get('/agent_payment/delete/{id}','AgentPayments@destroy')->name('agentPayment.delete');

/* ----------------------------------------------- Quiz results ---------------------------------- */
Route::get('student/quiz_result/show/{id}','Quizes@showBatchQuizzes')->name('quiz.showBatchQuizzes');
Route::post('student/quiz/index/','QuizResults@adminIndex')->name('quizResult.adminIndex');
Route::get('student/quiz_results/print','QuizResults@print')->name('quizResult.print');

/* ----------------------------------------- Student Type Route ---------------------------- */
Route::get('/student_type/index/ajax','StudentTypes@indexAjax')->name('studentType.indexAjax');
Route::get('/student_type/create','StudentTypes@create')->name('studentType.create');
Route::post('/student_type/store','StudentTypes@store')->name('studentType.store');
Route::get('student_type/index','StudentTypes@index')->name('studentType.index');
Route::get('/student_type/edit/{id}','StudentTypes@edit')->name('studentType.edit');
Route::post('/student_type/update/{id}','StudentTypes@update')->name('studentType.update');
Route::get('student_type/deactive/{id}','StudentTypes@deactive')->name('studentType.deactive');
Route::get('student_type/active/{id}','StudentTypes@active')->name('studentType.active');

/** -------------------------------------- Batch Random Feedback Routes--------------------- */
Route::post('/batch_random_feedback/store','BatchRandomFeedbacks@store')->name('batchRandomFeedback.store');
Route::get('/batch_random_feedback/show/{id}','BatchRandomFeedbacks@show')->name('batchRandomFeedback.show');

/** ------------------------------------- Student Batch Random Feedbac */
Route::get('/student/feedback/index/{id}','StudentBatchRandomFeedbacks@index')->name('studentRandomFeedback.index');
Route::get('/student/random/feedback/show/{id}','StudentBatchRandomFeedbacks@show')->name('studentRandomFeedback.show');
Route::get('/student/random/feedback/print','StudentBatchRandomFeedbacks@print')->name('studentRandomFeedback.print');

/** ------------------------------------- Complain Routes ------------------------------*/
Route::get('complain/index','Complains@index')->name('complain.index');
Route::get('complain/in_progress/{id}','Complains@inProgress')->name('complain.inProgress');
Route::post('complain/solved/','Complains@solved')->name('complain.solved');
Route::post('complain/list','Complains@list')->name('complain.list');
Route::get('/complain/print','Complains@print')->name('complain.print');
Route::get('complain/print_list','Complains@printList')->name('complain.printList');

/** ------------------------------------ Roles Routes -------------------------------- */
Route::get('role/create','Roles@create')->name('role.create');
Route::post('role/store','Roles@store')->name('role.store');
Route::get('/role/index','Roles@index')->name('role.index');
Route::get('/role/delete/{id}','Roles@destroy')->name('role.delete');
Route::get('/roles/index/ajax','Roles@getRoles')->name('role.getRoles');

/*************** Permission routes ************************************ */
Route::get('/permission/index/ajax','PermissionRoles@getPermissions')->name('permissionRole.getPermission');
/** --------------------------- Role Permissions Route ----------------------------------- */
Route::get('role_permission/create','PermissionRoles@create')->name('permissionRole.create');
Route::get('/sub_permission/show/{id}/{role_id}','PermissionRoles@getSubPermissions')->name('permissionRole.show');
Route::post('role_permission/store','PermissionRoles@store')->name('permissionRole.store');
Route::get('role_permission/get_user_permissions','PermissionRoles@getUserPermissions')->name('permissionRole.getUserPermissions');
Route::get('/role_permission/role_permissions/{id}','PermissionRoles@getRolePermissions')->name('permissionRole.getRolePermissions');
Route::get('/role_permission/revoke/sub_permission/{id}','PermissionRoles@revokeSubPermission')->name('subPermission.revoke');
Route::get('/role_permission/revoke/permission/{id}','PermissionRoles@revokePermission')->name('permission.revoke');