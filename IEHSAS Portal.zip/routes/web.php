<?php
/**
 * This code is wirtten and 
 * copyright by TechCodeX Team
 * http://www.techcodex.net
 */

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/* --------------------------------------------- Testing Routes ------------------------------------------- */

use App\Mail\Testmail;
use App\Notifications\StudentInstalment;
use App\Notifications\StudentRegister;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Request;

Route::get('test',function() {
    return view('test',['page_title'=>'Test','page_heading'=>'test','active'=>'test','current'=>'test']);
 });
 Route::post('/custom/endpoint/auth',function (Request $request){ 
    $pusher = new Pusher\Pusher(env('PUSHER_APP_KEY'),env('PUSHER_APP_SECRET'), env('PUSHER_APP_ID')); 
    return $pusher->socket_auth($request->request->get('channel_name'),$request->request->get('socket_id')); 
 });
Route::get('test1',function() {
   return view('test1',['page_title'=>'Test','page_heading'=>'test','active'=>'test','current'=>'test']);
});
Route::get('challan',function() {
    return view('challan_forms.print');
});
Route::post('upload/test', function(){
    $file = request()->image;
    $file->move('files/', $file->getClientOriginalName());
    return response()->json(['title' => request()->title, 'image' => $file->getClientOriginalName()]);
});
Route::get('mail',function() {
    Mail::send(new Testmail());
});



Route::get('email',function() {
    return view('emails.teacher_registration');
});


/* --------------------------------------------------------------------------------------------------------*/
//Admin Login Route
Route::get('/admin/login', function () {
    return view('auth.login');
});


//student login
Route::get('student/login','StudentLogin@login')->name('student.login');
Route::post('login','StudentLogin@VerifyLogin')->name('student.verifyLogin');

//teacher login
Route::get('/teacher/login','TeacherLogin@login')->name('teacher.login');
Route::post('/teacher/login','TeacherLogin@verifyLogin')->name('teacher.verifyLogin');

?>