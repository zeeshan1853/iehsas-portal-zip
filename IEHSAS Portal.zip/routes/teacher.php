<?php

/**
 * This code is wirtten and 
 * copyright by TechCodeX Team
 * http://www.techcodex.net
 */


Route::get('/dashboard','TeacherHome@dashboard')->name('teacher.dashboard');
Route::get('/logout','TeachersPortal@logout')->name('teacher.logout');
Route::get('profile','TeachersPortal@profile')->name('teacher.profile');
Route::get('profile/edit','TeachersPortal@editProfile')->name('teacher.editProfile');
Route::post('profile/update','TeachersPortal@updateProfile')->name('teacher.updateProfile');
Route::get('change_password','TeachersPortal@changePassword')->name('teacher.changePassword');
Route::post('/update_password','TeachersPortal@updatePassword')->name('teacher.updatePassword');
Route::get('/batch/active_batch','TeachersPortal@activeBatch')->name('teacher.activeBatch');
Route::get('/attendance/create/{id}','StudentAttendances@create')->name('teacher.createStudentAttendance');
Route::post('/attendance/store','StudentAttendances@store')->name('teacher.storeStudentAttendance');
Route::get('/old_batch','TeachersPortal@oldBatches')->name('teacher.oldBatches');
Route::get('/batch/student_list/{id}','TeachersPortal@batchStudents')->name('teacher.batchStudentList');
/* --------------------------------- Batch Daily Activity Routes -------------------------------- */
Route::get('batch/daily_activity/create/{id}','BatchDailyActivities@create')->name('batchDailyActivity.create');
Route::post('/batch/daily_activity/store','BatchDailyActivities@store')->name('batchDailyActivity.store');

/* ---------------------------------- Batch Assessments  Report ---------------------------- */
Route::get('batch/assessment/index/{id}','BatchAssessments@index')->name('assessment.index');
Route::post('batch/assessment/store','BatchAssessments@store')->name('assessment.store');
Route::get('batch/assessment/delete/{id}','BatchAssessments@destroy')->name('assessment.delete');
Route::get('/batch_assessment/show/{id}','BatchAssessments@show')->name('assessment.show');

/* --------------------------------- Student batch assessment Report ---------------------------------- */
Route::get('/student_batch_assessment_report/create/{batch_id}/{assessment_id}','StudentBatchAssessments@create')->name('batchAssessment.create');
Route::post('student_batch_assessment/save/{id}','StudentBatchAssessments@store')->name('batchAssessment.store');
Route::get('/student_batch_assessment/edit/{id}','StudentBatchAssessments@edit')->name('batchAssessment.edit');
Route::post('/student_batch_assessment/update/{id}','StudentBatchAssessments@update')->name('batchAssessment.update');

/*---------------------------------------- Quiz Routes --------------------------------------------- */
Route::get('/quiz/create/{id}','Quizes@create')->name('quiz.create');
Route::post('/quiz/store','Quizes@store')->name('quiz.store');
Route::get('/quiz/index/{id}','Quizes@index')->name('quiz.index');
Route::get('/quiz/delete/{id}','Quizes@destroy')->name('quiz.delete');

/* ----------------------------------- Student Quiz ---------------------------------- */
Route::get('/student_quiz/index/{id}','StudentQuizzes@index')->name('studentQuiz.index');

/* ---------------------------------- Student Quiz Result ----------------------------------------- */
Route::get('/quiz_result/create/{id}','QuizResults@create')->name('quizResult.create');
Route::post('/quiz_result/store','QuizResults@store')->name('quizResult.store');
Route::get('/quiz_result/show/{id}','QuizResults@show')->name('quizResult.show');
Route::get('/quiz_result/edit/{id}','QuizResults@edit')->name('quizResult.edit');
Route::post('/quiz_result/update/{id}','QuizResults@update')->name('quizResult.update');

//chat route
Route::get('/chat/batch/{id}','TeacherChat@index')->name('teacher.chat');
Route::get('/chat/batch_students/{id}','TeacherChat@getBatchStudents')->name('teacher.getBatchStudents');
Route::get('/chat/conversation/{id}','TeacherChat@getMessages')->name('teacher.chat.getMessages');
Route::post('/chat/teacher/send','TeacherChat@sendMessage')->name('teacher.chat.sendMessage');
?>