@if(Auth::user()->admin == 1)
<div class="main-menu menu-fixed menu-light menu-accordion    menu-shadow " data-scroll-to-active="true" data-img="{{asset('images/backgrounds/02.jpg')}}">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item mr-auto"><a class="navbar-brand" href="{{ route('home') }}"><img class="brand-logo" alt="Company Logo" src="{{asset(Auth::user()->branch->setting->logo)}}"/>
            <li class="nav-item d-md-none"><a class="nav-link close-navbar"><i class="ft-x"></i></a></li>
        </ul>
    </div>
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <center><span class="sidebar-loader"></span></center>
            <li class="nav-item @if($active == "home") open @endif"><a href="{{route('home')}}"><i class="ft-home"></i><span class="menu-title" data-i18n="">Dashboard</span></a></li>
            
            <li class="nav-item @if($active == "cash") open @endif"><a href="#"><i class="ft-briefcase"></i><span class="menu-title" data-i18n="">Cash</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "cash_account") active @endif"><a class="menu-item" href="{{ route('cash_account.edit',['id'=>Auth::user()->branch->cashAccount->id]) }}">Cash Account</a>
                    </li>
                    <li class="@if($current == "cash_book") active @endif"><a class="menu-item" href="{{route('cash_book.index')}}">Cash Book</a>
                    </li>
                    <li class="@if($current == "cash_book_daily") active @endif"><a class="menu-item" href="{{route('cash_book.daily')}}" title="Daily Cash Book">Daily Cash book</a>
                    </li>
                    <li class="@if($current == "branch_recoveries") active @endif"><a class="menu-item" href="{{route('branchRecovery.create')}}" title="Add Branch Recoveries">Add Branch Recoveries</a>
                    </li>
                    <li class="@if($current == "branch.index") active @endif"><a class="menu-item" href="{{route('branchRecovery.index')}}" title="Show Branch Recoveries">Show Branch Recoveries</a>
                    </li>
                    <li class="@if($current == "cash_to_bank") active @endif"><a class="menu-item" href="{{route('cashAccount.createTransfer')}}" title="Cash To Bank Transfer">Cash To Bank Trasnfer</a>
                    </li>
                    <li class="@if($current == "bank_to_cash") active @endif"><a class="menu-item" href="{{route('book.createTransfer')}}" title="Bank to Cash Transfer">Bank to Cash Transfer</a>
                    </li>
                </ul>
            </li>
            <li class="nav-item @if($active == "banks") open @endif"><a href="#"><i class="ft-zap"></i><span class="menu-title" data-i18n="">Banks</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create_bank") active @endif"><a class="menu-item" href="{{route('bank.create')}}">Add Bank</a>
                    </li>
                    <li class="@if($current == "index_bank") active @endif"><a class="menu-item" href="{{route('bank.index')}}">Show All Banks</a>
                    </li>
                    <li class="@if($current == "bank_books") active @endif"><a class="menu-item" href="{{ route('bankBook.index') }}">Show Bank Book</a>
                    </li>

                </ul>
            </li>
            <li class="nav-item @if($active == "users") open @endif"><a href="#"><i class="ft-users"></i><span class="menu-title" data-i18n="">Users</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create") active @endif"><a class="menu-item" href="{{ route('user.add_user') }}">Add User</a>
                    </li>
                    <li class="@if($current == "index") active @endif"><a class="menu-item" href="{{route('user.user_list')}}">Show All Users</a>
                    </li>

                </ul>
            </li>
            <li class="nav-item @if($active == "roles") open @endif"><a href="#"><i class="ft-layers"></i><span class="menu-title" data-i18n="">Role Mangement</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create_role") active @endif"><a class="menu-item" href="{{ route('role.create') }}">Add New Role</a>
                    </li>
                    <li class="@if($current == "index_role") active @endif"><a class="menu-item" href="{{route('role.index')}}">Show All Roles</a>
                    </li>
                    <li class="@if($current == "permission_role") active @endif"><a class="menu-item" href="{{route('permissionRole.create')}}">Role Permissions</a>
                    </li>
                </ul>
            </li>

            <li class="nav-item @if($active == "agents") open @endif" ><a href="#"><i class="ft-umbrella"></i><span class="menu-title" data-i18n="">Agents</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create_agent") active @endif"><a class="menu-item" href="{{route('agent.create')}}">Add Agent</a>
                    </li>
                    <li class="@if($current == "index_agent") active @endif"><a class="menu-item" href="{{route('agent.index')}}">Show All Agents</a>
                    </li>
                    <ul class="menu-content">
                        <li class="has-sub is-shown">
                            <a href="#" class="menu-item @if($active == 'agent_payments') @endif">
                                Payments <span class="ft-arrow-down float-right"></span>
                            </a>
                            <ul class="menu-content">
                                <li class="@if($current == "create_agent_payment") active @endif"><a class="menu-item" href="{{route('agentPayment.create')}}">Add Payment</a></li>
                                <li class="@if($current == "index_agent_payment") active @endif"><a class="menu-item" href="{{route('agentPayment.index')}}">Show all Payments</a></li>
                            </ul>
                        </li>
                    </ul>
                </ul>
            </li>

            <li class="nav-item @if($active == "branches") open @endif" ><a href="#"><i class="ft-monitor"></i><span class="menu-title" data-i18n="">Branches</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create_branch") active @endif"><a class="menu-item" href="{{route('branch.create')}}">Add Branch</a>
                    </li>
                    <li class="@if($current == "index_branch") active @endif"><a class="menu-item" href="{{route('branch.index')}}">Show All Branches</a>
                    </li>
                </ul>
            </li>
            
            <li class="nav-item @if($active == "teachers") open @endif"><a href="#"><i class="ft-user-check"></i><span class="menu-title" data-i18n="">Teachers</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create_teacher") active @endif"><a class="menu-item" href="{{route('teacher.create')}}">Add Teacher</a>
                    </li>
                    <li class="@if($current == "index_teacher") active @endif"><a class="menu-item" href="{{route('teacher.teachers_list')}}">Show All Teachers</a>
                    </li>

                </ul>
            </li>
            <li class="nav-item @if($active == "courses") open @endif"><a href="#"><i class="ft-book"></i><span class="menu-title" data-i18n="">Courses</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create_course") active @endif"><a class="menu-item" href="{{route('course.add_course')}}">Add Course</a>
                    </li>
                    <li class="@if($current == "index_course") active @endif"><a class="menu-item" href="{{route('course.courses_list')}}">Show All Courses</a>
                    </li>

                </ul>
            </li>
            <li class="nav-item @if($active == "batches") open @endif"><a href="#"><i class="ft-clipboard"></i><span class="menu-title" data-i18n="">Batches</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create_batch") active @endif"><a class="menu-item" href="{{route('batch.add_batch')}}">Add New Batch</a>
                    </li>
                    <li class="@if($current == "index_batch") active @endif"><a class="menu-item" href="{{route('batch.batches_list')}}">Show All Batches</a>
                    </li>

                </ul>
            </li>
            <li class="nav-item @if($active == "students") open @endif"><a href="#"><i class="ft-life-buoy"></i><span class="menu-title" data-i18n="">Students</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create_student") active @endif"><a class="menu-item" href="{{route('student.add_student')}}">Add New Student</a>
                    </li>
                    <li class="@if($current == "enrol") active @endif"><a class="menu-item" href="{{route('student.enroll')}}">Enroll Student</a>
                    </li>
                    <li class="@if($current == "student_list") active @endif"><a class="menu-item" href="{{route('student.studentList')}}">Student List</a>
                    </li>
                    <li class="nav-item @if($active == "student_types") open @endif"><a href="#"><span class="menu-title" data-i18n="">Types</span><span class="ft-arrow-down float-right mt-1"></span></a>
                        <ul class="menu-content">
                            <li class="@if($current == "student_type_create") active @endif"><a class="menu-item" href="{{route('studentType.create')}}">Add New Type</a></li>
                            <li class="@if($current == "student_type_index") active @endif"><a class="menu-item" href="{{ route('studentType.index') }}">Show all Types</a></li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li class="nav-item @if($active == "instalments") open @endif"><a href="#"><i class="ft-activity"></i><span class="menu-title" data-i18n="">Instalments</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create_instalment") active @endif"><a class="menu-item" href="{{route('instalment.add')}}">Add New Instalment</a></li>
                    <li class="@if($current == "create_hostel") active @endif"><a class="menu-item" href="{{ route('hostelRecovery.create') }}">Add Hostel Recovery</a></li>
                    <li class="@if($current == "create_challan") active @endif"><a class="menu-item" href="{{ route('instalment.challanForm') }}">Print Challan Form</a></li>
                </ul>
            </li>
            <li class="nav-item @if($active == "educations") open @endif"><a href="#"><i class="ft-star"></i><span class="menu-title" data-i18n="">Education</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create_education") active @endif"><a class="menu-item" href="{{route('education.create')}}">Add New Degree</a></li>
                    <li class="@if($current == "index_education") active @endif"><a class="menu-item" href="{{route('education.index')}}">Show All Degress</a></li>
                </ul>
            </li>
            <li class="nav-item @if($active == "payments") open @endif"><a href="#"><i class="ft-scissors"></i><span class="menu-title" data-i18n="">Payments</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create_payment") active @endif"><a class="menu-item" href="{{route('payment.create')}}">Add New Payment</a></li>
                    <li class="@if($current == "index_payment") active @endif"><a class="menu-item" href="{{route('payment.index')}}">Show All Payments</a></li>
                </ul>
            </li>
            <li class="nav-item @if($active == "expenses") open @endif"><a href="#"><i class="ft-shopping-cart"></i><span class="menu-title" data-i18n="">Expenses</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create_expense") active @endif"><a class="menu-item" href="{{route('expense.create')}}">Add New Expense</a></li>
                    <li class="@if($current == "index_expense") active @endif"><a class="menu-item" href="{{route('expense.index')}}">Show All Expenses</a></li>
                    <li class="@if($current == "") active @endif"><a class="menu-item" href="{{route('payment.index')}}">Daily Expenses</a></li>
                </ul>
            </li>
            <li class="nav-item @if($active == "emails") open @endif"><a href="#"><i class="ft-mail"></i><span class="menu-title" data-i18n="">Emails</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create_email") active @endif"><a class="menu-item" href="{{route('email.create')}}">Add New Email</a></li>
                    <li class="@if($current == "index_email") active @endif"><a class="menu-item" href="{{route('email.index')}}">Show All Emails</a></li>
                </ul>
            </li>
            <li class="nav-item @if($active == "documents") open @endif"><a href="#"><i class="ft-upload"></i><span class="menu-title" data-i18n="">Documents</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create_document_type") active @endif"><a class="menu-item" href="{{route('documentType.create')}}">Add Document Type</a></li>
                    <li class="@if($current == "index_document_type") active @endif"><a class="menu-item" href="{{route('documentType.index')}}">Show Document Type</a></li>
                    <li class="@if($current == "create_document") active @endif"><a class="menu-item" href="{{route('document.create')}}">Add New Document</a></li>
                    <li class="@if($current == "index_document") active @endif"><a class="menu-item" href="{{route('document.index')}}">Show All Documents</a></li>
                </ul>
            </li>
            <li class="nav-item @if($active == "mails") open @endif"><a href="#"><i class="ft-inbox"></i><span class="menu-title" data-i18n="">Mails</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="has-sub is-shown">
                        <a href="#" class="menu-item">
                            Incoming Mail <span class="ft-arrow-down float-right"></span>
                        </a>
                        <ul class="menu-content">
                            <li class="@if($current == "create_mail") active @endif"><a class="menu-item" href="{{route('mail.create')}}">Add New Mail</a></li>
                            <li class="@if($current == "index_mail") active @endif"><a class="menu-item" href="{{route('mail.index')}}">Show Stacked Mails</a></li>
                        </ul>
                    </li>
                    <li class="has-sub is-shown">
                        <a href="#" class="menu-item">
                            Outgoing Mail <span class="ft-arrow-down float-right"></span>
                        </a>
                        <ul class="menu-content">
                            <li class="@if($current == "create_outgoing") active @endif"><a class="menu-item" href="{{route('outgoingMail.create')}}">Add New Mail</a></li>
                            <li class="@if($current == "index_outgoing") active @endif"><a class="menu-item" href="{{route('outgoingMail.index')}}" title="Show Disptach Mail">Show Dispatch Mails</a></li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li class="nav-item @if($active == "certificates") open @endif"><a href="#"><i class="ft-award"></i><span class="menu-title" data-i18n="">Certificates</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create_certificate") active @endif"><a class="menu-item" href="{{route('certificate.create')}}">Add New Certificate</a></li>
                    <li class="@if($current == "index_certificate") active @endif"><a class="menu-item" href="{{route('certificate.index')}}">Show All Certificates</a></li>
                    <li class="@if($current == "stacked_certificate") active @endif"><a class="menu-item" href="{{route('certificate.stacked')}}">Stacked Certificates</a></li>
                    <li class="@if($current == "dispatch_certificate") active @endif"><a class="menu-item" href="{{route('certificate.dispatched')}}">Dispatch Certificates</a></li>
                </ul>
                <ul class="menu-content">
                    <li class="has-sub is-shown">
                        <a href="#" class="menu-item">
                            Certificate Types <span class="ft-arrow-down float-right"></span>
                        </a>
                        <ul class="menu-content">
                            <li class="@if($current == "create_certificate_type") active @endif"><a class="menu-item" href="{{route('certificateType.create')}}">Add New Type</a></li>
                            <li class="@if($current == "index_certificate_type") active @endif"><a class="menu-item" href="{{route('certificateType.index')}}">Show Certificate Types</a></li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li class="nav-item @if($active == "enquiries") open @endif"><a href="#"><i class="ft-phone-call"></i><span class="menu-title" data-i18n="">Enquiries</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create_enquiry") active @endif"><a class="menu-item" href="{{route('enquiry.create')}}">Add New Enquiry</a></li>
                    <li class="@if($current == "index_enquiry") active @endif"><a class="menu-item" href="{{route('enquiry.index')}}">Show All Enquiries</a></li>
                </ul>
            </li>
            <li class="nav-item @if($active == "advertisements") open @endif"><a href="#"><i class="ft-message-circle"></i><span class="menu-title" data-i18n="">Advertisements</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "create_advertisement") active @endif"><a class="menu-item" href="{{route('advertisement.create')}}" title="Add New Advertisement">Add New Advertisement</a></li>
                    <li class="@if($current == "index_advertisement") active @endif"><a class="menu-item" href="{{route('advertisement.index')}}" title="Show All Advertisement">Show All Advertisement</a></li>
                    <li class="@if($current == "create_custom_advertisement") active @endif"><a class="menu-item" href="{{route('advertisement.create_custom')}}">Send Custom Mail</a></li>
                </ul>
            </li>
            <li class="nav-item @if($active == "complains") open @endif"><a href="#"><i class="ft-alert-triangle"></i><span class="menu-title" data-i18n="">Complains</span><span class="ft-arrow-down float-right mt-1"></span></a>
                <ul class="menu-content">
                    <li class="@if($current == "complain_index") active @endif"><a class="menu-item" href="{{route('complain.index')}}" title="Add New Advertisement">Complains List</a></li>
                </ul>
            </li>
            
            <li class="nav-item @if($active == "settings") open @endif"><a href="{{route('setting.index')}}"><i class="ft-settings"></i><span class="menu-title" data-i18n="">Settings</span></a></li>
        </ul>
    </div>
    <div class="navigation-background"></div>
</div>

@else 

<div class="main-menu menu-fixed menu-light menu-accordion    menu-shadow " data-scroll-to-active="true" data-img="{{asset('images/backgrounds/02.jpg')}}">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item mr-auto"><a class="navbar-brand" href="{{ route('home') }}"><img class="brand-logo" alt="Company Logo" src="{{asset(Auth::user()->branch->setting->logo)}}"/>
            <li class="nav-item d-md-none"><a class="nav-link close-navbar"><i class="ft-x"></i></a></li>
        </ul>
    </div>
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <center><span class="sidebar-loader"></span></center>
            <li class="nav-item @if($active == "home") open @endif"><a href="{{route('home')}}"><i class="ft-home"></i><span class="menu-title" data-i18n="">Dashboard</span></a></li>
            
            
            <li class="nav-item @if($active == "settings") open @endif"><a href="{{route('setting.index')}}"><i class="ft-settings"></i><span class="menu-title" data-i18n="">Settings</span></a></li>
        </ul>
    </div>
    <div class="navigation-background"></div>
</div>

@endif