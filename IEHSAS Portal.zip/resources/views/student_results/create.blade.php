@extends('app')

@section('header-styles')

@stop

@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('studentResult.store')}}" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="course_exam_id" value="{{ $course_exam_id }}">
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> Student Exam Result</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Total Marks</label>
                                    <div class="col-md-9">
                                        <input type="text" autofocus id="totalMarks" value="{{old('total_marks')}}" class="form-control  {{$errors->has('total_marks') ? 'border-danger' : ''}}" placeholder="Enter Exam Total Marks" name="total_marks">
                                    </div>
                                    @if($errors->has('total_marks'))
                                    <span class="offset-md-4 text-danger">{{ $errors->first('total_marks') }}</span>
                                    @endif
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Obtain Marks</label>
                                    <div class="col-md-9">
                                        <input type="text" autofocus id="obtainMarks" value="{{old('obtain_marks')}}" class="form-control  {{$errors->has('obtain_marks') ? 'border-danger' : ''}}" placeholder="Enter Obtain Marks" name="obtain_marks">
                                        <span class="text-danger">
                                            @if($errors->has('obtain_marks'))
                                                {{$errors->first('obtain_marks')}}
                                            @endif
                                        </span>
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Result Status</label>
                                    <div class="col-md-9">
                                        <select class="form-control select2  {{$errors->has('result') ? 'border-danger' : ''}}" name="result" id="result">
                                            <option value="">--Select Result Status--</option>
                                            <option value="1">Pass</option>
                                            <option value="2">Fail</option>
                                        </select>
                                        <span class="text-danger">
                                            @if($errors->has('result'))
                                                {{$errors->first('result')}}
                                            @endif
                                        </span>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Result Attachment:</label>
                                    <div class="col-md-9">
                                        <input type="file" id="resultAttachment" class="form-control  date {{$errors->has('result_attachments') ? 'border-danger' : ''}}"  name="result_attachment">
                                        <span class="text-danger">
                                        @if($errors->has('result_attachment'))
                                                {{$errors->first('result_attachment')}}
                                            @endif
                                    </span>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Certificate</label>
                                    <div class="col-md-9">
                                        <input type="file" id="certificate" class="form-control date {{$errors->has('certificate') ? 'border-danger' : ''}}"  name="certificate">
                                        <span class="text-danger">
                                        @if($errors->has('certificate'))
                                                {{$errors->first('certificate')}}
                                            @endif
                                        </span>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-actions text-center">
                        <input type="submit" value="Store" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')

@stop

