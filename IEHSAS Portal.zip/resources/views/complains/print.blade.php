<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Complain Form Print</title>
    <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">
    <style>
        footer{
            position: fixed;
            bottom: 0;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <center><img src="{{ asset(Auth::user()->branch->setting->logo) }}" ></center>
        <hr>
        <center><h1>Complaint/ Suggestion Form</h1></center>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-bordered">
                    <tr>
                        <td>Delegate Name</td>
                        <td colspan="3" class="student"></td>
                    </tr>
                    <tr>
                        <td>Course</td>
                        <td class="course"></td>
                        <td>Date</td>
                        <td class="date"></td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="row mt-2">
            <div class="col-md-12">
                <center><label class="text-bold-700" style="font-size:20px;font-weight: bold;">Description of Complain / Suggestion</label></center>
                <textarea class="form-control" rows="20" id="complain"></textarea>
            </div>
        </div>

        <div class="row mt-2">
            <div class="col-md-12">
                <center><label class="text-bold-700" style="font-size:20px;font-weight: bold;">For Office Use Only </label></center>
                <textarea class="form-control" rows="20" id="remarks"></textarea>
            </div>
        </div>
        <footer>
            <h2>Signature:___________________</h2>
        </footer>
    </div>

</body>
</html>
<script>
    document.addEventListener("DOMContentLoaded",(e)=>{
        let complain = JSON.parse(localStorage.getItem("complain"));
        let student = document.querySelector(".student");
        let course = document.querySelector(".course");
        let created_at = document.querySelector(".date"); 
        let com = document.querySelector("#complain");
        let remarks = document.querySelector("#remarks");
        
        student.textContent = complain.student;
        course.textContent = complain.course;
        created_at.textContent = complain.created_at;
        com.textContent = complain.complain;
        remarks.textContent = complain.remarks;

        localStorage.removeItem("complain");
        window.print();
    });
</script>