@extends('app')

@section('header-styles')
<link href="{{asset('vendors/css/forms/selects/select2.min.css')}}" rel="stylesheet" type="text/css">
@stop

@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('certificateType.store')}}" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group">
                        <label for="course">Select Course:</label>
                        <select class="form-control" name="course_id" id="course_id">
                            <option value=""> -- Select Course --</option>
                            @foreach($courses as $course)
                                <option value="{{ $course->id }}">{{ $course->course_name }}</option>
                            @endforeach
                        </select>
                        @if($errors->has('course_id'))
                            <span class="text-danger">{{ $errors->first('course_id') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="name"> Name</label>
                        <input type="text" name="name" class="form-control" placeholder="Enter Certificate Name">
                        @if($errors->has('name'))
                            <span class="text-danger">{{ $errors->first('name') }}</span>
                        @endif
                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Add Certificate Type" id="btnAdd" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
<script src="{{asset('vendors/js/forms/select/select2.full.min.js')}}"></script>
<script>
    $(document).ready(function(e) {
        $("#course_id").select2();
    })
</script>
@stop

