@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="coursesData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Name</td>
                        <td data-column-id="contact_no">Contact No</td>
                        <td data-column-id="opening">Opening</td>
                        <td data-column-id="debit">Debit</td>
                        <td data-column-id="credit">Credit</td>
                        <td data-column-id="balance">Balance</td>
                        <td data-column-id="delete" data-sortable="false">Acions</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach($agents as $agent)
                        <tr>
                            <td>{{$i++}}</td>
                            <td>{{ $agent->name }}</td>
                            <td>{{ $agent->contact_no }}</td>
                            <td>{{ $agent->opening }}</td>
                            <td>{{ $agent->debit }}</td>
                            <td>{{ $agent->credit }}</td>
                            <td>{{ $agent->credit - $agent->debit }}</td>
                            <td>
                                <a href="{{ route('agent.delete',['id'=>$agent->id]) }}" style="color:red;" title="Delete Agent">
                                    <i class="ft-trash"></i>
                                </a>
                                <a href="{{ route('agent.edit',['id'=>$agent->id]) }}" style="margin-left:5px;" title="Edit Agent">
                                    <i class="ft-edit"></i>
                                </a>
                                <a href="{{ route('agent.show',['id'=>$agent->id]) }}" title="View Agent Ledger" style="color:green;margin-left:5px;">
                                    <span class="ft-eye"></span>
                                </a>
                            </td>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#coursesData").DataTable();
        })
    </script>
@stop