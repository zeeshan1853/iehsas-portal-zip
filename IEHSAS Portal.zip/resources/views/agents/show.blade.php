@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="coursesData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-colun-id="date">Date</td>
                        <td data-column-id="balance">Narration</td>
                        <td data-column-id="name">Debit</td>
                        <td data-column-id="paid_amount">Credit</td>
                        <td></td>
                        
                    </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>{{ $agent->opening }}</td>
                        </tr>
                    <?php
                    $i = 1;
                    $opening = $agent->opening;
                    ?>
                    @foreach($payments as $payment)
                        <tr>
                            <td>{{$i++}}</td>
                            <td>{{ $payment->created_at->toFormattedDateString() }}</td>
                            <td>{{ $payment->narration == "" ? "N/A" : $payment->narration }}</td>
                            <td>{{ $payment->debit }}</td>
                            <td>{{ $payment->credit }}</td>
                            @php $opening -= ($payment->credit - $payment->debit)  @endphp
                            <td>{{ $opening }}</td>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#coursesData").DataTable();
        })
    </script>
@stop