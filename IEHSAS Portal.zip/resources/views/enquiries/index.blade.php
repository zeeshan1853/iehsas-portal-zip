@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
    <style>
        .bor{
            border-bottom:1px solid #D3D3D3;
        }
    </style>
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="coursesData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="student_name">Student Name</td>
                        <td data-column-id="contact_no">Contact No</td>
                        <td data-column-id="email">Email</td>
                        <td data-column-id="education">Education</td>
                        <td data-column-id="course">Course</td>
                        <td data-column-id="date">Enquiry Date</td>
                        <td data-column-id="status">Status</td>
                        <td data-column-id="delete" data-sortable="false">Acions</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach($enquiries as $enquiry)
                        <tr>
                            <td>{{$i++}}</td>
                            <td>{{ $enquiry->student_name }}</td>
                            <td>{{ $enquiry->contact_no }}</td>
                            <td>{{ $enquiry->email == "" ? "N/A" : $enquiry->email }}</td>
                            <td>{{ $enquiry->education->name }}</td>
                            <td>{{ $enquiry->course->course_name }}</td>
                            <td>{{ $enquiry->created_at->toFormattedDateString() }}</td>
                            @if($enquiry->status == 0) 
                                <td><i class="badge badge-danger">Pending</i></td>
                            @else 
                                <td><i class="badge badge-success">Enrolled</i></td>
                            @endif
                            <td>
                                <a href="{{ route('enquiry.edit',['id'=>$enquiry->id]) }}" style="color:blue"><i class="ft-edit"></i></a>
                                <a href="{{ route('enquiry.delete',['id'=>$enquiry->id]) }}" title="Delete Enquiry" style="color:red;"><i class="ft-trash"></i></a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#coursesData").DataTable();
        });
    </script>
@stop