@extends('app')

@section('header-styles')
<link href="{{asset('vendors/css/forms/selects/select2.min.css')}}" rel="stylesheet" type="text/css">
@stop

@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('enquiry.update',['id'=>$enquiry->id])}}" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="branch_id" value="{{Auth::user()->branch->id}}">
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Student Name</label>
                                    <div class="col-md-9">
                                        <input type="text" id="studentName" autofocus @if(old('student_name') == '') value="{{ $enquiry->student_name }}" @else value="{{ old('student_name') }}" @endif class="form-control {{$errors->has('student_name') ? 'border-danger' : ''}}" placeholder="Enter Student Name" name="student_name">
                                        @if($errors->has('student_name'))
                                            <span class=" text-danger">{{ $errors->first('student_name') }}</span>
                                        @endif
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Course</label>
                                    <div class="col-md-9">
                                        <select class="form-control" name="course_id" id="course_id">
                                            <option> -- Select Course -- </option>
                                            @foreach($courses as $course)
                                            @if($course->id == $enquiry->course_id)
                                                <option value="{{ $course->id }}" selected>{{ $course->course_name }}</option>
                                            @else
                                                <option value="{{ $course->id }}">{{ $course->course_name }}</option>
                                            @endif
                                                
                                            @endforeach
                                        </select>
                                        @if($errors->has('course_id'))
                                            <span class=" text-danger">{{ $errors->first('course_id') }}</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Education</label>
                                    <div class="col-md-9">
                                        <select name="education_id" id="education_id" class="form-control select2"> 
                                            <option value="">-- Select Education --</option>
                                            @foreach($educations as $education)
                                            @if($education->id == $enquiry->education_id)
                                                <option value="{{ $education->id }}" selected>{{ $education->name }}</option>
                                            @else
                                            <option value="{{ $education->id }}">{{ $education->name }}</option>
                                            @endif
                                                
                                            @endforeach
                                        </select>
                                        @if($errors->has('education_id'))
                                            <span class="text-danger ">{{ $errors->first('education_id') }}</span>
                                        @endif
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput4">Email</label>
                                        <div class="col-md-9">
                                                <input type="email"  @if(old('email') == '') value="{{ $enquiry->email }}" @else value="{{ old('email') }}" @endif placeholder="Enter Student Email" class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}" name="email">
                                            @if($errors->has('email'))
                                                <span class="text-danger">{{$errors->first('email')}}</span>
                                            @endif
                                        </div>
    
                                    </div>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Contact No</label>
                                    <div class="col-md-9">
                                        <input type="text" id="contact_no" @if(old('contact_no') == '') value="{{ $enquiry->contact_no }}" @else value="{{ old('contact_no') }}" @endif placeholder="Enter Student Contact No" class="form-control {{$errors->has('contact_no') ? 'border-danger' : ''}}"  name="contact_no">
                                        @if($errors->has('contact_no'))
                                            <span class="text-danger contact_no">
                                                {{ $errors->first('contact_no') }}
                                            </span>
                                        @endif  
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Update" id="btnAdd" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/forms/select/select2.full.min.js')}}"></script>
    <script>
        
        var dueAmount = 0;
        $(document).ready(function (e) {
            $("#certificate_type_id").select2();
            $("#course_id").select2();
            $("#education_id").select2();
        });
    </script>

@stop

