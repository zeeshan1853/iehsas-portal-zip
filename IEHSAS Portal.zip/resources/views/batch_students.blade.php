@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
    <style>

    </style>
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered table-responsive text-center" id="studentsData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Name</td>
                        <td data-column-id="father_name">Father Name</td>
                        <td data-column-id="contact_no">Contact No</td>
                        <td data-column-id="admission_date">Admission Date</td>
                        <td data-column-id="paid_amount">Paid</td>
                        <td data-column-id="due_amount">Due</td>
                        <td data-column-id="course">Course</td>
                        <td>ID</td>
                        <td data-column-id="delete" data-sortable="false">Actions</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach($students as $student)
                        <tr>
                            <td>{{$i++}}</td>
                            <td><a href="{{route('student.student_instalments',['id'=>$student->id])}}">{{$student->student_name}}</a> </td>
                            <td>{{$student->father_name}}</td>
                            <td>{{$student->contact_no}}</td>
                            <td>{{$student->admission_date->toFormattedDateString()}}</td>
                            <td>{{$student->paid_amount}}</td>
                            <td>{{$student->due_amount}}</td>
                            <td>{{ $student->course->course_name }}</td>
                            @if($student->id_card != "")
                                <td>{{ $student->id_card }}</td>
                            @else
                                <td>N/A</td>
                            @endif
                            <td>
                                <a href="#" class="view" style="color:green;margin-left: 0px;" data-id="{{$student->id}}"><i class="ft-eye"></i></a>
                                <a href="#" class="" style="margin-left: 1px;"><i class="ft-edit"></i></a>
                                <a href="" style="color:#1ab7ea;margin-left: 1px;"><i class="ft-printer"></i></a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal for student Data--->
    <div class="modal" tabindex="-1" role="dialog" id="myModal">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content ">
                <div class="modal-header">
                    <center><h3 class="modal-title">Student Details</h3></center>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <a href="" class="linkStudentImage"><img src="" class="rounded-circle offset-md-4 studentImage" width="100" height="200"></a>
                    <hr>
                    <div>
                        <h4 class="pull-left offset-md-2">Email</h4>
                        <p class="offset-md-6"><b class="email"></b></p>
                    </div>
                    <div class="clearfix"></div>
                    <hr>
                    <hr>
                    <div>
                        <h4 class="pull-left offset-md-2">Date Of Birth</h4>
                        <p class="offset-md-6"><b class="dateOfBirth"></b> </p>
                    </div>
                    <div class="clearfix"></div>
                    <hr>
                    <div>
                        <h4 class="pull-left offset-md-2">Education</h4>
                        <p class="offset-md-6"><b class="education"></b> </p>
                    </div>
                    <div class="clearfix"></div>
                    <hr>
                    <div>
                        <h4 class="pull-left offset-md-2">How he find Us ?</h4>
                        <p class="offset-md-6"><b class="find"></b> </p>
                    </div>
                    <div class="clearfix"></div>
                    <hr>
                    <div>
                        <h4 class="pull-left offset-md-2">Emergency Contact No</h4>
                        <p class="offset-md-6"><b class="emergencyContactNo"></b> </p>
                    </div>
                    <div class="clearfix"></div>
                    <hr>
                    <hr>
                    <div>
                        <h4 class="pull-left offset-md-2">Address</h4>
                        <p class="offset-md-6"><b class="address"></b> </p>
                    </div>
                    <div class="clearfix"></div>
                    <hr>
                    <div>
                        <h4 class="pull-left offset-md-2">Exam Date</h4>
                        <p class="offset-md-6"><b class="examDate"></b> </p>
                    </div>
                    <div class="clearfix"></div>
                    <hr>

                    <div>
                        <h4 class="pull-left offset-md-2">ID Card</h4>
                        <img src="" alt="idCard" class="idCard1 pull-left offset-md-1 img-thumbnail">
                        <img src="" alt="idCard" class="idCard2 pull-left offset-md-1 img-thumbnail">
                    </div>
                    <div class="clearfix"></div>
                    <hr>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#studentsData").DataTable();
            $(".view").click(function (e) {
                e.preventDefault();
                var id = $(this).attr('data-id');
                var data = {
                    id:id,
                };
                $.ajax({
                    url:"{{route('student.show')}}",
                    data:data,
                    dataType:'JSON',
                    type:'POST',
                    complete:function (jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var student = result.student;

                                var src = '{{asset("/")}}'+student.student_image;
                                var idCardSrc = "{{asset('/')}}"+student.id_card_front;
                                var idCardSrc2 = "{{asset('/')}}"+student.id_card_back;
                                $(".studentImage").attr('src',src);
                                $(".linkStudentImage").attr('href',src);

                                $(".idCard1").attr('src',idCardSrc);
                                $(".idCard2").attr('src',idCardSrc2);

                                $(".email").html(student.email);
                                $(".dateOfBirth").html(student.date_of_birth);
                                $(".education").html(result.education);
                                $(".find").html(student.find);
                                $(".address").html(student.address);
                                $(".examDate").html(result.exam_date);
                                $(".emergencyContactNo").html(student.emergency);
                            }
                        }
                    }
                });
                $("#myModal").modal();
            })
        })
    </script>
@stop