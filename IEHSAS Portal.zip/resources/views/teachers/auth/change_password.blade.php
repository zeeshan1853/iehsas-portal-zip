@extends('layouts.app_teacher')

@section('styles')

@stop


@section('content')
<div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-content collpase show">
                    <div class="card-body">
                        <form class="form form-horizontal" method="POST" action="{{ route('teacher.updatePassword') }}">
                            {{ csrf_field() }}
                            <div class="form-body">
                                <h4 class="form-section"><i class="ft-user"></i> Update Password</h4>
                                <div class="form-group row">
                                    <label class="col-md-2 label-control" for="first_name">Old Password :</label>
                                    <div class="col-md-8">
                                        <div class="position-relative has-icon-left">
                                            <input type="password" id="old_password" class="form-control {{ $errors->has('old_password') ? 'is-invalid' : '' }}" placeholder="Enter Old Password" name="old_password">
                                            <div class="form-control-position">
                                                <i class="ft-lock"></i>
                                            </div>
                                        </div>
                                        @if($errors->has('old_password'))
                                        <span class="text-danger">
                                            {{ $errors->first('old_password') }}
                                        </span>
                                        @endif
                                        
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-2 label-control" for="new_password">New Password :</label>
                                    <div class="col-md-8">
                                        <div class="position-relative has-icon-left">
                                            <input type="password" id="new_password" class="form-control  {{ $errors->has('password') ? 'is-invalid' : '' }}" placeholder="Enter New Password" name="password">
                                            <div class="form-control-position">
                                                <i class="ft-lock"></i>
                                            </div>
                                        </div>
                                        @if($errors->has('password'))
                                        <span class="text-danger">
                                            {{ $errors->first('password') }}
                                        </span>
                                        @endif
                                        

                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-2 label-control" for="new_password">Confirm Password :</label>
                                    <div class="col-md-8">
                                        <div class="position-relative has-icon-left">
                                            <input type="password" id="confirm_password" class="form-control  {{ $errors->has('password_confirmation') ? 'is-invalid' : '' }}" placeholder="Retype Password" name="password_confirmation">
                                            <div class="form-control-position">
                                                <i class="ft-lock"></i>
                                            </div>
                                        </div>
                                        

                                    </div>
                                </div>
                            </div>
    
                            <div class="form-actions">
                                <center>
                                    <button type="submit" class="btn btn-primary">Update Password</button>
                                </center>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop


@section('scripts')

@stop