@extends('layouts.app_teacher')


@section('styles')

@stop

@section('content')
<section id="dom">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table class="table table-striped mt-5 text-center">
                        <thead class="bg-success bg-lighten-2 white">
                            <tr>
                                <th>Sr.No</td>
                                <th>Student Name</th>
                                <th>Total Marks</th>
                                <th>Obtain Marks</th>
                                <th>Remarks</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php $i = 1; @endphp
                            @if($reports->count() == 0)
                                <tr>
                                    <td colspan="3">No Result Found</td>
                                </tr>
                            @else
                                @foreach($reports as $report)
                                    <tr>
                                        <td>{{ $i++ }}</td>
                                        <td>{{ $report->student->student_name }} {{ $report->student->father_name }}</td>
                                        <td>{{ $report->batchAssessment->total_marks }}</td>
                                        <td>{{ $report->obtain_marks }}</td>
                                        <td>{{ $report->remarks == "" ? "N/A" : $report->remarks }}</td>
                                        <td>
                                            <a href="{{ route('batchAssessment.edit',['id'=>$report->id]) }}">
                                                <i class="ft-edit"></i>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach                                
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
@stop


@section('scripts')
@stop