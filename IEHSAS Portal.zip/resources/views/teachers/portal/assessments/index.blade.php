@extends('layouts.app_teacher')


@section('styles')

@stop

@section('content')
<section id="dom">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="float-right">
                        <a href="#" class="btn btn-primary round btn-min-width mr-1 mb-1" id="addAssessment">
                            <i class="fa fa-plus-circle"></i>&nbsp;
                            Add New Test
                        </a>
                    </div>
                    <table class="table table-striped mt-5 text-center">
                        <thead class="bg-success bg-lighten-2 white">
                            <tr>
                                <th>Sr.No</td>
                                <th>Test No</td>
                                <th>Total Marks</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody class="tbody">
                            @if(count($assessments) == 0)
                                <tr>
                                    <td colspan="4" class="text-center">No Result Found</td>
                                </tr>
                            @else
                                @php $i = 1; @endphp
                                @foreach($assessments as $assessment)
                                <tr>
                                    <td>{{ $i }}</td>
                                    <td>Test {{ $i++ }}</td>
                                    <td>{{ $assessment['total_marks'] }}</td>
                                    <td>
                                        <a href="{{ route('assessment.delete',['id'=>$assessment['id']]) }}">
                                            <i class="ft-trash" title="Delete Batch Assessment" style="color:red;margin-left:5px;"></i>
                                        </a>
                                        @if($assessment['report'] == 0)
                                            <a href="{{ route('batchAssessment.create',['batch_id'=>$assessment['batch_id'],'assessment_id'=>$assessment['id']]) }}">
                                                <i class="ft-bell" title="Upload Students Assessment Report"></i>
                                            </a>
                                        @else
                                            <a href="{{ route('assessment.show',['id'=>$assessment['id']]) }}" style="color:green;" title="Check Assessment Result">
                                                <i class="ft-eye"></i>
                                            </a>
                                        @endif
                                        
                                    </td>
                                </tr>
                                @endforeach
                            @endif
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="modal fade text-left" id="assessmentModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-cyan">
                <h4 class="modal-title white text-center" id="myModalLabel18"><i class="fa fa-plus"></i > Add New Batch Assessment</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="assessmentForm">
                    <input type="hidden" name="batch_id" value="{{ Route::input('id') }}">
                    <div class="form-group">
                        <label class="label-control">Total Marks:</label>
                        <input type="number" min="0" placeholder="Enter Test Total Marks" class="form-control" name="total_marks" id="totalMarks">
                        <span class="text-danger total_marks help-block"></span>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline-primary" id="save">Save changes</button>
            </div>
        </div>
    </div>
</div>
@stop


@section('scripts')
<script src="{{ asset('student-portal/app/js/scripts/modal/components-modal.min.js') }}"></script>
<script>
    $(document).ready((e) => {
        //adding assessment in storage
        $("#addAssessment").click((e) => {
            e.preventDefault();
            setTimeout(()=>{
                document.getElementById("totalMarks").focus();
            },500)
            $("#assessmentModal").modal();
            
        });
        $("#save").click(function(e) {
            var assessmentForm = $("#assessmentForm").serializeArray();
            $(".help-block").html("");
            var i = 0;
            assessmentForm.forEach((assessment)=>{
                if(assessment.value == "") {
                    i++;
                    $("."+assessment.name).html("This Field is Required");
                }
            });
            console.log(i);
            if(i > 0 ) {
                return;
            }
            $.ajax({
                url:"{{ route('assessment.store') }}",
                data:assessmentForm,
                dataType:'JSON',
                type:'POST',
                complete:function(jqXHR,textStatus) {
                    if(jqXHR.status == 200) {
                        var result = JSON.parse(jqXHR.responseText);
                        if(result.hasOwnProperty('success')) {
                            if(result.hasOwnProperty('assessments')) {
                                var assessments = result.assessments;
                                var output = "";
                                var i = 0;
                                if(assessments.length == 0) {
                                    output = "<tr><td colspan='4'>No Result Found</td></tr>";
                                } else {
                                    assessments.forEach((assessment) =>{
                                        i++;
                                        var route = "{{ route('assessment.delete',':id') }}";
                                        var routeUpload = "{{ route('batchAssessment.create',[':id',':batch_id']) }}"; 
                                        routeUpload = routeUpload.replace(":id",assessment.batch_id);
                                        routeUpload = routeUpload.replace(":batch_id",assessment.id);
                                        route = route.replace(":id",assessment.id);
                                        var routeShow = "{{ route('assessment.show',':id') }}";
                                        routeShow = routeShow.replace(":id",assessment.id);
                                        output += "<tr><td>"+i+"</td><td>Test "+i+"</td><td>"+assessment.total_marks+"</td>"
                                            +"<td><a href='"+route+"' style='color:red;margin-left:5px;' title='Delete Bacth Assessment'><i class='ft-trash'></i></a>";
                                            if(assessment.report == 1) {
                                                output+="<a href='"+route+"' style='color:green;margin-left:5px;' title='Check Assessment Result'><i class='ft-eye'></i></a>";
                                            } else {
                                                output+="<a href='"+routeUpload+"' style='margin-left:5px;'><i class='ft-bell'></i></a>";    
                                            }
                                            +"</td>"
                                            +"</tr>";
                                    });
                                }
                                
                                $(".tbody > tr").remove();
                                $(".tbody").append(output);
                            }
                            $("#assessmentModal").modal('hide');
                            toastr.success("Batch Assessment Added Successfully");
                        }
                    }
                }
            });

        });
        //end adding assesment in storage
    });
</script>
@stop