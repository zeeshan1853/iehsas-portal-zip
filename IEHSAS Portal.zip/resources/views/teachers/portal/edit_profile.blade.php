@extends('layouts.app_teacher')

@section('styles')

<link rel="stylesheet" type="text/css" href="{{ asset('student-portal/app/vendors/css/forms/selects/selectize.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('student-portal/app/vendors/css/forms/selects/selectize.default.css') }}">

<link rel="stylesheet" type="text/css" href="{{ asset('student-portal/app/css/plugins/forms/selectize/selectize.min.css') }}">
<link href="{{ asset('css/jasny-bootstrap.min.css') }}" rel="stylesheet" type="text/css">
@stop


@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-content collpase show">
                <div class="card-body">
                    <form class="form form-horizontal" method="POST" action="{{ route('teacher.updateProfile') }}" enctype="multipart/form-data">
                        {{ csrf_field() }}
                        <input type="hidden" name="id" value="{{ $teacher->id }}">
                        <div class="form-body">
                            <h4 class="form-section"><i class="ft-edit"></i> Edit Profile</h4>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="last_name">Qualification :</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <input type="text" class="input-selectize" value="{{ $teacher->profile->qualification }}" name="qualification" placeholder="Enter Your Qualification">
                                    </div>
                                    <span class="text-danger"></span>
                                    
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="last_name">Experience:</label>
                                <div class="col-md-8">
                                    <input type="text" id="last_name" class="form-control" value="{{ $teacher->profile->experience }}" name="experience" placeholder="Enter Working Experience" name="last_name">
                                    <span class="text-danger"></span>
                                    
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="last_name">Skills:</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <input type="text" class="input-selectize" value="{{ $teacher->profile->skills }}" name="skills" placeholder="Enter Your Skills Set">
                                    </div>
                                    <span class="text-danger"></span>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="last_name">Professional Courses:</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <input type="text" class="input-selectize" value="{{ $teacher->profile->professional_courses }}" name="professional_courses" placeholder="Enter Your Professional Courses">
                                    </div>
                                    
                                    <span class="text-danger"></span>
                                    
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="last_name">Profile Image:</label>
                                <div class="col-md-8">
                                    <div class="form-group row">
                                        <div>
                                            <!-- Student Image-->
                                            <div class="form-group">
                                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                                    <div class="fileinput-preview img-thumbnail" data-trigger="fileinput" style="width: 300px; height: 200px;">
                                                        <!-- Demo Image -->
                                                        <img src="{{ asset($teacher->profile_image) }}">
                                                    </div>
                                                    <div>
                                                <span class="btn btn-outline-secondary btn-file">
                                                  <span class="fileinput-new">Select image</span>
                                                  <span class="fileinput-exists">Change</span>
                                                  <input type="file" name="profile_image">
                                                </span>
                                                        <a href="#" class="btn btn-outline-secondary fileinput-exists" data-dismiss="fileinput">Remove</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    @if($errors->has('profile_image'))
                                        <span class="text-danger">{{$errors->first('profile_image')}}</span>
                                    @endif
                                </div>
                            </div>
                        </div>

                        <div class="form-actions">
                            <center>
                                <button type="submit" class="btn btn-primary">Update</button>
                            </center>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@stop


@section('scripts')
<script src="{{ asset('student-portal/app/vendors/js/forms/select/selectize.min.js') }}"></script>
<script src="{{ asset('app/js/core/libraries/jquery_ui/jquery-ui.min.js') }}"></script>
<script src="{{ asset('student-portal/app/js/scripts/forms/select/form-selectize.min.js') }}"></script>
<script src="{{ asset('js/jasny-bootstrap.min.js') }}"></script>
@stop