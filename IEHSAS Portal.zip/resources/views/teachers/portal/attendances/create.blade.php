@extends('layouts.app_teacher')


@section('styles')


@stop


@section('content')
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <form action="{{ route('teacher.storeStudentAttendance') }}" method="post">
                    <table class="table table-striped">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th>Sr.No</th>
                                <th>Student Name</th>
                                <th>Attendance</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if($students->count() != 0)
                            <input type="hidden" name="batch_id" value="{{ $students[0]->batch_id }}">
                            @php  $i=1; @endphp
                            @foreach($students as $student)
                                <tr>
                                    <td>{{ $i++ }}</td>
                                    <td>{{ $student->student->student_name }} {{ $student->student->father_name}}</td>
                                    <td>
                                        <select class="form-control" name="students[{{ $student->student->id}}]">
                                            <option class="A">A</option>
                                            <option class="P">P</option>
                                            <option class="L">L</option>
                                        </select>
                                    </td>
                                </tr>
                                
                            @endforeach
                            @else
                            <tr>
                                <td colspan="3" class="text-center">No Student Found</td>
                            </tr>
                            @endif
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="3" class="text-center"><input type="submit" value="Save" class="btn btn-primary"></td>
                            </tr>
                        </tfoot>
                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
@stop


@section('scripts')

@stop

