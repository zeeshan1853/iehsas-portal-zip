@extends('layouts.app_teacher')

@section('styles')
<link rel="stylesheet" type="text/css" href="{{ asset('student-portal/app/css/pages/users.min.css') }}">
<style>
    .bor{
        border-right:1px solid #CDCDCE;
    }
</style>
@stop

@section('content')
<div class="col-md-6 offset-md-3">
    <div class="card">
        <div class="text-center">
            <br>
            <img src="{{ asset($teacher->profile_image) }}" class="rounded-circle  height-150" alt="Card image">
            <br><br>
            <div id="rating">
                @for($i=0;$i<=4;$i++)
                @if($teacher->rating < 3)
                    <span class="ft-star @if($i < $teacher->rating) text-danger  @endif"></span>
                @else
                    <span class="ft-star @if($i < $teacher->rating) text-success  @endif"></span>
                @endif
                @endfor
                ( {{ $teacher->rating }} )
            </div>
            
            <div class="card-body">
                <h2 class="text-bold-600">{{ ucfirst($teacher->name) }}  </h4>
            </div>
        </div>
        <div class="list-group list-group-flush text-bold-500 ">
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-user"></i> Teacher Name</span>
                <span class="col-md-6">{{ ucfirst($teacher->name) }}</span>
            </li>
            
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-phone"></i> Contact No</span>
                <span class="col-md-6">{{ $teacher->contact_no }}</span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-mail"></i> Email</span>
                <span class="col-md-6">{{ $teacher->email }}</span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-briefcase"></i> Qualification</span>
                <span class="col-md-6">
                    @php
                        if($teacher->profile->qualification != "")  {
                            
                            $qualifications = preg_split("/,/",$teacher->profile->qulification);
                            if(count($qualifications) == 1) {
                                echo("<span class='badge badge-primary'>".$teacher->profile->qualification."</span>");
                            }
                            else {
                                foreach($qualifications as $qualification) {
                                    echo("<span class='badge badge-primary'>".$qualification."</span> &nbsp;");
                                }
                            } 
                        } else {
                            echo("N/A");
                        }
                        
                    @endphp
                </span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-clock"></i> Experience</span>
                <span class="col-md-6">
                    @if($teacher->profile->experience != "")
                        {{ $teacher->profile->experience }} 
                    @else
                        N/A
                    @endif
                </span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-shield"></i> Skills</span>
                <span class="col-md-6">
                    @php
                    if($teacher->profile->skills != "")  {
                        
                        $skills = preg_split("/,/",$teacher->profile->skills);
                        if(count($skills) == 1) {
                            echo("<span class='badge badge-primary'>".$teacher->profile->skills."</span>");
                        }
                        else {
                            foreach($skills as $skill) {
                                echo("<span class='badge badge-primary'>".$skill."</span> &nbsp;");
                            }
                        } 
                    } else {
                        echo("N/A");
                    }
                    
                @endphp
                </span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-globe"></i> Professional Courses</span>
                <span class="col-md-6">
                    @php
                    if($teacher->profile->professional_courses != "")  {
                        
                        $professional_courses = preg_split("/,/",$teacher->profile->professional_courses);
                        if(count($professional_courses) == 1) {
                            echo("<span class='badge badge-primary'>".$teacher->profile->professional_courses."</span>");
                        }
                        else {
                            foreach($professional_courses as $professional_course) {
                                echo("<span class='badge badge-primary'>".$professional_course."</span> &nbsp;");
                            }
                        } 
                    } else {
                        echo("N/A");
                    }
                    
                @endphp
                </span>
            </li>
            <li class="list-group-item">
                <center>
                    <a href="{{ route('teacher.editProfile') }}" class="btn btn-primary">Edit Profile</a>
                    <a href="{{ route('teacher.changePassword') }}" class="btn btn-info">Change Password</a>
                </center>
            </li>
        </div>
    </div>
</div>

@stop


@section('scripts')
<script>
    /*
    var rating = "{{ $teacher->rating }}";
    var stars = document.getElementById("rating").children;
    if(rating < 3) {
        for(var i = 0;i<rating;i++) {
            stars[i].style = "color:red";
        }
    } else {
        for(var i = 0;i<rating;i++) {
            stars[i].style = "color:green";
        }
    }
    */
</script>
@stop


