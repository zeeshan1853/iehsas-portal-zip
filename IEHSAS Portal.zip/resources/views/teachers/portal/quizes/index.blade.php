@extends('layouts.app_teacher')


@section('styles')

@stop

@section('content')
<section id="dom">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="float-right">
                        <a href="{{ route('quiz.create',['id'=>Route::input('id')]) }}" class="btn btn-primary round btn-min-width mr-1 mb-1" id="addAssessment">
                            <i class="fa fa-plus-circle"></i>&nbsp;
                            Add New Quiz
                        </a>
                    </div>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Sr.No</th>
                                <th>Total Marks</th>
                                <th>Document</th>
                                <th>Deadline</th>
                                <th>Time <small> (H:m:s)</small></th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php $i = 1; @endphp
                            @foreach($quizzes as $quiz)
                                <tr>
                                    <td>{{ $i++ }}</td>
                                    <td>{{ $quiz->total_marks }}</td>
                                    <td>
                                        <a href="{{ asset($quiz->document) }}" target="_blank">Document File</a>
                                    </td>
                                    <td>{{ $quiz->deadline->toFormattedDateString() }}</td>
                                    <td>{{ $quiz->time }}</td>
                                    <td>
                                        <a href="{{ route('quiz.delete',['id'=>$quiz->id]) }}" style="color:red;">
                                            <span class="ft-trash"></span>
                                        </a>
                                        <a href="{{ route('studentQuiz.index',['id'=>$quiz->id]) }}" style="margin-left:5px;" title="View Student Quizes">
                                            <span class="ft-eye"></span>
                                        </a>
                                        @php
                                            $now = date("Y-m-d");
                                            if($now > $quiz->deadline->format("Y-m-d")) {
                                                @endphp
                                                @if($quiz->quizResults->count() > 0)
                                                    <a href="{{ route('quizResult.show',['id'=>$quiz->id]) }}" style="margin-left:5px; color:orange;" title="Show Student Quiz Report">
                                                        <span class="ft-book"></span>
                                                    </a>
                                                @else
                                                    <a href="{{ route('quizResult.create',['id'=>$quiz->id]) }}" style="margin-left:5px;" title="Upload Student Quiz Marks">
                                                        <span class="ft-activity"></span>
                                                    </a>
                                                @endif
                                                    
                                                @php
                                            }
                                        @endphp
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
@stop


@section('scripts')
@stop