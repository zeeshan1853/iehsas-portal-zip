@extends('layouts.app_teacher')

@section('styles')
<link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

<link href="{{ asset('css/timepicker.min.css') }}"  rel="stylesheet">

@stop


@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-content collpase show">
                <div class="card-body">
                    <form class="form form-horizontal" method="POST" action="{{ route('quiz.store') }}" enctype="multipart/form-data">
                        {{ csrf_field() }}
                        <input type="hidden" name="batch_id" value="{{ Route::input('id') }}">
                        <div class="form-body">
                            <h4 class="form-section"><i class="ft-user"></i> {{ $page_heading }}</h4>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="document">Document :</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <input type="file" id="document" class="form-control {{ $errors->has('document') ? 'is-invalid' : '' }}" name="document">
                                        <div class="form-control-position">
                                            <i class="fa fa-sticky-note"></i>
                                        </div>
                                    </div>
                                    @if($errors->has('document'))
                                    <span class="text-danger">{{ $errors->first('document') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="deadline">Deadline Date :</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <input type="text" id="date" class="form-control {{ $errors->has('deadline') ? 'is-invalid' : '' }}" placeholder="Dead Line Date" name="deadline">
                                        <div class="form-control-position">
                                            <i class="ft-clock"></i>
                                        </div>
                                    </div>
                                    @if($errors->has('deadline'))
                                        <span class="text-danger">{{ $errors->first('deadline') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="deadline">Total Marks :</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <input type="integer" id="totalMarks" class="form-control {{ $errors->has('total_marks') ? 'is-invalid' : '' }}" placeholder="Enter Quiz Marks" name="total_marks">
                                        <div class="form-control-position">
                                            <i class="fa fa-percent"></i>
                                        </div>
                                    </div>
                                    @if($errors->has('total_marks'))
                                    <span class="text-danger">{{ $errors->first('total_marks') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="deadline">Time :</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <input type="text" id="time" name="time" class="form-control" placeholder="Select Quiz Time">
                                        <div class="form-control-position">
                                            <i class="fa fa-clock-o"></i>
                                        </div>
                                    </div>
                                    @if($errors->has('time'))
                                    <span class="text-danger">{{ $errors->first('time') }}</span>
                                    @endif
                                </div>
                            </div>
                        </div>

                        <div class="form-actions">
                            <center>
                                <button type="submit" class="btn btn-primary">Upload</button>
                            </center>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@stop

@section('scripts')
<script src="{{ asset('student-portal/app/js/core/libraries/jquery_ui/jquery-ui.min.js') }}"></script>
<script src="{{ asset('student-portal/app/js/scripts/ui/jquery-ui/date-pickers.min.js') }}"></script>

<script src="{{ asset('js/timepicker.min.js') }}"></script>
<script>
    $(document).ready((e) => {
        $("#date").datepicker().datepicker("setDate", new Date());
        
        var timepicker = new TimePicker('time', {
            theme: 'dark', // or 'blue-grey'
            lang: 'en', // 'en', 'pt' for now
          });
        timepicker.on('change', function(evt) {

        var value = (evt.hour || '00') + ':' + (evt.minute || '00');
        evt.element.value = value;
        
        });
    });
</script>
@stop