@extends('layouts.app_teacher')

@section('styles')

@stop

@section('content')
<div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-content collpase show">
                    <div class="card-body">
                        <form class="form form-horizontal" method="POST" action="{{ route('quizResult.update',['id'=>$result->id]) }}" >
                            {{ csrf_field() }}
                            <div class="form-body">
                                <h4 class="form-section"><i class="ft-user"></i> {{ $page_heading }}</h4>
                                <div class="form-group row">
                                    <label class="col-md-2 label-control" for="document">Obtain Marks :</label>
                                    <div class="col-md-8">
                                        <div class="position-relative has-icon-left">
                                            <input type="integer" value="{{ $result->obtain_marks }}" id="obtainMarks" placeholder="Enter Obtain Marks" class="form-control {{ $errors->has('obtain_marks') ? 'is-invalid' : '' }}" name="obtain_marks">
                                            <div class="form-control-position">
                                                <i class="fa fa-sticky-note"></i>
                                            </div>
                                        </div>
                                        @if($errors->has('obtain_marks'))
                                        <span class="text-danger">{{ $errors->first('obtain_marks') }}</span>
                                        @endif
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-2 label-control" for="document">Remarks :</label>
                                    <div class="col-md-8">
                                        <div class="position-relative has-icon-left">
                                            <textarea class="form-control" name="remarks" placeholder="Enter Remarks">{{ $result->remarks }}</textarea>
                                            <div class="form-control-position">
                                                <i class="fa fa-sticky-note"></i>
                                            </div>
                                        </div>
                                        @if($errors->has('remakrs'))
                                        <span class="text-danger">{{ $errors->first('remarks') }}</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
    
                            <div class="form-actions">
                                <center>
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </center>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

@stop

@section('scripts')

@stop

