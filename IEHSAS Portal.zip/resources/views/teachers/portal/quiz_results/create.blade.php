@extends('layouts.app_teacher')

@section('styles')

@stop

@section('content')
<section id="dom">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <form action="{{ route('quizResult.store') }}" method="post">
                            {{ csrf_field() }}
                            <input type="hidden" name="quiz_id" value="{{ $quiz->id }}">
                            <table class="table table-striped">
                                <thead class="bg-info text-white text-white">
                                    <tr>
                                        <td>Sr.No</td>
                                        <td>Name</td>
                                        <td>Obtain Marks</td>
                                        <td>Remakrs</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    @php $i = 1; @endphp
                                    @foreach($student_courses as $student)
                                        <tr>
                                            <td>{{ $i++ }}</td>
                                            <td>{{ $student->student->student_name }} {{ $student->student->father_name }}</td>
                                            <td>
                                                <input type="integer" name="marks[{{ $student->id }}]" class="form-control" min="0" placeholder="Enter Obtain Marks" value="0">
                                            </td>
                                            <td>
                                                <textarea name="remarks[{{ $student->id }}]" class="form-control" cols="15" rows="5" placeholder="Enter Remakrs"></textarea>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="4" class="text-center">
                                            <input type="submit" class="btn btn-primary" value="Store">
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </form>
                    </div>
                </div>
            </div>
        </div>
</section>
@stop


@section('scripts')

@stop