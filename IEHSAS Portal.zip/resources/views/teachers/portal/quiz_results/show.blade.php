@extends('layouts.app_teacher')

@section('styles')

@stop

@section('content')
<section id="dom">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr class="bg-amber text-center">
                                    <th>Sr. No</td>
                                    <th>Name</th>
                                    <th>Quiz</th>
                                    <th>Total Marks</th>
                                    <th>Obtain Marks</th>
                                    <th>Remarks</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php $i = 1; @endphp
                                @foreach($results as $result)
                                    <tr>
                                        <td>{{ $i++ }}</td>
                                        <td>{{ $result['student_name']}}</td>
                                        <td>
                                            @if($result['quiz'] == "")
                                            
                                            @else
                                            <a href="{{ asset($result['quiz']) }}" target="_blank">
                                                <span class="ft-download"></span>
                                            </a>
                                            @endif
                                        </td>
                                        <td>{{ $result['total_marks'] }}</td>
                                        <td>{{ $result['obtain_marks'] }}</td>
                                        <td>{{ $result['remarks'] }}</td>
                                        <td>
                                            <a href="{{ route('quizResult.edit',['id'=>$result['quiz_id']]) }}" title="Edit Student Quiz Details">
                                                <span class="ft-edit"></span>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
</section>
@stop

@section('scripts')

@stop