@extends('layouts.app_teacher')

@section('styles')

@stop

@section('content')
<section id="dom">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped text-center">
                            <thead class="bg-primary text-white ">
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Student Name</th>
                                    <th>Total Marks</th>
                                    <th>Obtain marks</th>
                                    <th>Remarks</th>
                                </tr>
                            </thead>
                            @php $i = 1; @endphp
                            <form action="{{ route('batchAssessment.store',['id'=>$assessment_id]) }}" method="post">
                                <input type="hidden" name="batch_id" value="{{ Route::input('batch_id') }}">
                                {{ csrf_field() }}
                                <tbody>
                                    @foreach($student_courses as $course)
                                        <tr>
                                            <td>{{ $i++ }}</td>
                                            <td>{{ $course['student_name'] }}</td>
                                            <td>{{ $course['total_marks'] }}</td>
                                            <td>
                                                <input type="number" min="0" name="students[{{ $course['student_id'] }}]" class="form-control" placeholder="Enter Obtain Marks" autofocus value="0">
                                            </td>
                                            <td>
                                                <textarea name="remarks[{{ $course['student_id'] }}]"  class="form-control" placeholder="Enter Remarks / Improvement"></textarea>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="5" class="text-center"><input type="submit" class="btn btn-primary" value="Save"></td>
                                    </tr>
                                </tfoot>
                            </form>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@stop

@section('scripts')

@stop