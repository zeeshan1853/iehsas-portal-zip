@extends('layouts.app_teacher')

@section('styles')

@stop


@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-content collpase show">
                <div class="card-body">
                    <form class="form form-horizontal" method="POST" action="{{ route('batchAssessment.update',['id'=>$assessment->id]) }}">

                        {{ csrf_field() }}
                        <div class="form-body">
                            <h4 class="form-section"><i class="fa fa-edit"></i> {{ $page_heading }}</h4>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="first_name">Obtain Marks :</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <input type="number"  id="obtain_marks" value="{{ $assessment->obtain_marks }}" class="form-control" placeholder="Enter Obtain Marks" name="obtain_marks" min="0" autofocus>
                                        <div class="form-control-position">
                                            <i class="ft-percent"></i>
                                        </div>
                                        @if($errors->has('obtain_marks'))
                                        <span class="text-danger">{{ $errors->first('obtain_marks') }}</span>
                                        @endif
                                    </div>
                                </div>
                                
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="first_name">Remarks :</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <textarea class="form-control" name="remarks" placeholder="Enter Remarks">{{ $assessment->remarks }}</textarea>
                                        <div class="form-control-position">
                                            <i class="ft-percent"></i>
                                        </div>
                                        @if($errors->has('remarks'))
                                        <span class="text-danger">{{ $errors->first('remarks') }}</span>
                                        @endif
                                    </div>
                                </div>
                                
                            </div>
                        </div>

                        <div class="form-actions">
                            <center>
                                <button type="submit" class="btn btn-primary">Update</button>
                            </center>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@stop

@section('scripts')

@stop