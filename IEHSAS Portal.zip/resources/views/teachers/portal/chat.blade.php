@extends('layouts.teacher_chat')


@section('styles')
<link rel="stylesheet" type="text/css" href="{{ asset('student-portal/app/css/pages/chat-application.css') }}">
<style>
    .card-body {
        padding: 1.0rem;
    }
</style>
@stop

@section('content')
<div id="app">
    <teacher-chat-app :asset="'{{ asset('/') }}'" :batch_id="'{{ Route::input('id') }}'" :path="'{{ url('/teacher') }}'" :teacher="{{ $teacher }}">
    </teacher-chat-app>
</div>

@stop

@section('scripts')
<script src="{{ asset('js/app.js') }}"></script>

@stop