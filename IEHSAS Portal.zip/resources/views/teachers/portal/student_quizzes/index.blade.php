@extends('layouts.app_teacher')


@section('styles')

@stop

@section('content')
<section id="dom">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Sr.No</th>
                                <th>Student Name</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if($student_quizzes->count() == 0)
                                <tr>
                                    <td colspan="3" class="text-center">No Result Found</td>
                                </tr>
                            @else
                                @php $i = 1; @endphp
                                @foreach($student_quizzes as $quiz)
                                    <tr>
                                        <td>{{ $i++ }}</td>
                                        <td>{{ $quiz->student->student_name }}</td>
                                        <td>
                                            <a href="{{ asset($quiz->document) }}"  target="_blank" style="color:green;">
                                                <i class="ft-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
@stop


@section('scripts')
@stop