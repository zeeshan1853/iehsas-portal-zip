@extends('layouts.app_teacher')

@section('styles')
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.css" rel="stylesheet">

@stop


@section('content')
<div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-content collpase show">
                    <div class="card-body">
                        <form class="form form-horizontal" method="POST" action="{{ route('batchDailyActivity.store') }}">

                            {{ csrf_field() }}
                            <input type="hidden" name="batch_id" value="{{ $id }}">
                            <div class="form-body">
                                <h4 class="form-section"><i class="fa fa-book"></i> {{ $page_heading }}</h4>
                                <div class="form-group">
                                    <label for="editor" class="text-bold-600">Today Topic Covered:</label> 
                                    <textarea id="editor" name="content" class="form-control"></textarea>
                                    @if($errors->has('content'))
                                        <span class="text-danger">{{ $errors->first('content') }}</span>
                                    @endif
                                </div>
                                <div class="form-group">
                                    <label for="improvement" class="text-bold-600">Improvements: </label>
                                    <textarea class="form-control" name="improvement"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="improvement" class="text-bold-600">Suggestions: </label>
                                    <textarea class="form-control" name="suggestion"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="improvement" class="text-bold-600">Remakrs: </label>
                                    <textarea class="form-control" name="remarks"></textarea>
                                </div>
                            </div>
    
                            <div class="form-actions">
                                <center>
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </center>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
@stop

@section('scripts')
<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.js"></script>
<script>
    $(document).ready(function(e) {
        $("#editor").summernote({
            height:300,
        });
    });
</script>
@stop