@extends('layouts.app_teacher')

@section('styles')
<link rel="stylesheet" type="text/css" href="{{ asset('student-portal/app/vendors/css/tables/datatable/datatables.min.css') }}">
@stop


@section('content')
<section id="dom">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table class="table table-bordered" id="batches">
                        <thead>
                            <tr>
                                <td>Sr.No</td>
                                <td>Course</td>
                                <td>Batch</td>
                                <td>Start Date</td>
                                <td>End date</td>
                                <td>Attendance</td>
                                <td>Actions</td>
                            </tr>
                        </thead>
                        <tbody>
                            @php  $i = 1; @endphp
                            @foreach($batches as $batch)

                                <tr>
                                    <td>{{ $i++ }}</td>
                                    <td>{{ $batch->course->course_name }}</td>
                                    <td>{{ $batch->batch_name }}</td>
                                    <td>{{ $batch->start_date->toFormattedDateString() }}</td>
                                    <td>{{ $batch->end_date->toFormattedDateString() }}</td>
                                    <td>
                                        <a href="{{ route('teacher.createStudentAttendance',['id'=>$batch->id]) }}" class="btn btn-sm btn-primary" title="Take Attendance">Attendance</a>
                                    </td>
                                    <td>
                                        <a href="{{ route('teacher.batchStudentList',['id'=>$batch->id]) }}" title="Student List">
                                            <span class="fa fa-eye" style="color:green;"></span>
                                        </a>
                                        <a href="{{ route('batchDailyActivity.create',['id'=>$batch->id]) }}" style="color:orange;margin-left:5px;" title="Add Daily Activity">
                                            <i class="fa fa-sticky-note"></i>
                                        </a>
                                        <a href="{{ route('assessment.index',['id'=>$batch->id]) }}" style="color:purple;margin-left:5px;" title="Batch Assessments List">
                                            <i class="fa fa-desktop"></i>
                                        </a>
                                        <a href="{{ route('quiz.index',['id'=>$batch->id]) }}" style="color:orange;margin-left:5px;" title="Batch Quiz List">
                                            <i class="fa fa-question"></i>
                                        </a>
                                        <a href="{{ route('teacher.chat',['id'=>$batch->id]) }}" title="Chat With Students">
                                            &nbsp;<i class="fa fa-envelope"></i>
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
@stop

@section('scripts')
<script src="{{ asset('student-portal/app/vendors/js/tables/datatable/datatables.min.js') }}"></script>
<script>
    $(document).ready(function(e) {
        $("#batches").dataTable();
    })
</script>
@stop