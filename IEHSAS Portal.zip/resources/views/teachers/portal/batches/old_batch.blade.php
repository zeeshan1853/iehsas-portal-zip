@extends('layouts.app_teacher')

@section('styles')
<link rel="stylesheet" type="text/css" href="{{ asset('student-portal/app/vendors/css/tables/datatable/datatables.min.css') }}">
@stop


@section('content')
<section id="dom">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table class="table table-bordered" id="batches">
                        <thead class="bg-info text-white text-center">
                            <tr>
                                <th>Sr.No</th>
                                <th>Course</th>
                                <th>Batch</th>
                                <th>Start Date</th>
                                <th>End date</th>
                                <th>Rating</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php  $i = 1; @endphp
                            @foreach($batches as $batch)

                                <tr>
                                    <td>{{ $i++ }}</td>
                                    <td>{{ $batch['course_name'] }}</td>
                                    <td>{{ $batch['batch_name'] }}</td>
                                    <td>{{ $batch['start_date'] }}</td>
                                    <td>{{ $batch['end_date'] }}</td>
                                    <td>
                                        <span class="badge badge-primary">{{ $batch['rating'] }}</span>
                                    </td>
                                    <td>
                                        <a href="{{ route('teacher.batchStudentList',['id'=>$batch['batch_id']]) }}">
                                            <i class="fa fa-eye" style="color:green;" title="View Student List"></i>
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
@stop

@section('scripts')
<script src="{{ asset('student-portal/app/vendors/js/tables/datatable/datatables.min.js') }}"></script>
<script>
    $(document).ready(function(e) {
        $("#batches").dataTable();
    })
</script>
@stop