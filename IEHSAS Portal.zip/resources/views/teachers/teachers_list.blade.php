@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="teachersData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Name</td>
                        <td data-column-id="contact_no">Contact No</td>
                        <td data-column-id="actions" data-sortable="false">Actions</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach($teachers as $teacher)
                        <tr>
                            <td>{{$i++}}</td>
                            <td>{{$teacher->name}}</td>
                            <td>{{$teacher->contact_no}}</td>
                            <td>
                                <a href="{{route('teacher.edit_teacher',['id'=>$teacher->id])}}">
                                    <i class="ft-edit"></i>
                                </a> 
                                <a href="{{route('teacher.delete_teacher',['id'=>$teacher->id])}}">
                                    <i class="ft-trash" style="color:red; margin-left: 5px;"></i>
                                </a>
                                @if($teacher->status == 0)
                                    <a href="{{ route('teacher.active',['id'=>$teacher->id]) }}" style="color:green; margin-left:5px;" title="Active Teachers Account">
                                        <i class="ft-check-circle"></i>
                                    </a>
                                @else
                                    <a href="{{ route('teacher.deactive',['id'=>$teacher->id]) }}" title="Deactive Teachers Account">
                                        <i class="ft-delete" style="color:red; margin-left:5px;"></i>    
                                    </a> 
                                @endif
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#teachersData").DataTable();
        })
    </script>
@stop