@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="branchesData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Branch</td>
                        <td data-column-id="narration">Narration</td>
                        <td data-column-id="batch">Batch</td>
                        <td data-column-id="debit">Debit</td>
                        <td data-column-id="credit">Credit</td>
                        <td data-column-id="date">Date</td>
                        <td data-sortable="false">Actions</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach($recoveries as $recovery)
                        <tr>
                            <td>{{ $i++ }}</td>
                            <td>{{ $recovery->branch->name }}</td>
                            <td>{{ $recovery->narration }}</td>
                            <td>{{ $recovery->batch->batch_name }}</td>
                            <td>{{ $recovery->debit }}</td>
                            <td>{{ $recovery->credit }}</td>
                            <td>{{ $recovery->created_at->toFormattedDateString() }}</td>
                            <td><a href="{{ route('branchRecovery.delete',['id'=>$recovery->id]) }}" style="color:red;"><span class="ft-trash"></span></a></td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#branchesData").DataTable({
                language: {
                    searchPlaceholder: "Search",
                }
            });
        })
    </script>
@stop