@extends('app')

@section('header-styles')
<link href="{{asset('vendors/css/forms/selects/select2.min.css')}}" rel="stylesheet" type="text/css">

@stop

@section('main')
    <div class="row">
        <div class="card col-md-8 offset-md-2">
            <div class="card-body">
                <form method="post" action="{{route('branchRecovery.store')}}">
                    @csrf
                    <div class="form-group">
                        <label><h5 class="mt-2">Branches:</h5></label>
                        <div class="input-group">
                            <select id="branch_id" class="form-control select2" name="branch_id">
                                <option value="">--Select Branch --</option>
                                @foreach($branches as $branch)
                                    @if($branch->branch != 1)
                                    <option value="{{ $branch->id }}" data-balance="{{ $branch->debit - $branch->credit }}" >{{ $branch->name }}</option>
                                    @endif
                                @endforeach
                            </select>
                            <div class="input-group-append">
                                <span class="input-group-text" id="balance">00000</span>
                            </div>
                            
                        </div>
                        @if($errors->has('branch_id'))
                            <span class="text-danger">{{ $errors->first('branch_id') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="batch">Select Batch</label>
                        <select class="form-control" id="batch_id" name="batch_id">
                            <option value="">--Select Batch--</option>
                        </select>
                        @if($errors->has('batch_id'))
                            <span class="text-danger">{{ $errors->first('batch_id') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="amount">Receive Amount:</label>
                        <input type="number" name="amount" placeholder="Enter Received Amount" class="form-control">
                        @if($errors->has('amount'))
                            <span class="text-danger">{{ $errors->first('amount') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <lable for="narration">Narration</lable>
                        <textarea name="narration" placeholder="Enter Narration" id="narration" class="form-control"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="amount">Recovery Date:</label>
                        <input type="date" name="date" id="date" class="form-control">
                        @if($errors->has('date'))
                            <span class="text-danger">{{ $errors->first('date') }}</span>
                        @endif
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" id="submit" class="btn btn-primary offset-md-4 col-md-4" >
                            Add Recovery
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
<script src="{{asset('vendors/js/forms/select/select2.full.min.js')}}"></script>
<script>
    $(document).ready(function (e) {
        $("#branch_id").select2();
        $("#branch_id").change(function(e) {
            var id = $("#branch_id").val();
            //getting branch balance from data-balance
            if(id == "") {
                $("#balance").html("0000");    
                return;
            }
            var bal = $(this).find(':selected').data('balance');
            
            $("#balance").html(bal);
            //getting branch batches
            var data = {
                id:id,
            };
            $.ajax({
                url:"{{ route('batch.get_branch_batches') }}",
                data:data,
                dataType:'JSON',
                type:'POST',
                complete:function(jqXHR,textStatus) {
                    if(jqXHR.status == 200) {
                        var result = JSON.parse(jqXHR.responseText);
                        if(result.hasOwnProperty('success')) {
                            var output = "";
                            if(result.batches.length == 0) { 
                                output += "<option value=''>No Batch Found</option>";
                                $("#batch_id > option").remove();
                                $("#batch_id").append(output);
                                $("#submit").attr('disabled',true);
                            } else {
                                result.batches.forEach(function(batch) {
                                    output += "<option value='"+batch.id+"'>"+batch.batch_name+"</option>";
                                });
                                $("#batch_id > option ~ option").remove();
                                $("#batch_id").append(output);
                                $("#submit").attr("disabled",false);
                            }
                        }
                    } else {
                        swal({
                            type:'error',
                            text:'Opss Something Went Wrong',
                        })
                    }
                }
            });

        });
        var date = new Date();
        var month = date.getMonth();
        var fullDate = date.getDate();
        if(month < 13)
            month = month + 1;
        if(month < 10) {
            month =  "0" +month;
        }
        if(fullDate < 10)
            fullDate = '0' + fullDate;

        $("#date").val(date.getFullYear() + "-" + month + "-" + fullDate);
    });

</script>
@stop

