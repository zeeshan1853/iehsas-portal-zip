@extends('app')


@section('header-styles')
<link href="{{asset('css/jasny-bootstrap.min.css')}}" rel="stylesheet" type="text/css">

@stop

@section('main')
<div class="row">
    <div class="card col-md-8 offset-md-2">
        <div class="card-body">
            <form method="post" action="{{route('user.update_profile',['id'=>$user['id']])}}" enctype="multipart/form-data">
                @csrf
                <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                <div class="form-group offset-4">
                    <label><h5 class="mt-2">Profile Image:</h5></label>
                    <!-- Student Image-->
                    <div class="form-group">
                        <div class="fileinput fileinput-new" data-provides="fileinput">
                            <div class="fileinput-preview img-thumbnail" data-trigger="fileinput"
                                style="width: 300px; height: 200px;">
                                <img src="{{ asset(Auth::user()->image) }}">
                            </div>
                            <div>
                                <span class="btn btn-outline-secondary btn-file">
                                    <span class="fileinput-new">Select image</span>
                                    <span class="fileinput-exists">Change</span>
                                    <input type="file" name="image">
                                </span>
                                <a href="#" class="btn btn-outline-secondary fileinput-exists"
                                    data-dismiss="fileinput">Remove</a>
                            </div>
                        </div>
                    </div>
                    @if($errors->has('image'))
                    <span class="text-danger offset-md-3">{{$errors->first('image')}}</span>
                    @endif
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary offset-md-4 col-md-4">
                        Edit Profile
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@stop

@section('footer-scripts')
<script src="{{asset('js/jasny-bootstrap.min.js')}}"></script>
@stop