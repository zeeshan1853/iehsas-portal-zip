@extends('app')

@section('header-styles')
    <link href="{{url('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
<div class="row">
    <div class="card col-md-12">
        <div class="card-body">
            <table class="table table-bordered text-center" id="usersData">
                <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Name</td>
                        <td data-column-id="email">Email</td>
                        <td data-column-id="image">Profile Image</td>
                        <td data-column-id="status" data-sortable="false">Status</td>
                        <td data-column-id="actions">Actions</td>
                    </tr>
                </thead>
                <tbody>
                <?php
                $i = 1;
                ?>
                    @foreach($users as $user)
                        <tr>
                            <td>{{$i++}}</td>
                            <td>{{$user->name}}</td>
                            <td>{{$user->email}}</td>
                            <td>
                                <img src="{{ asset($user->image) }}" alt="profile image" class="rounded-circle" style="width:80px;height:80px;">
                            </td>
                            @if($user->admin)
                                <td><a href="{{route('user.remove_admin',['id'=>$user->id])}}" class="btn btn-danger">Remove Admin</a> </td>
                            @else
                                <td><a href="{{route('user.make_admin',['id'=>$user->id])}}" class="btn btn-primary">Make Admin</a> </td>
                            @endif
                            <td>
                                <a href="{{route('user.delete_user',['id'=>$user->id])}}">
                                    <i class="ft-trash" style="color:red;"></i>    
                                </a> 
                                @if($user->status == 1)
                                    <a href="{{ route('user.deactive',['id'=>$user->id]) }}" title="Deactive User">
                                        <i class="ft-x-circle" style="color:red;"></i>
                                    </a>
                                @else
                                    <a href="{{ route('user.activate',['id'=>$user->id]) }}" title="Activate User">
                                        <i class="ft-check-circle" style="color:green;"></i>
                                    </a>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@stop


@section('footer-scripts')
    <script src="{{url('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{url('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{url('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
<script>
    $(document).ready(function(e) {
        $("#usersData").DataTable();
    })
</script>
@stop