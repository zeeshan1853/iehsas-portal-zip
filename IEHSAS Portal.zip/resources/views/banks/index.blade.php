@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="branchesData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Name</td>
                        <td data-column-id="account_no">Account No</td>
                        <td data-column-id="bank_branch">Bank Branch</td>
                        <td data-column-id="debit">Debit</td>
                        <td data-column-id="credit">Credit</td>
                        <td data-column-id="balance">Balance</td>
                        <td data-column-id="balance">Opening</td>
                        <td data-column-id="status">Status</td>
                        <td data-column-id="edit" data-sortable="false">Actions</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach($banks as $bank)
                        <tr>
                            <td>{{ $i++ }}</td>
                            <td>{{ $bank->name }}</td>
                            <td>{{ $bank->account_no }}</td>
                            <td>{{ $bank->bank_branch }}</td>
                            <td>{{ $bank->debit }}</td>
                            <td>{{ $bank->credit }}</td>
                            <td>{{ $bank->debit - $bank->credit }}</td>
                            <td>{{ $bank->opening }}</td>
                            @if($bank->status == 1)
                                <td>
                                    <span href="" class="badge badge-info">Active For Bank Transactions</span>
                                </td>
                            @else 
                                <td>
                                    <a href="{{ route('bank.activate',['id'=>$bank->id]) }}" class="btn btn-sm btn-primary">Activate Bank</a>
                                </td>
                            @endif
                            <td>
                                <a href="{{ route('bank.edit',['id'=>$bank->id]) }}" title="Edit Bank Detail"><i class="ft-edit"></i></a>
                                <a href="{{ route('bank.delete',['id'=>$bank->id]) }}" title="Delete Account"><i class="ft-trash" style="color:red;"></i></a>
                                <a href="{{ route('bankBook.show',['id'=>$bank->id]) }}" title="Bank Book"><i class="ft-eye" style="color:green;"></i></a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#branchesData").DataTable({
                language: {
                    searchPlaceholder: "Search Bank",
                }
            });
        })
    </script>
@stop