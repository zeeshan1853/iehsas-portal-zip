@extends('app')

@section('header-styles')
@stop

@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('bank.update',['id'=>$bank->id])}}" id="instalmentForm">
                    @csrf
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="opening">Bank Name</label>
                                    <div class="col-md-9">
                                        <input type="text" autofocus placeholder="Enter Bank Name" @if(old('name') != '') value="{{ old('name') }}" @else value="{{ $bank->name }}" @endif class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }} " name="name">
                                    </div>
                                    @if($errors->has('name'))
                                    <span class="offset-md-4 text-danger">
                                        {{ $errors->first('name') }}
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="opening">Account No</label>
                                    <div class="col-md-9">
                                        <input type="text" placeholder="Enter bank Account No" @if(old('account_no') != '') value="{{ old('account_no') }}" @else value="{{ $bank->account_no }}" @endif class="form-control {{ $errors->has('account_no') ? 'is-invalid' : '' }} " name="account_no">
                                    </div>
                                    @if($errors->has('account_no'))
                                    <span class="offset-md-4 text-danger">
                                        {{ $errors->first('account_no') }}
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="opening">Bank Branch Name</label>
                                    <div class="col-md-9">
                                        <input type="text" placeholder="Enter Bank Branch Name" @if(old('bank_branch') != '') value="{{ old('bank_branch') }}" @else value="{{ $bank->bank_branch }}" @endif class="form-control {{ $errors->has('bank_branch') ? 'is-invalid' : '' }} " name="bank_branch">
                                    </div>
                                    @if($errors->has('bank_branch'))
                                    <span class="offset-md-4 text-danger">
                                        {{ $errors->first('bank_branch') }}
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="opening">Opening</label>
                                    <div class="col-md-9">
                                        <input type="number" min="0" placeholder="Enter Opening Amont" @if(old('opening') != '') value="{{ old('opening') }}" @else value="{{ $bank->opening }}" @endif class="form-control {{ $errors->has('opening') ? 'is-invalid' : '' }} " name="opening">
                                    </div>
                                    @if($errors->has('opening'))
                                    <span class="offset-md-4 text-danger">
                                        {{ $errors->first('opening') }}
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        
                    </div>

                    <div class="form-actions ">
                        <input type="submit" value="Update" id="btnAdd" class="btn btn-primary offset-md-5">
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
@stop

