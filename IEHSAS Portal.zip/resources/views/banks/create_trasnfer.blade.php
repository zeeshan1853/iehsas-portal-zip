@extends('app')

@section('header-styles')
@stop

@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('book.storeTransfer')}}" id="instalmentForm">
                    @csrf
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Banks</label>
                                    <div class="col-md-9">
                                        <div class="input-group">
                                            <select name="bank_id" class="form-control {{ $errors->has('bank_id') ? 'is-invalid' : '' }}" id="bank_id">
                                                <option value="">--Select Bank--</option>
                                                @foreach($banks as $bank)
                                                    <option value="{{ $bank->id }}" data-balance="{{ $bank->debit }}">{{ $bank->name }}</option>
                                                @endforeach
                                            </select>
                                            <span class="input-group-append">
                                                <span class="input-group-text balance">0</span>
                                            </span>
                                        </div>
                                    </div>
                                    @if($errors->has('bank_id'))
                                    <span class="offset-md-4 text-danger">
                                        {{ $errors->first('bank_id') }}
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Cash Account</label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" disabled value="{{ $cash->debit }}" id="cash_amount">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Trasnfer Amount</label>
                                    <div class="col-md-9">
                                        <input type="number" min="0" placeholder="Enter Trasnfer Amount" name="transfer_amount" class="form-control {{ $errors->has('transfer_amount') ? 'is-invalid' : '' }}" id="transfer_amount">
                                    </div>
                                    @if($errors->has('transfer_amount'))
                                        <span class="offset-md-4 text-danger">
                                            {{ $errors->first('transfer_amount') }}
                                        </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        
                    </div>

                    <div class="form-actions ">
                        <input type="submit" value="Trasnfer" id="btnAdd" class="btn btn-primary offset-md-5">
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
<script>
    $(document).ready(function(e) {
        $("#bank_id").change(function(e) {
            if($("#bank_id").val() == "") {
                $(".balance").html(0);
                return;
            }
            var balance = $(this).find(":selected").data('balance');
            $(".balance").html(balance);
        });
        $("#transfer_amount").keyup(function(e) {
            var bankBalance = parseInt($(".balance").html());
            var amount = parseInt($("#transfer_amount").val());
            if(amount > bankBalance) {
                $("#btnAdd").attr("disabled",true);
            } else {
                $("#btnAdd").attr("disabled",false);
            }
        });
    });
</script>
@stop

