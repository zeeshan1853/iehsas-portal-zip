@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/forms/selects/select2.min.css')}}" rel="stylesheet" type="text/css">

@stop

@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('batch.store_batch')}}">
                    @csrf
                    <input type="hidden" name="branch_id" value="{{Auth::user()->branch->id}}">
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> Batch Details</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Batch Name</label>
                                    <div class="col-md-9">
                                        <input type="text" autofocus id="batch_name" value="{{old('batch_name')}}" class="form-control  {{$errors->has('batch_name') ? 'border-danger' : ''}}" placeholder="Batch Name" name="batch_name">
                                            @if($errors->has('batch_name'))
                                            <span class="text-danger">{{ $errors->first('batch_name') }}</span>
                                            @endif
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Course Name</label>
                                    <div class="col-md-9">
                                        <select class="form-control select2   {{$errors->has('course_id') ? 'border-danger' : ''}}" name="course_id" id="course_id">
                                            <option value="" data-teacher = "">--Select Course--</option>
                                            @foreach($courses as $course)
                                                <option value="{{$course->id}}" @if($course->id == old('course_id')) selected @endif data-teacher="{{$course->teacher_id}}">{{$course->course_name}}</option>
                                            @endforeach
                                        </select>
                                        <span class="text-danger">
                                            @if($errors->has('course_id'))
                                                {{$errors->first('course_id')}}
                                            @endif
                                        </span>
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Teacher Name</label>
                                    <div class="col-md-9">
                                        <select class="form-control select2  {{$errors->has('teacher_id') ? 'border-danger' : ''}}" name="teacher_id" id="teacher_id">
                                            <option value="">--Select Teacher--</option>
                                            @foreach($teachers as $teacher)
                                                <option value="{{$teacher->id}}" @if(old('teacher_id') == $teacher->id) selected @endif>{{$teacher->name}}</option>
                                            @endforeach
                                        </select>
                                        <span class="text-danger">
                                            @if($errors->has('teacher_id'))
                                                {{$errors->first('teacher_id')}}
                                            @endif
                                        </span>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Start Date</label>
                                    <div class="col-md-9">
                                        <input type="date" id="startDate" class="form-control  date {{$errors->has('start_date') ? 'border-danger' : ''}}" @if(old('start_date')) value="{{ old('start_date') }}" @endif  name="start_date">
                                        <span class="text-danger">
                                        @if($errors->has('start_date'))
                                                {{$errors->first('start_date')}}
                                            @endif
                                    </span>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">End Date</label>
                                    <div class="col-md-9">
                                        <input type="date" id="endDate" class="form-control date {{$errors->has('end_date') ? 'border-danger' : ''}}"  name="end_date" @if(old('end_date')) value="{{ old('end_date') }}" @endif  name="end_date">
                                        <span class="text-danger">
                                        @if($errors->has('end_date'))
                                                {{$errors->first('end_date')}}
                                            @endif
                                        </span>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Course Price</label>
                                    <div class="col-md-9">
                                        <input type="number" id="coursePrice" value="{{old('course_price')}}" class="form-control {{$errors->has('course_price') ? 'border-danger' : ''}}"  @if(old('end_date')) value="{{ old('end_date') }}" @endif placeholder="Enter Course Price" name="course_price">
                                        @if($errors->has('course_price'))
                                            <span class="text-danger">
                                                {{ $errors->first('course_price') }}
                                            </span>
                                        @endif
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Share Price</label>
                                    <div class="col-md-9">
                                        <input type="number" name="share_price" min="0" @if(old('share_price')) value="{{ old('share_price') }}" @else value="0" @endif placeholder="Enter Teacher Share Price" class="form-control {{ $errors->has('share_price') ? 'border-danger' : '' }}">
                                        @if($errors->has('share_price'))
                                            <span class="text-danger">
                                                {{ $errors->first('share_price') }}
                                            </span>
                                        @endif
                                    </div> 
                                    
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Store" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/forms/select/select2.full.min.js')}}"></script>
    <script>
        $(document).ready(function (e) {
           $('.select2').select2();
           var dates = document.getElementsByClassName('date'); 
           var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month + 1;
            if(month < 10)
                month = '0'+ month;
            if(fullDate < 10)
                fullDate = '0' + fullDate;
            for(var d in dates) {
                if(dates[d].value == "") {
                    dates[d].value = date.getFullYear() + "-" + month + "-" + fullDate;
                }   
            }
//            $(".date").val(date.getFullYear() + "-" + month + "-" + fullDate);
        });
    </script>

@stop

