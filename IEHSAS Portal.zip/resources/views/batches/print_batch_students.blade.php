<html>
    <head>
        <title>Batch Students</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

        <script
        src="https://code.jquery.com/jquery-3.4.1.min.js"
        integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
        crossorigin="anonymous"></script>

        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <style>
                @page { size: auto;  margin: 0mm; }
        </style>
    <body>


    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h2 class="page-header">
                    {{ Auth::user()->branch->name }}
                    <img src="{{ asset(Auth::user()->branch->setting->logo) }}" width="150px" alt="logo" style="margin-left:25%;">
                    <small class="pull-right">Date: {{ date("d-m-Y") }}</small>
                </h2>
            </div>
            <center><h1>Students List</h1></center>
            <!-- /.col -->
        </div>
    
            <table class="table table-responsive table-bordered">
                <thead>
                    <tr class="bg-primary">
                        <td>Sr.No</td>
                        <td>Student Name</td>
                        <td>Type</td>
                        <td>Email</td>
                        <td>Edu</td>
                        <td>Contact</td>
                        <td>Find ?</td>
                        <td>DOB</td>
                        <td>Reference By</td>
                        <td>Batch Name</td>
                        <td>Total Fee</td>
                        <td>Paid Fee</td>
                        <td>Due Fee</td>
                        <td>Enrolment Date</td>
                    </tr>
                </thead>
                <tbody class="tbody">
    
                </tbody>
            </table>

    </div>
    </body>
</html>
<script>
    $(document).ready(function(e) {
        var students = JSON.parse(localStorage.students);
        console.log(students);
        var output = "";
        students.forEach(function(student) {
            output += "<tr><td>"+student.sr_no+"</td><td>"+student.student_name+" "+student.father_name+"</td><td>"+student.type+"</td><td>"+student.email+"</td><td>"+student.education+"</td><td>"+student.contact_no+"</td><td>"+student.find+"</td><td>"+student.dob+"</td><td>"+student.reference+"</td><td>"+student.batch_name+"</td><td>"+student.total_fee+"</td><td>"+student.paid_amount+"</td><td>"+student.due_amount+"</td><td>"+student.enrolment_date+"</td></tr>"
        });
        $(".tbody > tr").remove();
        $(".tbody").append(output);
        window.print();
        localStorage.students = "";
    })
</script>
