@extends('app')

@section('header-styles')
    <link href="{{url('public/vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="coursesData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Batch Name</td>
                        <td data-column-id="teacher_name">Teacher Name</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach($courses as $course)
                        <tr>
                            <td>{{$i++}}</td>
                            <td>{{$course->batch_name}}</td>
                            <td>{{$course->teacher->name}}</td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{url('public/vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{url('public/js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{url('public/js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#coursesData").DataTable();
        })
    </script>
@stop