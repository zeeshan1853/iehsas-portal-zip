@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="teachersData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Name</td>
                        <td data-column-id="edit" data-sortable="false">Action</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach($payments as $payment)
                        <tr>
                            <td>{{$i++}}</td>
                            <td>{{$payment->name}}</td>
                            <td><a href="{{route('payment.edit',['id'=>$payment->id])}}"><i class="ft-edit"></i></a>
                                @if($payment->status == 1)
                                    <a href="{{route('payment.deactive',['id'=>$payment->id])}}" title="Deactive"><i class="ft-lock" style="color:red;margin-left: 5px;"></i></a>
                                @else
                                    <a href="{{route('payment.active',['id'=>$payment->id])}}" title="active"><i class="ft-unlock" style="color:green;margin-left: 5px;"></i></a>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#teachersData").DataTable();
        })
    </script>
@stop