@extends('layouts.app')

@section('header-styles')

@stop

@section('main')
<section id="collapsible">
    <div class="row">
        <div class="col-lg-12 col-xl-6">
            <div class="mb-2 mt-2">
                <h5 class="mb-0 text-uppercase">Collapse with Icon</h5>
                <p> <code>.collapse-icon</code> to set icon collapse.</p>
            </div>

            <div id="collapse3" class="card-accordion">
                <div class="card collapse-icon accordion-icon-rotate">
                    <div class="card">
                        <div class="card-header" id="headingCOne">
                            <h5 class="mb-0">
                                <button class="btn btn-link" data-toggle="collapse" data-target="#collapseC1"
                                    aria-expanded="true" aria-controls="collapseC1">
                                    Collapsible Group Item #1
                                </button>
                            </h5>
                        </div>

                        <div id="collapseC1" class="collapse show" aria-labelledby="headingCOne">
                            <div class="card-body">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@stop

@section('footer-scripts')

@stop