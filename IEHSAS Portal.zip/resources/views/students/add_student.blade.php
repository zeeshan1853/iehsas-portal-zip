@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/forms/selects/select2.min.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('css/jasny-bootstrap.min.css')}}" rel="stylesheet" type="text/css">
    <style>
        .idCard img {
            margin-top:10px;
            margin-left: 5px;
            border:1px solid #9ea5b0;
            animation: fadein 3;
            -moz-animation: fadein 2s; /* Firefox */
            -webkit-animation: fadein 2s; /* Safari and Chrome */
            -o-animation: fadein 2s; /* Opera */
        }
        .idCard img:first-of-type {
            margin-left: 0px;
        }
        @keyframes fadein {
            from {
                opacity:0;
            }
            to {
                opacity:1;
            }
        }
        @-moz-keyframes fadein { /* Firefox */
            from {
                opacity:0;
            }
            to {
                opacity:1;
            }
        }
        @-webkit-keyframes fadein { /* Safari and Chrome */
            from {
                opacity:0;
            }
            to {
                opacity:1;
            }
        }
        @-o-keyframes fadein { /* Opera */
            from {
                opacity:0;
            }
            to {
                opacity: 1;
            }
        }
        
    </style>
@stop

@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('student.save_student')}}" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="branch_id" value="{{Auth::user()->branch->id}}">
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}} | Required <span class="text-danger">*</span></h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Student Name <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" id="student_name" autofocus value="{{old('student_name')}}" class="form-control {{$errors->has('student_name') ? 'border-danger' : ''}}" placeholder="Student Name" name="student_name">
                                    </div>
                                    <span class="offset-md-4 text-danger"></span>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Father Name <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" id="father_name" value="{{old('father_name')}}" class="form-control {{$errors->has('father_name') ? 'border-danger' : ''}}" placeholder="Father Name" name="father_name">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Contact No <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" id="contact_no" value="{{old('contact_no')}}" class="form-control  {{$errors->has('contact_no') ? 'border-danger' : ''}}" placeholder="Contact No" name="contact_no">
                                        @if($errors->has('contact_no'))
                                            <span class="text-danger ">{{ $errors->first('contact_no') }}</span>
                                        @endif
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput4">Emergency Contact <span class="text-danger">*</span></label>
                                        <div class="col-md-9">
                                            <input type="text" name="emergency" placeholder="Emergency Contact No" class="form-control {{ $errors->has('emergency') ? 'is-invalid' : '' }}" value="{{ old('emergency') }}">
                                            @if($errors->has('emergency'))
                                                <span class="text-danger">{{$errors->first('emergency')}}</span>
                                            @endif
                                        </div>
    
                                    </div>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Email <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="email" id="email" placeholder="Enter Student Email" value="{{old('email')}}" class="form-control {{$errors->has('email') ? 'border-danger' : ''}}"  name="email">
                                    </div>
                                    @if($errors->has('email'))
                                    <span class="text-danger offset-md-4">{{ $errors->first('emails') }}</span>
                                    @endif
                                    
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Date Of Birth <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="date" id="dateOfBirth" class="form-control date {{$errors->has('date_of_birth') ? 'border-danger' : ''}}"  name="date_of_birth">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Education <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <select class="form-control select2" name="education_id">
                                            <option value="">--Select Education--</option>
                                            @foreach($degress as $degree)
                                                <option value="{{$degree->id}}" @if(old('education_id') == $degree->id) selected @endif>{{$degree->name}}</option>
                                            @endforeach
                                        </select>
                                        @if($errors->has('education_id'))
                                            <span class="text-danger">{{$errors->first('education_id')}}</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">How you Find Us. ? <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <textarea class="form-control {{ $errors->has('find') ? 'is-invalid' : '' }}" name="find" cols="10" placeholder="How Student Find Us"> @if(old('find') != "") {{ old('find') }}  @endif</textarea>
                                        @if($errors->has('find'))
                                            <span class="text-danger">{{$errors->first('find')}}</span>
                                        @endif
                                    </div>

                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Address <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <textarea class="form-control" name="address" cols="10" placeholder="Student Address">@if(old('address') != "") {{ old('address') }} @endif</textarea>
                                    </div>
                                    @if($errors->has('address'))
                                        <span class="text-danger offset-md-4">{{$errors->first('address')}}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">ID Card No</label>
                                    <div class="col-md-9">
                                        <input type="text" name="id_card" value="{{old('id_card')}}" placeholder="ID Card No" class="form-control">
                                        @if($errors->has('id_card'))
                                            <span class="text-danger">{{$errors->first('id_card')}}</span>
                                        @endif
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Gender <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <label>Male &nbsp;&nbsp;<input type="radio" name="gender[]" value="male" checked></label>&nbsp;&nbsp;
                                        <label>Female &nbsp;&nbsp;<input type="radio" name="gender[]" value="female"></label>
                                        @if($errors->has('gender'))
                                            <div class="text-danger">{{$errors->first('gender')}}</div>
                                        @endif
                                    </div>

                                </div>
                                
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Reference By </label>
                                    <div class="col-md-9">
                                        <select class="select2 form-control" id="agent_id" name="agent_id">
                                            <option value="">--Select Agent --</option>
                                            @foreach($agents as $agent)
                                                <option value="{{ $agent->id }}">{{ $agent->name }}</option>
                                            @endforeach
                                        </select>
                                        @if($errors->has('reference'))
                                            <div class="text-danger">{{$errors->first('reference')}}</div>
                                        @endif
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Student Image <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <!-- Student Image-->
                                        <div class="form-group">
                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                <div class="fileinput-preview img-thumbnail" data-trigger="fileinput" style="width: 300px; height: 200px;">
                                                    <!-- Demo Image -->

                                                </div>
                                                <div>
                                            <span class="btn btn-outline-secondary btn-file">
                                              <span class="fileinput-new">Select image</span>
                                              <span class="fileinput-exists">Change</span>
                                              <input type="file" name="student_image">
                                            </span>
                                                    <a href="#" class="btn btn-outline-secondary fileinput-exists" data-dismiss="fileinput">Remove</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @if($errors->has('student_image'))
                                        <span class="text-danger offset-md-3">{{$errors->first('student_image')}}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row idCard">
                                    <label class="col-md-3 label-control" for="userinput3">ID Card Image </label>
                                    <div class="col-md-9">
                                        <input type="file" multiple id="images" class="form-control idCardImage {{$errors->has('idCardImage') ? 'border-danger' : ''}}"  name="idCardImage[]">
                                        <div class="images"></div>
                                    </div>
                                    @if($errors->has('idCardImage'))
                                    <span class="text-danger offset-md-4">
                                        {{$errors->first('idCardImage')}}
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Designation <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <select class="form-control {{ $errors->has('designation') ? 'is-invalid' : '' }}" name="designation" id="job_designation">
                                            <option value="">--Select Designation--</option>
                                            <option value="0" @if(old('designation') == 0 && old('designation') != '') selected @endif>Unemployeed</option>
                                            <option value="1" @if(old('designation') == 1) selected @endif>Employeed</option>
                                        </select>
                                        @if($errors->has('designation'))
                                            <div class="text-danger">{{$errors->first('designation')}}</div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="designation">
                            <h4 class="form-section"><i class="ft-settings"></i> Student Designation Detail</h4>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput1">Current Designation <span class="text-danger">*</span></label>
                                        <div class="col-md-9">
                                            <input type="text" id="current_designation" value="{{old('current_designation')}}" class="form-control {{$errors->has('current_designation') ? 'border-danger' : ''}}" placeholder="Current Designation" name="current_designation">
                                        </div>
                                        @if($errors->has('current_designation'))
                                            <span class="offset-md-4 text-danger">
                                                {{ $errors->first('current_designation') }}
                                            </span>
                                        @endif
                                        
                                    </div>
    
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput3">Company Name <span class="text-danger">*</span></label>
                                        <div class="col-md-9">
                                            <input type="text" id="company_name" value="{{old('company_name')}}" class="form-control {{$errors->has('company_name') ? 'border-danger' : ''}}" placeholder="Company Name" name="company_name">
                                        </div>
                                        @if($errors->has('compnay_name'))
                                            <span class="text-danger offset-md-4">
                                                {{ $errors->first('compnay_name') }}
                                            </span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput1">Company Country <span class="text-danger">*</span></label>
                                        <div class="col-md-9">
                                            <div class="input-group">
                                                <select name="country_id" class="form-control {{ $errors->has('country_id') ? 'is-invalid' : '' }}" id="country_id">
                                                    <option value="0">--Select Company Country--</option>
                                                </select>
                                            </div>
                                        </div>
                                        @if($errors->has('country_id'))
                                            <span class="offset-md-4 text-danger">
                                                {{ $errors->first('country_id') }}
                                            </span>
                                        @endif
                                        
                                    </div>
    
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput3">Company State <span class="text-danger">*</span></label>
                                        <div class="col-md-9">
                                            <div class="input-group">
                                                <select name="state_id" class="form-control {{ $errors->has('country_id') ? 'is-invalid' : '' }}" id="state_id">
                                                    <option value="0">--Select Company State--</option>
                                                </select>
                                                <span class="state_loader"></span>
                                            </div>
                                        </div>
                                        @if($errors->has('state_id'))
                                            <span class="text-danger offset-md-4">
                                                {{ $errors->first('state_id') }}
                                            </span>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput1">Company City <span class="text-danger">*</span></label>
                                        <div class="col-md-9">
                                            <div class="input-group">
                                                <select name="city_id" class="form-control {{ $errors->has('country_id') ? 'is-invalid' : '' }}" id="city_id">
                                                    <option value="0">--Select Company City--</option>
                                                </select>
                                                <span class="city_loader"></span>
                                            </div>
                                        </div>
                                        @if($errors->has('city_id'))
                                            <span class="offset-md-4 text-danger">
                                                {{ $errors->first('city_id') }}
                                            </span>
                                        @endif
                                        
                                    </div>
    
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput3">Student C.v</label>
                                        <div class="col-md-9">
                                            <input type="file" name="resume" class="form-control {{ $errors->has('resume') ? 'is-invalid' : '' }}">
                                        </div>
                                        @if($errors->has('resume'))
                                            <span class="text-danger offset-md-4">
                                                {{ $errors->first('resume') }}
                                            </span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Add Student" id="btnAdd" class="btn btn-primary">
                        {{--<input type="submit" value="Print Invoice" id="btnAdd" class="btn btn-success">--}}
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
    <script src="{{asset('js/jasny-bootstrap.min.js')}}"></script>
    <script src="{{asset('vendors/js/forms/select/select2.full.min.js')}}"></script>
    <script>
        var dueAmount = 0;
        $(document).ready(function (e) {
            $('.select2').select2();
            var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month + 1;
            if(month < 10) {
                month =  "0" +month;
            }
            if(fullDate < 10)
                fullDate = '0' + fullDate;


            $(".date").val(date.getFullYear() + "-" + month + "-" + fullDate);
            @if(old('designation') == '' || old('designation') == 0 )
                $("#designation").hide();
            @endif
            $("#job_designation").change(function(e) {
                var value = $("#job_designation").val();
                if(value == 1) {
                    $("#designation").fadeIn(1000);
                    $("#designation").show();
                    //get countries
                    $.ajax({
                        url:"{{ route('location.countries') }}",
                        dataType:'JSON',
                        type:'GET',
                        complete:function(jqXHR,textStatus) {
                            if(jqXHR.status == 200) {
                                var result = JSON.parse(jqXHR.responseText);
                                if(result.hasOwnProperty('success')) {
                                    var countries = result.countries;
                                    var output = "";
                                    countries.forEach(function(country) {
                                        output += "<option value='"+country.id+"'>"+country.name+"</option>";
                                    });
                                    $("#country_id > option ~ option").remove();
                                    $("#country_id").append(output);
                                }
                            } else {
                                toastr.error("Contact Admin "+jqXHR.status);
                            }
                        }
                    });                     
                } else {
                    $("#designation").fadeOut(1000)
                    
                }
            });
            $("#country_id").change(function(e) {
                $("#satte_id > option ~ option").remove();
                $("#city_id > option ~ option").remove();
                var id = $("#country_id").val();
                if(id == "" || id == 0) {
                    return;
                }
                var data = {
                    country_id:id,
                };
                $.ajax({
                    url:"{{ route('location.states') }}",
                    data:data,
                    dataType:'JSON',
                    type:'POST',
                    beforeSend:function(xhr) {
                        $(".state_loader").html(ajaxLoader);
                    },
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var states = result.states;
                                var output = "";
                                states.forEach(function(state) {
                                    output += "<option value='"+state.id+"'>"+state.name+"</option>";
                                });
                                $("#state_id > option ~ option").remove();
                                $("#state_id").append(output);
                                $(".state_loader").html("");
                            }
                        }
                    }
                }); 
            });
            $("#state_id").change(function(e) {
                $("#city_id > option ~ option").remove();
                var id = $("#state_id").val();
                if(id == "" || id == 0) {
                    return;
                }
                var data = {
                    state_id:id,
                };
                $.ajax({
                    url:"{{ route('location.cities') }}",
                    data:data,
                    dataType:'JSON',
                    type:'POST',
                    beforeSend:function(xhr) {
                        $(".city_loader").html(ajaxLoader);
                    },
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var cities = result.cities;
                                var output = "";
                                cities.forEach(function(city) {
                                    output += "<option value='"+city.id+"'>"+city.name+"</option>";
                                });
                                $("#city_id > option ~ option").remove();
                                $("#city_id").append(output);
                                $(".city_loader").html("");
                            }
                        }
                    }
                });
            })
        });
        function previewImages() {

            var $preview = $('.images').empty();
            if (this.files) $.each(this.files, readAndPreview);

            function readAndPreview(i, file) {

                if (!/\.(jpe?g|png|gif)$/i.test(file.name)){
                    return alert(file.name +" is not an image");
                } // else...

                var reader = new FileReader();

                $(reader).on("load", function() {
                    $preview.append($("<img/>", {src:this.result, height:100}));
                });

                reader.readAsDataURL(file);
            }
        }
        $('#images').on("change", previewImages);
        
    </script>

@stop

