@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="studentsData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Name</td>
                        <td data-column-id="paid">Paid Amount</td>
                        <td data-column-id="Payment_type">Payment Type</td>
                        <td data-column-id="created_at">Date</td>
                        <td data-column-id="actions" data-sortable="false">Actions</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach($instalments as $instalment)
                        <tr>
                            <td>{{$i++}}</td>
                            <td>{{$instalment->student->student_name}}</td>
                            <td>{{$instalment->paid_amount}}</td>
                            <td>{{ $instalment->payment->name }}</td>
                            <td>{{ $instalment->created_at->toFormattedDateString() }}</td>
                            <td><a href="{{ route('instalment.edit',['id'=>$instalment->id]) }}" class="ft-edit"></a><a href="{{ route('instalment.destroy',['id'=>$instalment->id]) }}" class="ft-trash" style="color:red; margin-left:10px;"></a><a href="#" class="ft-printer print" style="color:green;margin-left: 10px;" data-id="{{ $instalment->id }}"></a> </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#studentsData").DataTable();
            $(".print").click(function(e) {
                var id = $(this).attr("data-id");
                var route = "{{route('instalment.printInstalment','id')}}";
                route = route.replace('id',id);
                $.ajax({
                    url:route,
                    dataType:'JSON',
                    type:'GET',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                localStorage.instalments = JSON.stringify(result.instalments);
                                window.open("{{route('instalment.print')}}","_blank");
                            } else {
                                toastr.error("Opps Something Went Wrong");
                            }
                        }
                    }
                })
                   
            })
        })
    </script>
@stop