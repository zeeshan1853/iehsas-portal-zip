@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/forms/selects/select2.min.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('css/jasny-bootstrap.min.css')}}" rel="stylesheet" type="text/css">
    <style>
        .idCard img {
            margin-top:10px;
            margin-left: 5px;
            border:1px solid #9ea5b0;
            animation: fadein 3;
            -moz-animation: fadein 2s; /* Firefox */
            -webkit-animation: fadein 2s; /* Safari and Chrome */
            -o-animation: fadein 2s; /* Opera */
        }
        .idCard img:first-of-type {
            margin-left: 0px;
        }
        @keyframes fadein {
            from {
                opacity:0;
            }
            to {
                opacity:1;
            }
        }
        @-moz-keyframes fadein { /* Firefox */
            from {
                opacity:0;
            }
            to {
                opacity:1;
            }
        }
        @-webkit-keyframes fadein { /* Safari and Chrome */
            from {
                opacity:0;
            }
            to {
                opacity:1;
            }
        }
        @-o-keyframes fadein { /* Opera */
            from {
                opacity:0;
            }
            to {
                opacity: 1;
            }
        }
    </style>
@stop

@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('student.update',['id'=>$student->id])}}" enctype="multipart/form-data">
                    @csrf
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Student Name</label>
                                    <div class="col-md-9">
                                    <input type="text" id="student_name" autofocus @if(old('student_name')) value="{{old('student_name')}}" @else value="{{ $student->student_name }}" @endif class="form-control {{$errors->has('student_name') ? 'border-danger' : ''}}" placeholder="Student Name" name="student_name">
                                    </div>
                                    <span class="offset-md-4 text-danger"></span>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Father Name</label>
                                    <div class="col-md-9">
                                    <input type="text" id="father_name" @if(old('father_name')) value="{{ old('father_name')}}" @else value="{{ $student->father_name }}" @endif class="form-control {{$errors->has('father_name') ? 'border-danger' : ''}}" placeholder="Father Name" name="father_name">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Contact No</label>
                                    <div class="col-md-9">
                                        <input type="text" id="contact_no" @if(old('contact_no')) value="{{ old('contact_no')}}" @else value="{{ $student->contact_no }}" @endif class="form-control  {{$errors->has('contact_no') ? 'border-danger' : ''}}" placeholder="Contact No" name="contact_no">
                                        @if($errors->has('contact_no'))
                                            <span class="text-danger ">{{ $errors->first('contact_no') }}</span>
                                        @endif
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Emergency Contact</label>
                                    <div class="col-md-9">
                                    <input type="text" name="emergency" @if(old('emergency')) value="{{ old('emergency') }}" @else value="{{ $student->emergency }}" @endif placeholder="Emergency Contact No" class="form-control">
                                        @if($errors->has('emergency'))
                                            <span class="text-danger">{{$errors->first('emergency')}}</span>
                                        @endif
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Paid Amount</label>
                                    <div class="col-md-9">
                                    <input type="number" id="paid_amount" placeholder="Paid Amount" @if(old('paid_amount')) value="{{ old('paid_amount') }}" @else value="{{ $student->paid_amount }}" @endif class="form-control {{$errors->has('paid_amount') ? 'border-danger' : ''}}"  name="paid_amount">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Due Amount</label>
                                    <div class="col-md-9">
                                        <input type="number" id="dueAmount" @if(old('due_amount')) value="{{ old('due_amount') }}" @else value="{{ $student->due_amount }}" @endif class="form-control date {{$errors->has('due_amount') ? 'border-danger' : ''}}"  name="due_amount">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Email</label>
                                    <div class="col-md-9">
                                        <input type="email" id="email" placeholder="Enter Student Email" @if(old('email')) value="{{ old('email') }}" @else value="{{ $student->email }}" @endif class="form-control {{$errors->has('email') ? 'border-danger' : ''}}"  name="email">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Date Of Birth</label>
                                    <div class="col-md-9">
                                        <input type="date" id="dateOfBirth" @if(old('date_of_birth')) value="{{ old('date_of_birth') }}" @else value="{{ $student->date_of_birth }}" @endif class="form-control date {{$errors->has('date_of_birth') ? 'border-danger' : ''}}"  name="date_of_birth">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Education</label>
                                    <div class="col-md-9">
                                        <select class="form-control select2" name="education_id">
                                            <option value="">--Select Education--</option>
                                            @foreach($degress as $degree)
                                                @if($student->education_id == $degree->id)
                                                <option value="{{$degree->id}}" selected>{{$degree->name}}</option>
                                                @else 
                                                <option value="{{$degree->id}}">{{$degree->name}}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                        @if($errors->has('education_id'))
                                            <span class="text-danger">{{$errors->first('education_id')}}</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">How you Find Us. ?</label>
                                    <div class="col-md-9">
                                    <textarea class="form-control" name="find" cols="10" placeholder="How Student Find Us">{{ $student->find }}</textarea>
                                        @if($errors->has('find'))
                                            <span class="text-danger">{{$errors->first('find')}}</span>
                                        @endif
                                    </div>

                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Address</label>
                                    <div class="col-md-9">
                                    <textarea class="form-control" name="address" cols="10" placeholder="Student Address">{{ $student->address}}</textarea>
                                    </div>
                                    @if($errors->has('address'))
                                        <span class="text-danger offset-md-4">{{$errors->first('address')}}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">ID Card No</label>
                                    <div class="col-md-9">
                                        <input type="number" name="id_card"  @if(old('id_card')) value="{{ old('id_card') }}" @else value="{{ $student->id_card }}" @endif placeholder="ID Card No" class="form-control">
                                        @if($errors->has('id_card'))
                                            <span class="text-danger">{{$errors->first('id_card')}}</span>
                                        @endif
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            

                        </div>
                        <div class="row">
                            
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Gender</label>
                                    <div class="col-md-9">
                                        
                                        <label>Male &nbsp;&nbsp;<input type="radio" name="gender[]" value="male" @if($student->gender == "male") checked @endif></label>&nbsp;&nbsp;
                                        
                                        <label>Female &nbsp;&nbsp;<input type="radio" name="gender[]" value="female"@if($student->gender == "female") checked @endif> </label>
                                        @if($errors->has('gender'))
                                            <div class="text-danger">{{$errors->first('gender')}}</div>
                                        @endif
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Student Image</label>
                                    <div class="col-md-9">
                                        <!-- Student Image-->
                                        <div class="form-group">
                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                <div class="fileinput-preview img-thumbnail" data-trigger="fileinput" style="width: 300px; height: 200px;">
                                                    <!-- Demo Image -->
                                                    <img src="{{ asset($student->student_image) }}" alt="img">
                                                </div>
                                                <div>
                                            <span class="btn btn-outline-secondary btn-file">
                                              <span class="fileinput-new">Select image</span>
                                              <span class="fileinput-exists">Change</span>
                                              <input type="file" name="student_image">
                                            </span>
                                                    <a href="#" class="btn btn-outline-secondary fileinput-exists" data-dismiss="fileinput">Remove</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @if($errors->has('student_image'))
                                        <span class="text-danger offset-md-3">{{$errors->first('student_image')}}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row idCard">
                                    <label class="col-md-3 label-control" for="userinput3">ID Card Image:</label>
                                    <div class="col-md-9">
                                        <input type="file" multiple id="images" class="form-control idCardImage {{$errors->has('idCardImage') ? 'border-danger' : ''}}"  name="idCardImage[]">
                                        <div class="images">
                                            <img src="{{ asset($student->id_card_front) }}" style="heigth:100px; width:190px;" alt="id card front">
                                            <img src="{{ asset($student->id_card_back) }}" style="heigth:100px; width:190px;" alt="id card back">
                                        </div>
                                    </div>
                                    @if($errors->has('idCardImage'))
                                    <span class="text-danger offset-md-4">
                                        {{$errors->first('idCardImage')}}
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Update Student" id="btnAdd" class="btn btn-primary">
                        {{--<input type="submit" value="Print Invoice" id="btnAdd" class="btn btn-success">--}}
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
    <script src="{{asset('js/jasny-bootstrap.min.js')}}"></script>
    <script src="{{asset('vendors/js/forms/select/select2.full.min.js')}}"></script>
    <script>
        var dueAmount = 0;
        $(document).ready(function (e) {
            $('.select2').select2();
            /*
            var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month + 1;
            if(month < 10) {
                month =  "0" +month;
            }
            if(fullDate < 10)
                fullDate = '0' + fullDate;


            $(".date").val(date.getFullYear() + "-" + month + "-" + fullDate);
            */
        });
        $("#batch_id").change(function (e) {
            dueAmount = $('option:selected',this).data('amount');
            $("#dueAmount").val(dueAmount);
        });
        function previewImages() {

            var $preview = $('.images').empty();
            if (this.files) $.each(this.files, readAndPreview);

            function readAndPreview(i, file) {

                if (!/\.(jpe?g|png|gif)$/i.test(file.name)){
                    return alert(file.name +" is not an image");
                } // else...

                var reader = new FileReader();

                $(reader).on("load", function() {
                    $preview.append($("<img/>", {src:this.result, height:100}));
                });

                reader.readAsDataURL(file);

            }

        }
        $('#images').on("change", previewImages);
    </script>

@stop

