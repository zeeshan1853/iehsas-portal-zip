<html>
    <head>
        <title>Registration Form</title>
        <link href="{{ asset('css/print.css') }}" rel="stylesheet" type="text/css" media="all">
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
    </head>
    <body>
        <main>
            <div id="main">
                <div id="content">
                    <div id="header">
                        <div id="logo">
                            <img src="{{ asset(Auth::user()->branch->setting->logo) }}" alt="logo">
                            <p><b>Office:</b> {{ $setting->address }} <b>Country:</b>  {{ $setting->country }}. Cell # {{ $setting->mobile_no }} Phone # {{ $setting->phone_no }} 
                            <b>Website:</b> www.iehsas.com  <b>Email:</b>{{ $setting->email }}
                            </p>
                        </div>
                        <div id="student_image">
                        <img src="{{ asset($student->student_image)}}">
                        </div>
                        <br clear="all">
                        <center><h1 style="margin-top:0px;">REGISTRATION FORM</h1></center>
                        <p class="date">Date.<u>{{date("Y-m-d",strtotime($student->created_at))}}</u></p>
                        <p class="registeration">Registration No.<u>{{ $student->id }}</u></p>
                        <br clear="all">
                        <hr class="border">
                    </div>
                    <div id="courses">
                        <section>
                            <p>Training title in which student Enroll. </p>
                            <table border="1px">
                                <tr>
                                    <th>Sr.</th>
                                    <th>Course Name</th>
                                    <th>Batch Name</th>
                                    <th>Nebosh ID</th>
                                    <th>Fresh / Resit</th>
                                    <th>Enrolment Date</th>
                                    <th>Training Date</th>
                                    <th>Course Price</th>
                                    <th>Exam Dates</th>
                                </tr>
                                <?php
                                    $i=1;
                                ?>
                                @foreach($student->courses as $course)
                                <tr>
                                    <td>{{$i++}}</td>
                                    <td>{{ $course->course->course_name}} </td>
                                <td>{{ $course->batch->batch_name }}</td>
                                <td>{{ $course->nebosh_student_id == "" ? "N/A" : $course->nebosh_student_id }}</td>
                                <td>
                                    @if($course->fresh_resit == "")
                                        N/A
                                    @elseif($course->fresh_resit == "0")
                                        Fresh
                                    @else
                                        Resit
                                    @endif
                                </td>
                                <td>{{ $course->admission_date->toFormattedDateString() }}</td>
                                <td>{{ $course->batch->start_date->toFormattedDateString() }}<br>{{ $course->batch->end_date->toFormattedDateString() }}</td>
                                <td>{{ $course->fresh_resit == 0 ? $course->batch->course_price : $course->resit_fee }}</td>
                                <td style="width:14%;">
                                    @foreach($course->examDates as $date)
                                        
                                            {{ $date->exam_date->toFormattedDateString() }}
                                            @if($date->willing == 1)
                                            <span class="fa fa-check"></span><br>
                                            @else
                                            <span class="fa fa-times"></span><br>
                                            @endif
                                        
                                    @endforeach
                                </td>
                                </tr>
                                @endforeach
                            </table>
                        </section>
                    </div>
                    <div id="student_info">
                        <center><h3>STUDENT INFORMATION</h3></center>
                        <table >
                            <tr>
                                <td>Candidate Name</td>
                                <td>{{ $student->student_name }}</td>
                                <td>Date Of Birth</td>
                                <td>{{ $student->date_of_birth }}</td>
                            </tr>
                            <tr>
                                <td>National ID Card</td>
                                @if(empty($student->id_card))
                                    <td>N/A</td>
                                @else 
                                    <td>{{ $student->id_card }}</td>
                                @endif
                                
                                <td>Email Address</td>
                                <td>{{ $student->email }}</td>
                            </tr>
                            <tr>
                                <td>Father Name</td>
                                <td>{{ $student->father_name }}</td>
                                <td>Gender</td>
                                <td>
                                    <label for="male">Male<input type="checkbox" @if($student->gender == "male") checked @endif></label>
                                    <label for="female">Female<input type="checkbox" @if($student->gender == "female") checked @endif></label>
                                </td>
                            </tr>
                            <tr>
                                <td>Mobile No</td>
                                <td>{{ $student->contact_no }}</td>
                                <td>Emergency No.</td>
                                <td>{{ $student->emergency }}</td>
                            </tr>
                            <tr>
                                <td>Qualifications</td>
                                <td colspan="3"><center>{{ $student->education->name }}</center></td>
                            </tr>
                            <tr>
                                <td>Home Address</td>
                                <td colspan="3"><center>{{ $student->address }}</center></td>
                            </tr>
                            <tr>
                                <td>How You Find Us ?</td>
                                <td colspan="3"><center>{{ $student->find }}</center></td>
                            </tr>
                            <tr>
                                <td colspan="2"><b><center>Documents Attached</center></b></td>
                                <td colspan="2"><b><center>Method Of Payment</center></b></td>
                            </tr>
                            <tr class="documents">
                                <td>Copy Of Cnic / Form B</td>
                                <td><input type="checkbox"></td>
                                <td>Cash</td>
                                <td><input type="checkbox"></td>
                            </tr>
                            <tr class="documents">
                                <td colspan="1">Education Certification</td>
                                <td><input type="checkbox"></td>
                                <td colspan="1">Cheque</input>
                                <td><input type="checkbox"></td>
                            </tr>
                            <tr class="documents">
                                <td colspan="1">One Photograph</td>
                                <td><input type="checkbox"></td>
                                <td colspan="1">Bank Transfer</td>
                                <td><input type="checkbox"></td>
                            </tr>
                            <tr class="documents">
                                <td colspan="2">Comments:</td>
                                <td colspan="1">Credit</td>
                                <td><input type="checkbox"></td>
                            </tr>
                        </table>
                    </div>
                    <div id="insitute">
                        <br>
                        <center><h3 class="title">For Training Insitute Use Only</h3></center>
                        <div id="info">
                            <table>
                                <tr>
                                    <td colspan="2"><b>Form</b></td>
                                    <td></td>
                                    <td>Approved <input type="checkbox"></td>
                                    <td>Rejected <input type="checkbox"></td>
                                </tr>
                                <tr>
                                    <td colspan="2"><b>ID Card</b></td>
                                    <td></td>
                                    <td><img src="{{ asset('images/cards/front.jpg') }}" width="300px"></td>
                                    <td><img src="{{ asset('images/cards/back.jpg') }}" width="300px"></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div id="footer">
                        <table>
                            <tr>
                                <td><span style="border-top:1px solid black;">Executive Signature</span> </td>
                                <td><span style="border-top:1px solid black;">Candidiate Signature</span> </td>
                                <td><span style="border-top:1px solid black;">Admin Signature</span></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </main>
        
    </body>
</html>
<script>
    window.print();

</script>