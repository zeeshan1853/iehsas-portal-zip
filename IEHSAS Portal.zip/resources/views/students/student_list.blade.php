@extends('layouts.app')

@section('header-styles')

@stop


@section('main')
    <div id="app">
        <student-component></student-component>
    </div>
@stop


@section('footer-scripts')
<script> window.Laravel = { csrfToken : '{{ csrf_token() }} ',asset:'{{ asset('/') }}',path:'{{ url('') }}'}</script>
<script>
    var ajaxLoading = "<img src='{{ asset('images/loader.gif') }}' style='width:70px;'>";
</script>
<script src="{{ asset('js/app.js') }}"></script>
@stop