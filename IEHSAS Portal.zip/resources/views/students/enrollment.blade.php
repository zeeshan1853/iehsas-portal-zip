@extends('layouts.app')

@section('header-styles')
    <link href="{{asset('vendors/css/forms/selects/select2.min.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('css/jasny-bootstrap.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
    <div id="app">
        <enrolment></enrolment>
    </div>
@stop

@section('footer-scripts')

    <script src="{{asset('vendors/js/forms/select/select2.full.min.js')}}"></script>
    <script src="{{asset('js/jasny-bootstrap.min.js')}}"></script>
    <script> window.Laravel = { csrfToken : '{{ csrf_token() }} ',asset:'{{ asset('/') }}',path:'{{ url('admin/') }}'}</script>
    <script src="{{ asset('js/app.js') }}"></script>
    <script>
        $(document).ready(function () {
            setTimeout(()=>{
                var body = document.getElementsByTagName('body')[0];
                body.classList.remove('menu-expanded');
                body.classList.add("menu-collapsed");
            },1000)
            
        });

    </script>

@stop