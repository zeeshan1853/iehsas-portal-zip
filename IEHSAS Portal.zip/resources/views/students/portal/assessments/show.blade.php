@extends('layouts.app_student')

@section('styles')

@stop

@section('content')
<div class="row">
    <div class="card col-md-12">
        <div class="card-body">
            <table class="table table-striped text-center">
                <thead>
                    <tr class="bg-primary text-white" >
                        <th>Sr.No</th>
                        <th>Assessment No</th>
                        <th>Total marks</th>
                        <th>Obatain Marks</th>
                        <th>Remarks / Improvements</th>
                        <th>Percentage</th>
                    </tr>
                </thead>
                <tbody>
                    @php 
                    $i = 1; 
                    $percentage = 0; 
                    $total_marks = 0;
                    $total_obtain = 0;
                    @endphp
                    @if(count($reports) == 0)
                        <tr>
                            <td colspan="5">No Result Found</td>
                        </tr>
                    @else
                        @foreach($reports as $report)
                        <tr>
                            <td>{{ $i }}</td>
                            <td>Test {{ $i++ }}</td>
                            @if($report != null) 
                                <td> {{ $report->batchAssessment->total_marks }} </td>
                            @else
                                <td>N/A</td>
                            @endif
                            <td>{{ $report != null ? $report->obtain_marks : "N/A" }}</td>
                            <td>{{ $report->remarks == "" ? "N/A" : $report->remarks}}</td>
                            @if($report != null)
                                <td>
                                    {{( $report->obtain_marks / $report->batchAssessment->total_marks) * 100 }} 
                                </td>
                            @else
                                <td>N/A</td>
                            @endif
                            </tr>
                            @php
                                $report != null ? $total_marks += $report->batchAssessment->total_marks : 0;
                                $report != null ? $total_obtain += $report->obtain_marks : 0;
                            @endphp
                        @endforeach
                    @endif
                    
                </tbody>
                <tfoot >
                    <tr class="bg-info text-white">
                        <td class="text-bold-600">Total</td>
                        <td></td>
                        <td class="text-bold-600">{{ $total_marks }}</td>
                        <td class="text-bold-600">{{ $total_obtain }}</td>
                        <td></td>
                        @if($total_marks != 0  && $total_obtain != 0)
                        <td class="text-bold-600">{{ round((($total_obtain / $total_marks) * 100),2) }}</td>
                        @else
                        <td>0</td>
                        @endif
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
@stop

@section('scripts')

@stop