@extends('layouts.app_student')

@section('styles')

@stop


@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-content collpase show">
                <div class="card-body">
                    <form class="form form-horizontal" method="POST" action="{{ route('complain.store') }}" enctype="multipart/form-data">
                        {{ csrf_field() }}
                        <div class="form-body">
                            <h4 class="form-section"><i class="fa fa-envelope"></i> Complain / Suggestion Form</h4>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="document">Course Name :</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <select class="form-control" name="course_id">
                                            <option value=""> --Select Course --</option>
                                            @foreach($courses as $course)
                                                <option value="{{ $course->id }}">{{ $course->course_name }}</option>
                                            @endforeach
                                        </select>
                                        <div class="form-control-position">
                                            <i class="fa fa-list"></i>
                                        </div>
                                    </div>
                                    @if($errors->has('course_id'))
                                    <span class="text-danger">{{ $errors->first('course_id') }}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="document">Complain / Suggestion :</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <textarea class="form-control" name="complain" placeholder="Enter Complain / Suggestion" rows="10"></textarea>
                                        <div class="form-control-position">
                                            <i class="fa fa-exclamation-circle"></i>
                                        </div>
                                    </div>
                                    @if($errors->has('complain'))
                                    <span class="text-danger">{{ $errors->first('complain') }}</span>
                                    @endif
                                </div>
                            </div>
                        </div>

                        <div class="form-actions">
                            <center>
                                <button type="submit" class="btn btn-primary" id="upload">Submit</button>
                            </center>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@stop

@section('scripts')

@stop