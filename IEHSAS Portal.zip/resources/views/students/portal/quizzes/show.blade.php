@extends('layouts.app_student')

@section('styles')


@stop

@section('content')
<div class="row">
    <div class="card col-md-6 offset-md-3">
        <div class="card-header bg-primary  text-bold-600 text-center">
            <h3 class="text-white">Batch Quiz</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <h3 class="col-md-5 col-sm-5">Deadline</h3>
                |
                <h3 class="col-md-5 col-sm-5 text-center"> {{ $quiz->deadline->toFormattedDateString() }}</h3>
            </div>
            <hr>
            <div class="row">
                <h3 class="col-md-5 col-sm-5">Quiz Marks</h3>
                |
                <h3 class="col-md-5 text-center col-sm-5"> {{ $quiz->total_marks }}</h3>
            </div>
            <hr>
            <hr>
            <div class="row">
                <h3 class="col-md-5 col-sm-5">Time</h3>
                |
                <h3 class="col-md-5 text-center col-sm-5"> 
                    @php 
                    $time = preg_split("/:/",$quiz->time); 
                    echo($time[0]." : ".$time[1]." Hours");
                    @endphp 
                </h3>
            </div>
            <hr>
            <h3 class="text-danger">Note:</h3>
            <h4>You have to submit yout quiz before Deadline ({{ $quiz->deadline->toFormattedDateString() }}).
                And the time that is available to solve this quiz is 
                @php 
                $time = preg_split("/:/",$quiz->time); 
                echo($time[0]." : ".$time[1]." Hours");
                @endphp 
                The quiz is not submit after deadline or if you take more time than expected one to solve. After you click download the timmer starts
            </h4>
            <h2 class="text-danger text-center">
                <span id="time"></span>
            </h2>
        </div>
        <div class="card-footer">
            <a href="{{ asset($quiz->document) }}" target="_blank" class="btn btn-primary col-md-6 offset-md-3 col-sm-6 offset-sm-3" id="download">Download</a>
            <a href="{{ route('studentQuiz.create',['id'=>$quiz->id]) }}" class="btn btn-primary col-md-6 offset-md-3 col-sm-6 offset-sm-3" id="upload">Upload</a>
        </div>
    </div>
</div>

@stop

@section('scripts')
<script>
    
    document.getElementById("upload").style.display = "none";
    function startTimer(duration, display) {
        var timer = duration, minutes, seconds;
        
        var inte = setInterval(function () {
            localStorage.duration = timer;
            if(localStorage.duration != "" && localStorage.duration != 0) {
                timer = localStorage.duration;
                
            }    
            minutes = parseInt(timer / 60, 10);
            seconds = parseInt(timer % 60, 10);
    
            minutes = minutes < 10 ? "0" + minutes : minutes;
            seconds = seconds < 10 ? "0" + seconds : seconds;
            
            localStorage.minutes = minutes;
            localStorage.seconds = seconds;
            
            display.textContent = minutes + ":" + seconds;
    
            if (--timer < 0) {
                
                display.textContent = "Times Up !!";
                clearInterval(inte);
                localStorage.duration = timer;
                document.getElementById("upload").style.display = "none";
            }
            localStorage.duration = timer;
            
            
        }, 1000);
    }
    var doc = document.getElementById("download");
    doc.addEventListener("click",(e)=>{
        e.preventDefault();
        
        var url = doc.getAttribute("href")
        var link = document.createElement('a');
        link.href = url;
        link.download = 'Quiz.pdf';
        link.dispatchEvent(new MouseEvent('click'));
        @php 
        $time = preg_split("/:/",$quiz->time); 
        $min = $time[0] * 60;
        $sec = $min*60;

        $min = $time[1] * 60;
        $sec += $min;
        @endphp 
        var time = {{ $sec }} ;
        
        display = document.querySelector('#time');
        
       startTimer(time, display);
       document.getElementById("download").style.display = "none";
       document.getElementById("upload").style.display = "block";
    });
    
    
    window.onload = function() {
        if(localStorage.duration == -1) {
            document.getElementById("download").style.display = "none";
            document.getElementById("upload").style.display = "none";
        }
        else if(localStorage.duration != "" || localStorage.duration != 0) {
            document.getElementById("download").style.display = "none";
            document.getElementById("upload").style.display = "block";
            time = localStorage.duration;          
            display = document.querySelector('#time');
            startTimer(time, display);
        }
    }
</script>

@stop

