@extends('layouts.app_student')

@section('styles')

@stop

@section('content')
<div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-content collpase show">
                    <div class="card-body">
                        <form class="form form-horizontal" method="POST" action="{{ route('studentQuiz.store') }}" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            <input type="hidden" name="quiz_id" value="{{ Route::input('id') }}">
                            <div class="form-body">
                                <h4 class="form-section"><i class="ft-user"></i> Upload Batch Quiz</h4>
                                <div class="form-group row">
                                    <label class="col-md-2 label-control" for="document">Quiz Document :</label>
                                    <div class="col-md-8">
                                        <div class="position-relative has-icon-left">
                                            <input type="file" id="document" class="form-control {{ $errors->has('document') ? 'is-invalid' : '' }}" name="document">
                                            <div class="form-control-position">
                                                <i class="fa fa-sticky-note"></i>
                                            </div>
                                        </div>
                                        @if($errors->has('document'))
                                        <span class="text-danger">{{ $errors->first('document') }}</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
    
                            <div class="form-actions">
                                <center>
                                    <button type="submit" class="btn btn-primary" id="upload">Upload</button>
                                </center>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop

@section('scripts')
<script>
    $(document).ready(function(e) {
        $("#upload").click(function(e) {
            localStorage.duration = "";
        });
    });
</script>
@stop
