@extends('layouts.app_student')

@section('styles')

@stop


@section('content')
<div class="row">
        <div class="col-xl-3 col-lg-6 col-12">
            <a href="#">
                <div class="card bg-info">
                    <div class="card-content">
                        <div class="card-body">
                            <div class="media d-flex">
                                <div class="align-self-center">
                                    <i class="icon-rocket text-white font-large-2 float-left"></i>
                                </div>
                                <div class="media-body text-white text-right">
                                    <h3 class="text-white">{{ $courses }}</h3>
                                    <span>Registered Courses</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-xl-3 col-lg-6 col-12">
            <a href="#">
                <div class="card bg-danger">
                    <div class="card-content">
                        <div class="card-body">
                            <div class="media d-flex">
                                <div class="align-self-center">
                                    <i class="icon-pie-chart text-white font-large-2 float-left"></i>
                                </div>
                                <div class="media-body text-white text-right">
                                    <h3 class="text-white">{{ $due }}</h3>
                                    <span>Dues Remaining</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </div>
</div>
@stop


@section('scripts')

@stop

