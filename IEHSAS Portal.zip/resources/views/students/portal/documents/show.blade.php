@extends('layouts.app_student')

@section('styles')
<style>
</style>
@stop

@section('content')
<div class="col-lg-12 col-md-12 col-xl-12">
    <div id="accordionWrap2" role="tablist" aria-multiselectable="true">
        <div class="card-header text-bold-700 text-center bg-info text-white" style="font-size:22px;padding:10px;">
          {{ $course->course_name }} Documents
        </div>
        <div class="card collapse-icon accordion-icon-rotate left" style="height: auto;">
            @if($types->count() == 0)
            <h3 class="text-danger mt-2 text-center">No Document Found</h3>
            @else
            @foreach($types as $filed=>$type)
            <div id="heading{{ $filed+1 }}" class="card-header type">
                <a data-toggle="collapse" data-parent="#accordionWrap2" href="#accordion{{ $filed+1 }}" aria-expanded="false"
                    aria-controls="accordion{{ $filed+1 }}" class="collapsed " style="font-size:20px;">
                     &nbsp;{{ $type->name }} <span class="fa fa-book"></span>
                </a>
            </div>
            <div id="accordion{{ $filed+1 }}" role="tabpanel" aria-labelledby="heading{{ $filed+1 }}" class="collapse" style="">
                <div class="card-content">
                    <div class="card-body" style="font-size:15px;">
                        <table class="table table-striped">
                            <thead class="bg-info">
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Document</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if($type->documents->count() == 0)
                                    <tr>
                                        <td colspan="3" class="text-center">No Document Found</td>
                                    </tr>
                                @else
                                    @php $i = 1; @endphp
                                    @foreach($type->documents as $document)
                                        <tr>
                                            <td>{{ $i++ }}</td>
                                            <td>{{ $document->name }}</td>
                                            <td>
                                                <a href="{{ asset($document->document) }}" title="Click to Download" class="btn btn-sm btn-info">Download <i class="fa fa-download"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    @endforeach

                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <hr>
            @endforeach

            @endif
        </div>
    </div>
</div>
@stop

@section('scripts')

@stop