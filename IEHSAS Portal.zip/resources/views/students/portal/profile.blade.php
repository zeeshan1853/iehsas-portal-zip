@extends('layouts.app_student')

@section('styles')
<link rel="stylesheet" type="text/css" href="{{ asset('student-portal/app/css/pages/users.min.css') }}">
<style>
    .bor{
        border-right:1px solid #CDCDCE;
    }
</style>
@stop

@section('content')
<div class="col-md-6 offset-md-3">
    <div class="card card">
        <div class="text-center">
            <div class="card-body">
                <img src="{{ asset($student->student_image) }}" class="rounded-circle  height-150" alt="Card image">
            </div>
            <div class="card-body">
                <h2 class="text-bold-600">{{ ucfirst($student->student_name) }} {{ ucfirst($student->father_name) }}</h4>
            </div>
        </div>
        <div class="list-group list-group-flush text-bold-500 ">
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-user"></i> Student Name</span>
                <span class="col-md-6 offset-md-0">{{ ucfirst($student->student_name) }}</span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-user-plus"></i> Father Name</span>
                <span class="col-md-6 offset-md-0">{{ ucfirst($student->father_name) }}</span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-phone"></i> Contact No</span>
                <span class="col-md-6 offset-md-0">{{ $student->contact_no }}</span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-mail"></i> Email</span>
                <span class="col-md-6 offset-md-0">{{ $student->email }}</span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-calendar"></i> Date Of Brith</span>
                <span class="col-md-6 offset-md-0">{{ $student->date_of_birth->toFormattedDateString() }}</span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-info"></i> Education</span>
                <span class="col-md-6 offset-md-0">{{ $student->education->name }}</span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-mail"></i> Gender</span>
                <span class="col-md-6 offset-md-0">{{ ucfirst($student->gender) }}</span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-smartphone"></i> Emergency Contact No</span>
                <span class="col-md-6 offset-md-0">{{ ucfirst($student->emergency) }}</span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor">
                    @if($student->id_card_front != "")
                    <a href="{{ url($student->id_card_front) }}" target="_blank"><img src="{{ asset($student->id_card_front) }}" style="width:150px;"></a>
                    @endif
                </span>
                <span class="col-md-6 offset-md-0 col-sm-6">
                    @if($student->id_card_back)
                    <a href="{{ url($student->id_card_back) }}" target="_blank"><img src="{{ asset($student->id_card_back) }}" style="width:150px;"></a>
                    @endif
                </span>
            </li>
        </div>
    </div>
</div>

@stop


@section('scripts')

@stop


