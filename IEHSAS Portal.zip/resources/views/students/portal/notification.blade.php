@extends('layouts.app_student')

@section('styles')
<link rel="stylesheet" type="text/css" href="{{ asset('student-portal/app/css/core/colors/palette-callout.min.css') }}">
<style>
    .form-section {
        color: #1D2B36;
        line-height: 3rem;
        margin-bottom: 20px;
        border-bottom: 1px solid #1D2B36;
    }
</style>

@stop


@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                    <h4 class="form-section"><i class="ft-alert-circle"></i> New Notifications</h4>
                    @if($notifications->count() == 0)
                    <div class="bs-callout-danger callout-transparent callout-bordered mt-1">
                        <div class="media align-items-stretch">
                            <div class="media-left media-middle bg-danger position-relative callout-arrow-left p-2">
                                <i class="icon-close white font-medium-5"></i>
                            </div>
                            <div class="media-body p-1">
                                <strong>No New Notification To Read!</strong>
                            </div>
                        </div>
                    </div>
                    @else 
                        @foreach($notifications as $notification)
                        <a href="{{ $notification['data']['url'] }}">
                            <div class="bs-callout-success callout-transparent callout-bordered mt-1">
                                <div class="media align-items-stretch">
                                    <div class="media-left d-flex align-items-center bg-success position-relative callout-arrow-left p-2">
                                        <i class="{{ $notification['data']['icon'] }} white font-medium-5"></i>
                                    </div>
                                    <div class="media-body p-1">
                                        <strong>{{ $notification['data']['heading'] }}!</strong>
                                        <div class="row">
                                            <p class="col-md-10">{{ $notification['data']['message'] }}</p>
                                            <p class="col-md-2 text-right ">
                                                <span class="ft-clock text-bold-600"> {{ $notification->created_at->diffForHumans() }}</span>
                                            </p>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>

                        </a>
                            {{ $notification->markAsRead() }}
                        @endforeach

                    @endif
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                    <h4 class="form-section "><i class="ft-check-circle"></i> Read Notifications</h4>
                    @if($read_notifications->count() == 0)
                    <div class="bs-callout-danger callout-transparent callout-bordered mt-1">
                        <div class="media align-items-stretch">
                            <div class="media-left media-middle bg-danger position-relative callout-arrow-left p-2">
                                <i class="icon-close white font-medium-5"></i>
                            </div>
                            <div class="media-body p-1">
                                <strong>No Read Notification To Show!</strong>
                            </div>
                        </div>
                    </div>
                    @else 
                        @foreach($read_notifications as $notification)
                        <a href="{{ $notification['data']['url'] }}">
                            <div class="bs-callout-success callout-transparent callout-bordered mt-1">
                                <div class="media align-items-stretch">
                                    <div class="media-left d-flex align-items-center bg-success position-relative callout-arrow-left p-2">
                                        <i class="{{ $notification['data']['icon'] }} white font-medium-5"></i>
                                    </div>
                                    <div class="media-body p-1">
                                        <strong>{{ $notification['data']['heading'] }}!</strong>
                                        <p>{{ $notification['data']['message'] }}</p>
                                        <hr>
                                        <p>
                                            <span class="read_at pull-left">
                                                <i class="ft-check-circle text-bold-600"> {{ $notification->read_at->diffForHumans() }}</i>
                                            </span>
                                            <span class="read_at pull-right">
                                                <i class="ft-clock text-bold-600"> {{ $notification->created_at->diffForHumans() }}</i>
                                            </span>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </a>
                        @endforeach

                    @endif
            </div>
        </div>
    </div>
</div>
@stop


@section('scripts')

@stop

