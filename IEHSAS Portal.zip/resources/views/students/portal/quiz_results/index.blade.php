@extends('layouts.app_student')

@section('styles')

@stop

@section('content')
<div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-striped">
                    <thead class="bg-amber">
                        <tr>
                            <td>Sr.No</td>
                            <td>Total Marks</td>
                            <td>Obtain Marks</td>
                            <td>Percentage</td>
                        </tr>
                    </thead>
                    <tbody>
                        @if(count($results) == 0)
                            <tr>
                                <td colspan="4">No Result Found</td>
                            </tr>
                        @else
                            @php $i=1; @endphp
                            @foreach($results as $result)
                                <tr>
                                    <td>{{ $i++ }}</td>
                                    <td>{{ $result == null ? "N/A" : $result->quiz->total_marks }}</td>
                                    <td>{{ $result == null ? "N/A" : $result->obtain_marks }}</td>
                                    @if($result != null) 
                                        <td>{{ round(($result->quiz->total_marks / $result->obtain_marks) * 100,2) }}</td>
                                    @else
                                        <td>N/A</td>
                                    @endif
                                </tr>
                            @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
</div>
@stop

@section('scripts')

@stop