@extends('layouts.app_student')

@section('styles')
<link rel="stylesheet" type="text/css" href="{{ asset('student-portal/app/css/plugins/forms/wizard.min.css') }}">
@stop

@section('content')
<section id="validation">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-content collapse show">
                    <div class="card-body">
                        <form action="#" class="steps-validation wizard-circle">
                            <input type="hidden" name="student_course_id"
                                value="{{ collect(request()->segments())->last() }}">
                            <!-- Step 1 -->
                            <h6>Step 1</h6>
                            <fieldset>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="location1" class="">1. Did the tutor explain well the
                                                qualification overview </label>
                                            <br>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label>1. Satisfactory</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="1" class="overview required"
                                                        name="overview[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label>2.Not Satisfied</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="0" class="overview required"
                                                        name="overview[]">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="suggesion">Remarks /Improvement Plan</label>
                                            <textarea class="form-control" name="overview_remarks"
                                                placeholder="Enter Remarks.." rows="5"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="location1" class="">2. Did the tutor explain well about the
                                                command words ? </label>
                                            <br>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label>1. Satisfactory</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="1" class="words required" name="words[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label>2.Not Satisfied</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="0" class="words required" name="words[]">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="suggesion">Remarks /Improvement Plan</label>
                                            <textarea class="form-control" name="words_remarks"
                                                placeholder="Enter Remarks.." rows="5"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>

                            <!-- Step 2 -->
                            <h6>Step 2</h6>
                            <fieldset>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="location1" class="">3. How well the tutor presents the relevant
                                                videos ? </label>
                                            <br>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label>1. Satisfactory</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="1" class="video required" name="video[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label>2.Not Satisfied</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="0" class="video required" name="video[]">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="suggesion">Remarks /Improvement Plan</label>
                                            <textarea class="form-control" name="video_remarks"
                                                placeholder="Enter Remarks.." rows="5"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="location1" class="">4. Did the tutor explain well examination
                                                pattern ? </label>
                                            <br>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label>1. Satisfactory</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="1" class="examination required"
                                                        name="examination[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label>2.Not Satisfied</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="0" class="examination required"
                                                        name="examination[]">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="suggesion">Remarks /Improvement Plan</label>
                                            <textarea class="form-control" name="examination_remarks"
                                                placeholder="Enter Remarks.." rows="5"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>

                            <!-- Step 3 -->
                            <h6>Step 3</h6>
                            <fieldset>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="location1" class="text-bold-600">5. How did the tutor teach IGC
                                                1 ? </label>
                                            <br>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label>1. Satisfactory</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="1" class="teach required" name="teach[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label>2.Not Satisfied</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="0" class="teach required" name="teach[]">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="suggesion text-bold-600">Remarks /Improvement Plan</label>
                                            <textarea class="form-control" name="teach_remarks"
                                                placeholder="Enter Remarks.." rows="5"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="location1" class="text-bold-600">6. Did the tutor explain well
                                                the management system cycle ? </label>
                                            <br>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label>1. Satisfactory</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="1" class="cycle required" name="cycle[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label>2.Not Satisfied</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="0" class="cycle required" name="cycle[]">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="suggesion text-bold-600">Remarks /Improvement Plan</label>
                                            <textarea class="form-control" name="cycle_remarks"
                                                placeholder="Enter Remarks.." rows="5"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>

                            <!-- Step 4 -->
                            <h6>Step 4</h6>
                            <fieldset>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="location1" class="">7. Did the tutor give learner the homework
                                                assignments ? </label>
                                            <br>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label>1. Satisfactory</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="1" class="homework required"
                                                        name="homework[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label>2.Not Satisfied</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="0" class="homework required"
                                                        name="homework[]">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="suggesion ">Remarks /Improvement Plan</label>
                                            <textarea class="form-control" name="homework_remarks"
                                                placeholder="Enter Remarks.." rows="5"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="location1" class="">7. Did the learner participate into group
                                                discussion ? </label>
                                            <br>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label>1. Satisfactory</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="1" class="discussion required"
                                                        name="discussion[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <label>2.Not Satisfied</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="0" class="discussion required"
                                                        name="discussion[]">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="suggesion">Remarks /Improvement Plan</label>
                                            <textarea class="form-control" name="discussion_remarks"
                                                placeholder="Enter Remarks.." rows="5"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@stop

@section('scripts')
<script src="{{ asset('student-portal/app/vendors/js/extensions/jquery.steps.min.js') }}"></script>
<script src="{{ asset('student-portal/app/vendors/js/forms/validation/jquery.validate.min.js') }}"></script>
<script src="{{ asset('student-portal/app/js/scripts/forms/wizard-steps-random.min.js') }}"></script>
<script>
    var route = "{{ route("random.store",":id") }}";
    route = route.replace(":id",{{ Route::input('id') }});
    console.log(route);
    window.Laravel = {
        url:route,
        path:"{{ url('/student/') }}"
    };
</script>
@stop