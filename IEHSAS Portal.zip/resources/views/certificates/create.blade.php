@extends('app')

@section('header-styles')
<link href="{{asset('vendors/css/forms/selects/select2.min.css')}}" rel="stylesheet" type="text/css">
@stop

@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('certificate.store')}}" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="branch_id" value="{{Auth::user()->branch->id}}">
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Certificate No</label>
                                    <div class="col-md-9">
                                        <input type="text" id="certificate_no" autofocus value="{{old('certificate_no')}}" class="form-control {{$errors->has('certificate_no') ? 'border-danger' : ''}}" placeholder="Enter Certificate No" name="certificate_no">
                                        @if($errors->has('certificate_no'))
                                            <span class=" text-danger">{{ $errors->first('certificate_no') }}</span>
                                        @endif
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Student</label>
                                    <div class="col-md-9">
                                        <select class="form-control" name="student_id" id="student_id">
                                            <option> -- Select Student -- </option>
                                        </select>
                                        @if($errors->has('student_id'))
                                            <span class=" text-danger">{{ $errors->first('student_id') }}</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Certificate Type</label>
                                    <div class="col-md-9">
                                        <select name="certificate_type_id" id="certificate_type_id" class="form-control"> 
                                            <option value="">-- Select Certificate Type --</option>
                                            @foreach($types as $type)
                                                <option value="{{ $type->id }}">{{ $type->name }}</option>
                                            @endforeach
                                        </select>
                                        @if($errors->has('certificate_type_id'))
                                            <span class="text-danger ">{{ $errors->first('certificate_type_id') }}</span>
                                        @endif
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput4">Exam Date</label>
                                        <div class="col-md-9">
                                                <input type="date" class="form-control date {{ $errors->has('exam_date') ? 'is-invalid' : '' }}" name="exam_date">
                                            @if($errors->has('exam_date'))
                                                <span class="text-danger">{{$errors->first('exam_date')}}</span>
                                            @endif
                                        </div>
    
                                    </div>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Declared Date</label>
                                    <div class="col-md-9">
                                        <input type="date" id="declaredDate" class="form-control date {{$errors->has('declared_date') ? 'border-danger' : ''}}"  name="declared_date">
                                        @if($errors->has('declared_date'))
                                            <span class="text-danger courier_name">
                                                {{ $errors->first('declared_date') }}
                                            </span>
                                        @endif  
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Issused Date</label>
                                    <div class="col-md-9">
                                        <input type="date" id="issusedDate" class="form-control date {{$errors->has('issuesed_date') ? 'border-danger' : ''}}"  name="issued_date">
                                    </div>
                                    @if($errors->has('issued_date'))
                                        <span class="text-danger offset-md-4">{{ $errors->first('issued_date') }}</span>
                                    @endif
                                </div>
                            </div>

                        </div>

                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Add Certificate" id="btnAdd" class="btn btn-primary">
                        {{--<input type="submit" value="Print Invoice" id="btnAdd" class="btn btn-success">--}}
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/forms/select/select2.full.min.js')}}"></script>
    <script>
        
        var dueAmount = 0;
        $(document).ready(function (e) {
            var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month + 1;
            if(month < 10) {
                month =  "0" +month;
            }
            if(fullDate < 10)
                fullDate = '0' + fullDate;
            $("#certificate_type_id").select2();
            $(".date").val(date.getFullYear() + "-" + month + "-" + fullDate);
            $("#student_id").select2({
                minimumInputLength:5,
                placeholder:'Search Student...',
                ajax:{
                    url:'{{ route("student.batch_student_ajax") }}',
                    dataType:'JSON',
                    type:'POST',
                    delay:1000,
                    data:function(term) {
                        return{
                            term:term,
                        }
                    },
                    processResults:function(data) {
                        return{
                            results: $.map(data, function(item) {
                                return {
                                    text:item.student_name+" "+item.father_name+" "+item.contact_no,
                                    id:item.id,
                                    slug:item.hostel_fee,
                                }
                            })
                        }
                    }
                }
            });
        });
    </script>

@stop

