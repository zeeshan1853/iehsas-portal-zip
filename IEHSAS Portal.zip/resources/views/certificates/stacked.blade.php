@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="coursesData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="certificate_no">Certificarte No</td>
                        <td data-column-id="student_name">Student</td>
                        <td data-column-id="certificate_type">Type</td>
                        <td data-column-id="exam_date">Exam Date</td>
                        <td data-column-id="declared_date">Declared Date</td>
                        <td data-column-id="issued_date">Issued Date</td>
                        <td data-column-id="received_date">Received Date</td>
                        <td data-column-id="delete" data-sortable="false">Acions</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach($certificates as $certificate)
                        <tr>
                            <td>{{$i++}}</td>
                            <td>{{ $certificate->certificate_no }}</td>
                            <td>{{ $certificate->student->student_name  }} {{ $certificate->student->father_name }}</td>
                            <td>{{ $certificate->certificateType->name }}</td>
                            <td>{{ $certificate->exam_date->toFormattedDateString() }}</td>
                            <td>{{ $certificate->declared_date->toFormattedDateString() }}</td>
                            <td>{{ $certificate->issued_date->toFormattedDateString() }}</td>
                            <td>{{ $certificate->created_at->toFormattedDateString() }}</td>
                            <td>
                                <a href="{{ route('certificate.delete',['id'=>$certificate->id]) }}" style="color:red" title="Delete Certificate"><i class="ft-trash"></i></a>
                                <a href="{{ route('certificate.edit',['id'=>$certificate->id]) }}" style="color:blue" title="Edit Certificate Deatils"><i class="ft-edit"></i></a>
                                <a href="#" data-id="{{ $certificate->id }}" class="dispatch" style="color:green" title="Dispatch Certificate"><i class="ft-check-square"></i></a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="modal fade text-left" id="dispatchModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-cyan">
                <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Disptach Mail</h4> &nbsp;&nbsp; <span> Required *</span>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <form id="dispatchForm">
                        <input type="hidden" name="certificate_id" value="" id="certificateId">
                        <input type="hidden" name="branch_id" value="{{ Auth::user()->branch->id }}" id="branch_id">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Courier Name <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control " id="courierName" name="courier_name" placeholder="Enter Courier Name">
                                    </div>
                                    <span class="text-danger courier_name offset-md-4 has-error"></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Tracking No <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" name="tracking_no" id="trackingNo" class="form-control" placeholder="Enter Courier Tracking No">
                                    </div>
                                    <span class="offset-md-4 tracking_no text-danger has-error"></span>
                                </div>
    
                            </div>
                        </div>
                        <div class="row">
                            
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Dispatcher Name <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" placeholder="Enter Dispatcher name" name="dispatcher" id="dispatcher">
                                    </div>
                                    <span class="text-danger dispatcher offset-md-4 has-error"></span>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" id="btnSave" class="btn btn-danger">Dispatch</button>
                </div>
            </div>
            </div>
        </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#coursesData").DataTable();
            $(".dispatch").click(function(e) {
                var id = $(this).attr("data-id");
                $("#dispatchModal").modal();
                $("#certificateId").val(id);
            });
            $("#btnSave").click(function(e) {
                var data = $("#dispatchForm").serializeArray();
                var i= 0;
                data.forEach(function(d) {
                    if(d.value == "") {
                        i++;
                        $("."+d.name).html("This Field is Required");
                    }
                });
                if(i > 0) {
                    return;
                }
                $.ajax({
                    url:"{{ route('outgoingCertificate.storeAjax') }}",
                    data:data,
                    dataType:'JSON',
                    type:'POST',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                $("#trackingNo").val(" ");
                                $("#dispatcher").val(" ");
                                $("#courierName").val(" ");
                                $("#dispatchModal").modal('hide');
                                toastr.success("Certificate Dispatch Successfully");
                                setTimeout(()=>{
                                    window.location.reload();
                                },1000)
                            } else {
                                toastr.error("Opss Something Went Wrong");
                            }
                        } else {
                            toastr.error("Contact Admin "+jqXHR.status);
                        }
                    }
                })
            });
        });
    </script>
@stop