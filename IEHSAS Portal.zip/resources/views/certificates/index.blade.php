@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
    <style>
        .bor{
            border-bottom:1px solid #D3D3D3;
        }
    </style>
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="coursesData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="certificate_no">Certificarte No</td>
                        <td data-column-id="student_name">Student</td>
                        <td data-column-id="certificate_type">Type</td>
                        <td data-column-id="exam_date">Exam Date</td>
                        <td data-column-id="declared_date">Declared Date</td>
                        <td data-column-id="issued_date">Issued Date</td>
                        <td data-column-id="received_date">Received Date</td>
                        <td data-column-id="status">Status</td>
                        <td data-column-id="delete" data-sortable="false">Acions</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach($certificates as $certificate)
                        <tr>
                            <td>{{$i++}}</td>
                            <td>{{ $certificate->certificate_no }}</td>
                            <td>{{ $certificate->student->student_name  }} {{ $certificate->student->father_name }}</td>
                            <td>{{ $certificate->certificateType->name }}</td>
                            <td>{{ $certificate->exam_date->toFormattedDateString() }}</td>
                            <td>{{ $certificate->declared_date->toFormattedDateString() }}</td>
                            <td>{{ $certificate->issued_date->toFormattedDateString() }}</td>
                            <td>{{ $certificate->created_at->toFormattedDateString() }}</td>
                            <td>
                                @if($certificate->status == 0)
                                    <i class="badge badge-danger">Stacked</i>
                                @else 
                                    <i class="badge badge-primary">Dispatched</i>
                                @endif
                            </td>
                            <td>
                                <a href="{{ route('certificate.delete',['id'=>$certificate->id]) }}" style="color:red" title="Delete Certificate"><i class="ft-trash"></i></a>
                                <a href="{{ route('certificate.edit',['id'=>$certificate->id]) }}" style="color:blue" title="Edit Certificate Deatils"><i class="ft-edit"></i></a>
                                @if($certificate->status == 1)
                                    <a href="#" class="dispatch" title="Show Disptahced Details" data-id="{{ $certificate->outgoingCertificate->id }}"><i class="ft-eye" style="color:green;"></i></a>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="modal fade text-left" id="dispatchModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-cyan">
            <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i>Mail Details</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-4" style="border-right:1px solid grey;">
                        <img src="{{ asset('images/postman.png') }}" height="400" width="400">
                    </div>    
                    <div class="col-md-8">
                        <div class="row bor">
                            <h3 class="text-bold-500 mt-4  offset-md-1 col-md-5"><i class="ft-star" style="color:gold;"></i> &nbsp;Courier Name</h3>
                            <h3 class="text-bold-700 mt-4 col-md-5 offset-md-1 courier_name"></h3>
                        </div>
                        <div class="row bor">
                            <h3 class="text-bold-500 mt-4 offset-md-1 col-md-5"><i class="ft-star" style="color:gold;"></i> &nbsp;Tracking No</h3>
                            <h3 class="text-bold-700 mt-4 col-md-5 offset-md-1 tracking_no"></h3>
                        </div>
                        <div class="row bor">
                            <h3 class="text-bold-500 mt-4 offset-md-1 col-md-5"><i class="ft-star" style="color:gold;"></i> &nbsp;Dispatcher</h3>
                            <h3 class="text-bold-700 mt-4 col-md-5 offset-md-1 dispatcher"></h3>
                        </div>
                    </div>    
                </div>  
            </div>
            <div class="modal-footer">
            <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
        </div>
    </div>
</div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#coursesData").DataTable();
            $(".dispatch").click(function(e) {
                $("#dispatchModal").modal();
                var id = $(this).attr("data-id");
                var route = "{{ route('outgoingCertificate.show',':id') }}";
                route = route.replace(":id",id);
                $.ajax({
                    url:route,
                    dataType:'JSON',
                    type:'GET',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var outgoing = result.outgoing;
                                $(".courier_name").html(outgoing.courier_name);
                                $(".tracking_no").html(outgoing.tracking_no);
                                $(".dispatcher").html(outgoing.dispatcher);
                            }
                        }
                    }

                });
            });
        })
    </script>
@stop