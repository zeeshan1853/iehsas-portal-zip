@extends('app')

@section('header-styles')
<link href="{{asset('vendors/css/forms/selects/select2.min.css')}}" rel="stylesheet" type="text/css">
<style>
        input[type="date"]::-webkit-calendar-picker-indicator {
            background: transparent;
            bottom: 0;
            color: transparent;
            cursor: pointer;
            height: auto;
            left: 0;
            position: absolute;
            right: 0;
            top: 0;
            width: auto;
        }
</style>
@stop

@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('certificate.update',['id'=>$certificate->id])}}" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="branch_id" value="{{ $certificate->branch_id }}">
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Certificate No</label>
                                    <div class="col-md-9">
                                        <input type="text" id="certificate_no" autofocus @if(old('certificate_no') == '') value="{{ $certificate->certificate_no }}" @else value="{{ old('certificate_no') }}" @endif class="form-control {{$errors->has('certificate_no') ? 'border-danger' : ''}}" placeholder="Enter Certificate No" name="certificate_no">
                                        @if($errors->has('certificate_no'))
                                            <span class=" text-danger">{{ $errors->first('certificate_no') }}</span>
                                        @endif
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Student</label>
                                    <div class="col-md-9">
                                        <select class="form-control" name="student_id" id="student_id">
                                            <option value="{{ $certificate->student_id }}">{{$certificate->student->student_name}} {{$certificate->student->father_name}} {{$certificate->student->contact_no}}</option>
                                        </select>
                                        @if($errors->has('student_id'))
                                            <span class=" text-danger">{{ $errors->first('student_id') }}</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Certificate Type</label>
                                    <div class="col-md-9">
                                        <select name="certificate_type_id" id="certificate_type_id" class="form-control"> 
                                            <option value="">-- Select Certificate Type --</option>
                                            @foreach($types as $type)
                                            @if($type->id == $certificate->certificate_type_id)
                                                <option value="{{ $type->id }}" selected>{{ $type->name }}</option>
                                            @else
                                                <option value="{{ $type->id }}">{{ $type->name }}</option>
                                            @endif
                                            @endforeach
                                        </select>
                                        @if($errors->has('certificate_type_id'))
                                            <span class="text-danger ">{{ $errors->first('certificate_type_id') }}</span>
                                        @endif
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput4">Exam Date</label>
                                        <div class="col-md-9">
                                                <input type="date" class="form-control date {{ $errors->has('exam_date') ? 'is-invalid' : '' }}" name="exam_date" value="{{ $certificate->exam_date->format('Y-m-d') }}">
                                            @if($errors->has('exam_date'))
                                                <span class="text-danger">{{$errors->first('exam_date')}}</span>
                                            @endif
                                        </div>
    
                                    </div>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Declared Date</label>
                                    <div class="col-md-9">
                                        <input type="date" id="declaredDate" class="form-control date {{$errors->has('declared_date') ? 'border-danger' : ''}}"  name="declared_date" value="{{ $certificate->declared_date->format('Y-m-d') }}">
                                        @if($errors->has('declared_date'))
                                            <span class="text-danger courier_name">
                                                {{ $errors->first('declared_date') }}
                                            </span>
                                        @endif  
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Issused Date</label>
                                    <div class="col-md-9">
                                        <input type="date" id="issusedDate" class="form-control date {{$errors->has('issuesed_date') ? 'border-danger' : ''}}"  name="issued_date" value="{{ $certificate->issued_date->format('Y-m-d') }}">
                                    </div>
                                    @if($errors->has('issued_date'))
                                        <span class="text-danger offset-md-4">{{ $errors->first('issued_date') }}</span>
                                    @endif
                                </div>
                            </div>

                        </div>

                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Update" id="btnAdd" class="btn btn-primary">
                        {{--<input type="submit" value="Print Invoice" id="btnAdd" class="btn btn-success">--}}
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/forms/select/select2.full.min.js')}}"></script>
    <script>
        
        var dueAmount = 0;
        $(document).ready(function (e) {
            var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month + 1;
            if(month < 10) {
                month =  "0" +month;
            }
            if(fullDate < 10)
                fullDate = '0' + fullDate;
            $("#certificate_type_id").select2();
            var dates = document.getElementsByClassName('date');
            for(d in dates){
                if(dates[d].value == "") {
                    dates[d].value = date.getFullYear() + "-" + month + "-" + fullDate;
                }
            }
            $("#student_id").select2({
                minimumInputLength:5,
                placeholder:'Search Student...',
                ajax:{
                    url:'/api/students',
                    dataType:'JSON',
                    type:'POST',
                    delay:1000,
                    data:function(term) {
                        return{
                            term:term,
                        }
                    },
                    processResults:function(data) {
                        return{
                            results: $.map(data, function(item) {
                                return {
                                    text:item.student_name+" "+item.father_name+" "+item.contact_no,
                                    id:item.id,
                                    slug:item.hostel_fee,
                                }
                            })
                        }
                    }
                }
            });
        });
    </script>

@stop

