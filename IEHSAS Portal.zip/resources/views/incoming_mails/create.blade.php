@extends('app')

@section('header-styles')
@stop

@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('mail.store')}}" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="branch_id" value="{{Auth::user()->branch->id}}">
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">From</label>
                                    <div class="col-md-9">
                                        <input type="text" id="=from" autofocus value="{{old('from')}}" class="form-control {{$errors->has('from') ? 'border-danger' : ''}}" placeholder="Mail From" name="from">
                                        @if($errors->has('from'))
                                            <span class=" text-danger">{{ $errors->first('from') }}</span>
                                        @endif
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">To</label>
                                    <div class="col-md-9">
                                        <input type="text" id="to" value="{{old('to')}}" class="form-control {{$errors->has('to') ? 'border-danger' : ''}}" placeholder="Mail To" name="to">
                                        @if($errors->has('to'))
                                            <span class=" text-danger">{{ $errors->first('to') }}</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Address</label>
                                    <div class="col-md-9">
                                        <textarea class="form-control {{ $errors->has('address') ? 'is-invalid' : '' }}" placeholder="Enter Mail Address" name="address" rows="8">{{ old('address') }}</textarea>
                                        @if($errors->has('address'))
                                            <span class="text-danger ">{{ $errors->first('address') }}</span>
                                        @endif
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput4">Content</label>
                                        <div class="col-md-9">
                                                <textarea class="form-control {{ $errors->has('content') ? 'is-invalid' : '' }}" name="content" placeholder="Enter Mail Content" rows="8">{{ old('content') }}</textarea>
                                            @if($errors->has('content'))
                                                <span class="text-danger">{{$errors->first('content')}}</span>
                                            @endif
                                        </div>
    
                                    </div>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Courier Name</label>
                                    <div class="col-md-9">
                                        <input type="text" id="courierName" placeholder="Enter Courier Name" value="{{old('courier_name')}}" class="form-control {{$errors->has('courier_name') ? 'border-danger' : ''}}"  name="courier_name">
                                        @if($errors->has('courier_name'))
                                            <span class="text-danger courier_name">
                                                {{ $errors->first('courier_name') }}
                                            </span>
                                        @endif  
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Receiving Date</label>
                                    <div class="col-md-9">
                                        <input type="date" id="receivingDate" class="form-control date {{$errors->has('receiving_date') ? 'border-danger' : ''}}"  name="receiving_date">
                                    </div>
                                    @if($errors->has('receiving_date'))
                                        <span class="text-danger offset-md-4">{{ $errors->first('receiving_date') }}</span>
                                    @endif
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Stacking / placement</label>
                                    <div class="col-md-9">
                                        <input type="text" value="{{ old('stacking_placement') }}" name="stacking_placement" id="stackingPlacement" placeholder="Enter Mail is Stack / Placed" class="form-control {{ $errors->has('stacking_placement') ? 'is-invalid' : '' }}">
                                        @if($errors->has('stacking_placement'))
                                            <span class="text-danger">{{$errors->first('stacking_placement')}}</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Reciver Name:</label>
                                    <div class="col-md-9">
                                        <input type="text" value="{{ old('receiver_name') }}" class="form-control {{ $errors->has('receiver_name') ? 'is-invalid' : '' }}" name="receiver_name" id="receiverName" placeholder="Enter Reciver Name">
                                        @if($errors->has('receiver_name'))
                                            <span class="text-danger">{{$errors->first('receiver_name')}}</span>
                                        @endif
                                    </div>

                                </div>
                            </div>

                        </div>

                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Add Mail" id="btnAdd" class="btn btn-primary">
                        {{--<input type="submit" value="Print Invoice" id="btnAdd" class="btn btn-success">--}}
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
    <script>
        var dueAmount = 0;
        $(document).ready(function (e) {
            var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month + 1;
            if(month < 10) {
                month =  "0" +month;
            }
            if(fullDate < 10)
                fullDate = '0' + fullDate;


            $(".date").val(date.getFullYear() + "-" + month + "-" + fullDate);
        });
    </script>

@stop

