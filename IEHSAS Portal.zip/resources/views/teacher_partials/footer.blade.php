<footer class="footer fixed-bottom footer-light navbar-border">
    <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2">
        <span class="float-md-left d-block d-md-inline-block">Copyright &copy; 2019 
            <a class="text-bold-800 grey darken-2" href="http://www.iehsas.com" target="_blank">IEHSAS </a>, All rights reserved. </span>
        <span class="float-md-right d-block d-md-inline-blockd-none d-lg-block">
            &nbsp;&nbsp;Version 1.0
        </span>
        <span class="float-md-right d-block d-md-inline-blockd-none d-lg-block">Hand-crafted & Made with <i class="ft-heart pink"></i>
        By <a href="https://www.techcodex.net" target="_blank">TechCodeX</a>
        </span>
        
    </p>
</footer>
