@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="coursesData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Course Name</td>
                        <td data-column-id="delete" data-sortable="false">Acions</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach($courses as $course)
                        <tr>
                            <td>{{$i++}}</td>
                            <td>{{ $course->course_name }}</td>
                            <td>
                                <a href="{{route('course.edit_course',['id'=>$course->id])}}"><i class="ft-edit"></i></a>
                                <a href="{{route('course.delete_course',['id'=>$course->id])}}" style="color:red;margin-left: 5px;"><i class="ft-trash"></i></a> 
                                <a href="{{ route('course.documentTypes',['id'=>$course->id]) }}" style="color:orange;margin-left: 5px;" title="Course Document Types"><i class="ft-book"></i></a> 
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#coursesData").DataTable();
        })
    </script>
@stop