@extends('app')

@section('header-styles')
<link href="{{url('public/vendors/css/forms/selects/select2.min.css')}}" rel="stylesheet" type="text/css">

@stop

@section('main')
    <div class="row">
        <div class="card col-md-8 offset-md-2">
            <div class="card-body">
                <form method="post" action="{{route('course.save_course')}}">
                    @csrf
                    <div class="form-group">
                        <label><h5 class="mt-2">Course Name:</h5></label>
                        <input name="course_name" autofocus class="form-control" {{$errors->has('course_name') ? 'is-invalid':''  }} placeholder="Course Name"  value="{{old('course_name')}}">
                        <span class="text-danger">
                            @if($errors->has('course_name'))
                                {{$errors->first('course_name')}}
                            @endif
                        </span>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary offset-md-4 col-md-4" >
                            Add Course
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
<script src="{{url('public/vendors/js/forms/select/select2.full.min.js')}}"></script>
<script>
    $(document).ready(function (e) {
        $("#teacher_id").select2();
    })
</script>
@stop

