@extends('app')

@section('header-styles')
    <link href="{{url('public/vendors/css/forms/selects/select2.min.css')}}" rel="stylesheet" type="text/css">

@stop

@section('main')
    <div class="row">
        <div class="card col-md-8 offset-md-2">
            <div class="card-body">
                <form method="post" action="{{route('course.update_course',['id'=>$course->id])}}">
                    @csrf
                    <div class="form-group">
                        <label><h5 class="mt-2">Course Name:</h5></label>
                        <textarea name="course_name" class="form-control" {{$errors->has('course_name') ? 'is-invalid':''  }} placeholder="Course Name">
                            {{$course->course_name}}
                        </textarea>
                        <span class="text-danger">
                            @if($errors->has('course_name'))
                                {{$errors->first('course_name')}}
                            @endif
                        </span>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary offset-md-4 col-md-4" >
                            Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
    <script src="{{url('public/vendors/js/forms/select/select2.full.min.js')}}"></script>
    <script>
        $(document).ready(function (e) {
            $("#teacher_id").select2();
        })
    </script>
@stop

