@extends('app')


@section('header-styles')


@stop

@section('main')
    <div class="row">
        <div class="card col-md-8 offset-md-2">
            <div class="card-body">
                <form method="post" action="{{route('cash_account.update',['id'=>$cash->id])}}">
                    @csrf
                    <div class="form-group">
                        <label><h5 class="mt-2">Opening:</h5></label>
                    <input type="text" name="opening" class="form-control" disabled id="opening" value="{{ $cash->opening}}">
                    </div>
                    <div class="form-group">
                        <label><h5 class="mt-2">Debit:</h5></label>
                    <input type="text" name="debit" class="form-control" id="debit" disabled value="{{ $cash->debit}}">
                    </div>
                    <div class="form-group">
                        <label><h5 class="mt-2">Credit:</h5></label>
                    <input type="text" name="credit" class="form-control" id="credit" disabled value="{{ $cash->credit}}">
                    </div>
                    <div class="form-group">
                        <label><h5 class="mt-2">Deposit Money:</h5></label>
                        <input type="text" name="deposit" value="0" class="form-control {{$errors->has('deposit') ? 'is-invalid' : ''}}" id="deposit" placeholder="Enter Deposit Amount" @if(old('deposit'))value="{{old('deposit')}}" @endif>
                        <span class="text-danger">
                            @if($errors->has('deposit'))
                                {{$errors->first('deposit')}}
                            @endif
                        </span>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary offset-md-5 col-md-2" >
                            Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@stop

@section('footer-scripts')

@stop


