@extends('app')

@section('header-styles')
@stop

@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('documentType.update',['id'=>$type->id])}}" id="documentTypeForm" enctype="multipart/form-data">
                    @csrf
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-4 label-control" for="userinput1">Docoument Type Name</label>
                                    <div class="col-md-8">
                                        <input type="text" @if(old('name') != "") value="{{ old('name') }}" @else value="{{ $type->name }}" @endif autofocus placeholder="Enter Document Name" class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" name="name">
                                            @if($errors->has('name'))
                                            <span class="text-danger">
                                                {{ $errors->first('name') }}
                                            </span>
                                            @endif
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-actions ">
                        <input type="submit" value="Update" id="btnAdd" class="btn btn-primary offset-md-5">
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
@stop

