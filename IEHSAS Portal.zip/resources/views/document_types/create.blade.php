@extends('app')

@section('header-styles')
<link href="{{asset('vendors/css/forms/selects/select2.min.css')}}" rel="stylesheet" type="text/css">
@stop

@section('main')
<div class="row">
    <div class="card col-md-12">
        <div class="card-body">
            <form class="form form-horizontal" method="post" action="{{route('documentType.store')}}"
                id="documentTypeForm" enctype="multipart/form-data">
                @csrf
                <div class="form-body">
                    <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                    <div class="row">
                        <div class="col-md-6 offset-md-2">
                            <div class="form-group row">
                                <label class="col-md-4 label-control" for="userinput1">Docoument Type Name</label>
                                <div class="col-md-8">
                                    <input type="text" value="{{ old('name') }}" autofocus
                                        placeholder="Enter Document Name"
                                        class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" name="name">
                                    @if($errors->has('name'))
                                    <span class="text-danger">
                                        {{ $errors->first('name') }}
                                    </span>
                                    @endif
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 offset-md-2">
                            <div class="form-group row">
                                <label class="col-md-4 label-control" for="userinput1">Document Type:</label>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <select class="form-control" name="course_id" id="courseId">
                                            <option value="">--Select Document Type--</option>
                                            @foreach($courses as $course)
                                            <option value="{{ $course->id }}">{{ $course->course_name }}</option>
                                            @endforeach
                                        </select>
                                        <div class="input-group-append">
                                            <span class="input-group-text">
                                                <a href="#" id="addDocumentType"><i class="ft-plus-circle"></i></a>
                                            </span>
                                        </div>
                                    </div>
                                    @if($errors->has('course_id'))
                                    <span class="text-danger">
                                        {{ $errors->first('course_id') }}
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="form-actions ">
                    <input type="submit" value="Add" id="btnAdd" class="btn btn-primary offset-md-5">
                </div>
            </form>
        </div>
    </div>
</div>

@stop


@section('footer-scripts')
<script src="{{asset('vendors/js/forms/select/select2.full.min.js')}}"></script>
<script>
    $(document).ready(function(e) {
        $("#courseId").select2();
        
    });
</script>
@stop