@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="mailsData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Name</td>
                        <td data-column-id="edit" data-sortable="false">Action</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach ($types as $type)
                        <tr>
                            <td>{{ $i++ }}</td>
                            <td>{{ $type->name }}</td>
                            <td>
                                <a href="{{ route('documentType.edit',['id'=>$type->id]) }}" title="Edit Course Title"><i class="ft-edit"></i></a>
                                <a href="{{ route('documentType.show',['id'=>$type->id]) }}" title="Show Documents" style="color:green;"><i class="ft-eye"></i></a>
                                <a href="{{ route('documentType.delete',['id'=>$type->id]) }}" title="Delete" style="color:red;"><i class="ft-trash"></i></a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#mailsData").DataTable();
            
        });
    </script>
@stop