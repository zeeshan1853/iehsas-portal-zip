@extends('app')


@section('header-styles')


@stop

@section('main')
    <div class="row">
        <div class="card col-md-8 offset-md-2">
            <div class="card-body">
                <form method="post" action="{{route('branch.store')}}">
                    @csrf
                    <div class="form-group">
                        <label><h5 class="mt-2">Branch Name:</h5></label>
                        <input type="text" name="name" class="form-control {{$errors->has('name') ? 'is-invalid' : ''}}" id="branchName" placeholder="Branch Name" value="{{old('name')}}">
                        <span class="text-danger">
                            @if($errors->has('name'))
                                {{$errors->first('name')}}
                            @endif
                        </span>
                    </div>
                    <div class="form-group">
                        <label><h5 class="mt-2">Branch Opening Balance:</h5></label>
                        <input type="text" name="opening" class="form-control {{$errors->has('opening') ? 'is-invalid' : ''}}" id="opening" placeholder="Branch Opening Balance" value="{{old('opening')}}">
                        <span class="text-danger">
                            @if($errors->has('opening'))
                                {{$errors->first('opening')}}
                            @endif
                        </span>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary offset-md-4 col-md-4" >
                            Add Branch
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@stop

@section('footer-scripts')

@stop


