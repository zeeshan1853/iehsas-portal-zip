@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="branchesData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Name</td>
                        <td data-column-id="debit">Debit</td>
                        <td data-column-id="credit">Credit</td>
                        <td data-column-id="balance">Balanace</td>
                        <td data-column-id="edit" data-sortable="false">Edit</td>
                        <td data-sortable="false">Branch</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach($branches as $branch)
                        <tr>
                            <td>{{$i++}}</td>
                            <td>{{$branch->name}}</td>
                            <td>{{ $branch->debit }}</td>
                            <td>{{ $branch->credit }}</td>
                            <td>{{ $branch->debit - $branch->credit }}</td>
                            <td><a href="{{route('branch.edit',['id'=>$branch->id])}}"> <i class="ft-edit"></i></a></td>
                            @if($branch->branch == 1)
                                <td><span class="ft-award" style="color:green;"></span></td>
                            @else 
                                <td><span class="ft-umbrella" style="color:red;"></span></td>
                            @endif
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#branchesData").DataTable({
                language: {
                    searchPlaceholder: "Search Branch",
                }
            });
        })
    </script>
@stop