@extends('app')

@section('header-styles')
@stop

@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('document.update',['id'=>$document->id])}}" id="instalmentForm" enctype="multipart/form-data">
                    @csrf
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Docoument Name</label>
                                    <div class="col-md-9">
                                        <input type="text" @if(old('name') == '') value="{{ $document->name }}" @else value="{{ old('name') }}" @endif autofocus placeholder="Enter Document Name" class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" name="name">
                                    </div>
                                    @if($errors->has('name'))
                                    <span class="offset-md-4 text-danger">
                                        {{ $errors->first('name') }}
                                    </span>
                                    @endif
                                    
                                </div>

                            </div>

                        </div>

                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Docoument File</label>
                                    <div class="col-md-9">
                                        <input type="file"  class="form-control {{ $errors->has('document') ? 'is-invalid' : '' }}" name="document">
                                    </div>
                                    @if($errors->has('document'))
                                    <span class="offset-md-4 text-danger">
                                        {{ $errors->first('document') }}
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-actions ">
                        <input type="submit" value="Add" id="btnAdd" class="btn btn-primary offset-md-5">
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
@stop

