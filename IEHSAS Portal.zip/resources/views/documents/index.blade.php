@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="mailsData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="course">Course</td>
                        <td data-column-id="name">Name</td>
                        <td data-column-id="document">Document</td>
                        <td data-column-id="edit" data-sortable="false">Action</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach ($documents as $document)
                        <tr>
                            <td>{{ $i++ }}</td>
                            <td>{{ $document->documentType->course->course_name }}</td>
                            <td>{{ $document->name }}</td>
                            <td>
                                <?php
                                    $extension = File::extension($document->document);
                                ?>
                                @if($extension == "jpg" || $extension == "jpeg")
                                    <img src="{{ asset($document->document) }}" alt="file" style="width:100px;height:100px;">

                                @else
                                    <img src="{{ asset('images/icons/pdf.png') }}" alt="pdf file" style="width:100px;height:100px;">
                                @endif
                            </td>
                            <td>
                                <a href="{{ route('document.edit',['id'=>$document->id]) }}"><i class="ft-edit"></i></a>
                                <a href="{{ route('document.delete',['id'=>$document->id]) }}"><i class="ft-trash" style="color:red;"></i></a>
                                <a href="" class="print" data-document="{{ asset($document->document) }}" @if($extension == "jpeg" || $extension == "jpg") data-type="image" @else data-type="pdf" @endif><i class="ft-printer" style="color:green;"></i></a>
                                <a href="{{ asset($document->document) }}" download class="download" data-document="{{ asset($document->document) }}"><i class="ft-download" style="color:purple;"></i></a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#mailsData").DataTable();
            $(".print").click(function(e) {
                e.preventDefault();
                var document = $(this).data("document");
                var type = $(this).data("type");
                if(type == "pdf") {
                    window.open(document);
                } else {
                    myWindow = window.open(document);
                    myWindow.print();
                }
            });
            
        });
    </script>
@stop