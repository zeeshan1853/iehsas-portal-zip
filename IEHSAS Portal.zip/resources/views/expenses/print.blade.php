<html>
    <head>
        <title>Expense List</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

        <script
        src="https://code.jquery.com/jquery-3.4.1.min.js"
        integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
        crossorigin="anonymous"></script>

        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <style>
                @page { size: auto;  margin: 0mm; }
        </style>
    <body>


    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h2 class="page-header">
                    {{ Auth::user()->branch->name }}
                    <img src="{{ asset(Auth::user()->branch->setting->logo) }}" width="150px" alt="logo" style="margin-left:25%;">
                    <small class="pull-right">Date: {{ date("d-m-Y") }}</small>
                </h2>
            </div>
            <center><h1>Expense List</h1></center>
            <!-- /.col -->
        </div>
    
            <table class="table table-responsive table-bordered">
                <thead>
                    <tr class="bg-primary">
                        <td>Sr.No</td>
                        <td>Date</td>
                        <td>Name</td>
                        <td>Amount</td>
                        <td>Type</td>
                        <td>Description</td>
                    </tr>
                </thead>
                <tbody class="tbody">
    
                </tbody>
                <tfoot class="tfoot">
                    <tr>
                    <tr>
                        <td colspan="3"><center><b>Total</b></center></td>
                        <td class="total"></td>
                        <td></td>
                        <td></td>
                    </tr>
                    </tr>
                </tfoot>
            </table>

    </div>
    </body>
</html>
<script>
    $(document).ready(function(e) {
        var expenses = JSON.parse(localStorage.expense_list);
        var output = "";
        var total = 0;
        expenses.forEach(function(expense) {
            total += parseInt(expense.amount);
            output += "<tr><td>"+expense.sr_no+"</td><td>"+expense.date+"</td><td>"+expense.name+"</td><td>"+expense.amount+"</td><td>"+expense.type+"</td><td>"+expense.description+"</td></tr>";
        });
        $(".tbody > tr").remove();
        $(".tbody").append(output);
        document.getElementsByClassName("total")[0].textContent = total;
        window.print();
    })
</script>
