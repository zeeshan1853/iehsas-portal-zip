@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/forms/selects/select2.min.css')}}" rel="stylesheet" type="text/css">

@stop

@section('main')

    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('expense.store')}}">
                    @csrf
                    
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> Expense Details</h4>
                            <div class="form-group row">
                                <label class="col-md-2 label-control">Expense Type:</label>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <select class="form-control select2" tabindex="01" autofocus name="expense_type_id" id="expenseTypeId">
                                            <option value="">--Select Expense Type--</option>
                                            @foreach($types as $type)
                                                <option value="{{ $type->id }}">{{ $type->name }}</option>
                                            @endforeach
                                        </select>
                                        <div class="input-group-append">
                                            <span class="input-group-text">
                                                <a href="#" id="addExpenseType" class="color:blue"><span class="ft-plus"></span></a>
                                            </span>
                                        </div>
                                    </div>
                                    @if($errors->has('expense_type_id'))
                                        <span  class="text-danger">{{ $errors->first('expense_type_id') }}</span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-2 label-control">Expense Name:</label>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <select class="form-control select2" tabindex="02" name="expense_name_id" id="expenseNameId">
                                            <option value="">--Select Expense Name--</option>
                                        </select>
                                        <div class="input-group-append">
                                            <span class="input-group-text">
                                                <a href="#" id="addExpenseName" class="color:blue"><span class="ft-plus"></span></a>
                                            </span>
                                        </div>
                                    </div>
                                    @if($errors->has('expense_name_id'))
                                        <span  class="text-danger">{{ $errors->first('expense_name_id') }}</span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-2 label-control">Description:</label>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <textarea id="" name="description" tabindex="03" placeholder="Expense Description" class="form-control" rows="5"></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-2 label-control">Amount:</label>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <input type="number" name="amount" tabindex="04" @if(old('amount')) value="{{ old('amount') }}" @endif placeholder="Enter Expense Amount" class="form-control">
                                    </div>
                                    @if($errors->has('amount'))
                                        <span  class="text-danger">{{ $errors->first('amount') }}</span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-2 label-control">Payment Type:</label>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <select class="form-control" name="payment_id">
                                            <option>--Select Type Of Payment</option>
                                            @foreach($payments as $payment)
                                                <option value="{{ $payment->id }}" @if(strtolower($payment->name) == "cash") selected @endif >{{ $payment->name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    @if($errors->has('payment_id'))
                                        <span  class="text-danger">{{ $errors->first('payment_id') }}</span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-2 label-control">Date:</label>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <input type="date" name="date" tabindex="05" class="form-control date">
                                    </div>
                                </div>
                                @if($errors->has('date'))
                                    <span class="text-danger">{{ $errors->first('date') }}</span>
                                @endif
                            </div>

                        </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Add Expense" class="btn btn-primary" tabindex="06">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Add New Expense Type Modal -->
    <div class="modal fade" id="expenseTypeModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
            <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Add New Expense Type</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <form method="post" id="expenseTypeForm">
                    {{ csrf_field() }}
                    <div class="form-group">
                        <label for="name">Expense Type Name * <small>(Required)</small></label>
                        <input type="text" name="name" id="typeName" placeholder="Enter Expense Type Name" class="form-control">
                    </div>
                </form>
                
            <div class="modal-footer">
            <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-danger" id="saveType">Save</button>
            </div>
        </div>
        </div>
    </div>
    </div>
    <!-- Ending -->

    <!-- Add New Expense Name Modal -->
    <div class="modal fade" id="expenseNameModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
            <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Add New Expense Name</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <form method="post" id="expenseNameForm">
                    {{ csrf_field() }}
                    <div class="form-group">
                        <label for="name">Expense Name * (Required)</label>
                        <input type="text" name="name" placeholder="Enter Expense Name" id="expenseName" class="form-control">
                    </div>
                </form>
            <div class="modal-footer">
            <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-danger" id="saveName">Save</button>
            </div>
        </div>
        </div>
    </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/forms/select/select2.full.min.js')}}"></script>
    <script>
        $(document).ready(function (e) {
           $('.select2').select2();
            var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month + 1;
            if(month < 10)
                month = '0'+ month;
            if(fullDate < 10)
                fullDate = '0' + fullDate;

            $(".date").val(date.getFullYear() + "-" + month + "-" + fullDate);
        });
        $(document).ready(function (e) {
            $(document).on('focus','.select2',function (e) {
                $(this).siblings('select').select2('open');
            });
            $("#expenseTypeId").focus();
        });
        $("#addExpenseType").click(function(e) {
            $("#expenseTypeModal").modal();
        })
        $("#addExpenseName").click(function(e) {
            $("#expenseNameModal").modal();
        });
        $("#saveType").click(function() {
            
            var name = $("#typeName").val();
            if(name == "" || name.length < 2) {
                toastr.error("Check Your Errors");
                return;
            }
            var data = $("#expenseTypeForm").serializeArray();
            $.ajax({
                url:"{{ route('expenseType.store') }}",
                data:data,
                dataType:'JSON',
                type:'POST',
                complete:function(jqXHR,textStatus) {
                    if(jqXHR.status == 200) {
                        var result = JSON.parse(jqXHR.responseText);
                        if(result.hasOwnProperty('success')) {
                            var types = result.types;
                            var output = "";
                            types.forEach(function(type) {
                                output += "<option value='"+type.id+"'>"+type.name+"</option>";
                            });
                            $("#expenseTypeId > option ~ option").remove();

                            $("#expenseTypeId").append(output);
                            $("#typeName").val("");
                            $("#expenseTypeModal").modal('hide');
                            $("#typeName").val("");
                            $("#expenseTypeId").focus();
                            toastr.success("Expense Type Added Successfully");
                            
                        }
                    } else if(jqXHR.status == 422) {
                        var result = JSON.parse(jqXHR.responseText);
                        var errors = result.errors;
                        for(error in errors) {
                            toastr.error(errors[error]);
                        }
                    } 
                    else {
                        toastr.error("Opss Someting Went Wrong");            
                    }
                }
            });
        });
        $(document).ready(function() {
            $("#saveName").click(function(e) {
                var name = $("#expenseName").val();
                if(name == "" || name.length < 2) {
                    toastr.error("Please Fill all Required Fields");
                    return;
                }
                var expense_type_id = $("#expenseTypeId").val();
                if(expense_type_id == "") {
                    toastr.error("Please Select Any Expense Type");
                }
                var data = {
                    'name':name,
                    'expense_type_id':expense_type_id,
                };
                $.ajax({
                    data:data,
                    url:"{{ route('expenseName.store') }}",
                    dataType:'JSON',
                    type:'POST',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var output = "";
                                var names = result.names;
                                names.forEach(function(name) {
                                    output += "<option value='"+name.id+"'>"+name.name+"</option>";
                                });
                                $("#expenseNameId > option ~ option").remove();
                                $("#expenseNameId").append(output);
                                $("#expenseName").val("");
                                $("#expenseNameModal").modal('hide');
                                toastr.success("Expense Name Added Successsfully");
                            }
                        } else if(jqXHR.status == 422) {
                            var result = JSON.parse(jqXHR.responseText);
                            var errors = result.errors;
                            for(error in errors) {
                                toastr.error(errors[error]);
                            }
                        } 
                        else {
                            toastr.error("Opss Something Went Worng");
                        }
                    }
                });
            });
            $("#expenseTypeId").change(function(e) {
                var id = $("#expenseTypeId").val();
                var data = {
                    id:id,
                };
                $.ajax({
                    url:"{{ route('expenseName.showAjax') }}",
                    data:data,
                    dataType:'JSON',
                    type:'POST',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var names = result.names;
                                var output = "";
                                names.forEach(function(name) {
                                    output += "<option value='"+name.id+"'>"+name.name+"</option>";
                                });
                                $("#expenseNameId > option ~option").remove();
                                $("#expenseNameId").append(output);
                            }
                        }
                         else {
                            toastr.error("Opss Someting Went Wrong");
                        }
                    }
                });
            });
        });
    </script>

@stop

