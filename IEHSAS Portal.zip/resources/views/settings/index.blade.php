@extends('app')


@section('header-styles')
    <link href="{{asset('css/jasny-bootstrap.min.css')}}" rel="stylesheet" type="text/css">
@stop

@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('setting.update')}}" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="id" value="{{$setting->id}}">
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Insitute Name:</label>
                                    <div class="col-md-9">
                                        <input type="text" id="name"  autofocus @if(old('name') != null) value="{{ old('name') }}" @else value="{{$setting->name}}"  @endif  class="form-control {{$errors->has('name') ? 'border-danger' : ''}}" placeholder="Insitute Name" name="name">
                                    </div>
                                    @if($errors->has('name'))
                                        <span class="offset-md-4 text-danger">{{$errors->first('name')}}</span>

                                    @endif

                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Phone No</label>
                                    <div class="col-md-9">
                                        <input type="text" id="phone_no" @if(old('phone_no') != null) value="{{old('phone_no')}}" @else value="{{$setting->phone_no}}"  @endif  class="form-control {{$errors->has('phone_no') ? 'border-danger' : ''}}" placeholder="Phone No" name="phone_no">
                                    </div>
                                    @if($errors->has('phone_no'))
                                        <span class="offset-md-4 text-danger">{{$errors->first('phone_no')}}</span>

                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Email:</label>
                                    <div class="col-md-9">
                                        <input type="email" id="email" autofocus @if(old('email') != null) value="{{old('email')}}" @else value="{{$setting->email}}" @endif  class="form-control {{$errors->has('email') ? 'border-danger' : ''}}" placeholder="Insitute Email" name="email">
                                    </div>
                                    @if($errors->has('email'))
                                        <span class="offset-md-4 text-danger">{{$errors->first('email')}}</span>

                                    @endif
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Mobile No</label>
                                    <div class="col-md-9">
                                        <input type="text" id="mobile_no" @if(old('mobile_no') != null) value="{{old('mobile_no')}}" @else value="{{$setting->mobile_no}}"  @endif  class="form-control {{$errors->has('mobile_no') ? 'border-danger' : ''}}" placeholder="Mobile No" name="mobile_no">
                                    </div>
                                    @if($errors->has('mobile_no'))
                                        <span class="offset-md-4 text-danger">{{$errors->first('mobile_no')}}</span>

                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Country:</label>
                                    <div class="col-md-9">
                                        <input type="text" id="email" autofocus @if(old('country')!= null) value="{{old('country')}}" @else value="{{$setting->country}}" @endif class="form-control {{$errors->has('country') ? 'border-danger' : ''}}" placeholder="Country Name" name="country">
                                    </div>
                                    @if($errors->has('country'))
                                        <span class="offset-md-4 text-danger">{{$errors->first('country')}}</span>

                                    @endif
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3"> Insitute Logo</label>
                                    <div class="col-md-9">
                                        <!-- Student Image-->
                                        <div class="form-group">
                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                <div class="fileinput-preview img-thumbnail" data-trigger="fileinput" style="width: 300px; height: 200px;">
                                                    <img src="{{asset($setting->logo)}}" alt="logo">
                                                </div>
                                                <div>
                                            <span class="btn btn-outline-secondary btn-file">
                                              <span class="fileinput-new">Select image</span>
                                              <span class="fileinput-exists">Change</span>
                                              <input type="file" name="logo">
                                            </span>
                                                    <a href="#" class="btn btn-outline-secondary fileinput-exists" data-dismiss="fileinput">Remove</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @if($errors->has('logo'))
                                        <span class="text-danger offset-md-3">{{$errors->first('logo')}}</span>
                                    @endif
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Address:</label>
                                    <div class="col-md-9">
                                        <textarea cols="10" rows="10" name="address" class="form-control" placeholder="Insitute Address ...">@if(old('address') != null) {{old('address')}} @else {{$setting->address}} @endif</textarea>
                                    </div>
                                    @if($errors->has('address'))
                                        <span class="text-danger offset-md-4">
                                        {{$errors->first('address')}}
                                    </span>
                                    @endif
                                </div>
                            </div>
                        </div>

                    </div>


                    <div class="form-actions text-center">
                        <input type="submit" value="Update" id="btnAdd" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop

@section('footer-scripts')
    <script src="{{asset('js/jasny-bootstrap.min.js')}}"></script>

@stop