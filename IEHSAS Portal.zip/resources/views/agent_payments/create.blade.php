@extends('app')

@section('header-styles')
<link href="{{asset('vendors/css/forms/selects/select2.min.css')}}" rel="stylesheet" type="text/css">
@stop

@section('main')
<div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('agentPayment.store')}}" enctype="multipart/form-data" data-tabgroup>
                    @csrf
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                        <div class="row">
                            <div class="col-md-10">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Agent</label>
                                    <div class="col-md-9">
                                        <div class="input-group col-md-12">
                                            <select id="agent_id" name="agent_id" class="form-control select2" tabindex="01">
                                                <option value="">--Select Agent--</option>
                                                @foreach($agents as $agent)
    
                                                    <option data-dueAmount="{{ $agent->credit - $agent->debit }}" value="{{ $agent->id }}" {{ old('agent_id') == $agent->id ? 'selected' : ''  }}>{{ $agent->name }}</option>
                                                @endforeach
                                            </select>
                                            <div class="input-group-append">
                                                <span class="input-group-text due_amount">000000</span>
                                            </div>
                                        </div>
                                        @if($errors->has('agent_id'))
                                            <span class=" text-danger">{{ $errors->first('agent_id') }}</span>
                                        @endif
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-10">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Narration</label>
                                    <div class="col-md-9">
                                        <textarea class="form-control" rows="5" placeholder="Enter Narration" name="narration" tabindex="02">{{ old('narration') }}</textarea>
                                        @if($errors->has('narration'))
                                            <span class="text-danger contact_no">
                                                {{ $errors->first('narration') }}
                                            </span>
                                        @endif  
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-10">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Paid Amount</label>
                                    <div class="col-md-9">
                                        <input type="number" min="0" id="amount" class="form-control {{ $errors->has('amount') ? 'is-invalid' : '' }}" value="{{ old('amount') }}" name="amount" tabindex="03" placeholder="Enter Paid Amount">
                                        @if($errors->has('amount'))
                                            <span class="text-danger contact_no">
                                                {{ $errors->first('amount') }}
                                            </span>
                                        @endif  
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Save" id="btnAdd" class="btn btn-primary" tabindex="04">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@stop

@section('footer-scripts')
<script src="{{asset('vendors/js/forms/select/select2.full.min.js')}}"></script>
<script>
    var dueAmount = 0;
    $(document).on('focus','.select2',function (e) {
        $(this).siblings('select').select2('open');
    });
    $(document).ready((e)=>{
        $("#agent_id").select2();
        $("#agent_id").focus();
        $("#agent_id").change((e) => {
            dueAmount = $("#agent_id > option:selected").attr("data-dueAmount");
            $(".due_amount").text(dueAmount);
        });
        $("#amount").keydown((e) =>{
            if($("#agent_id").val() == 0 || $("#agent_id").val() == "") {
                toastr.error("Missing Agent");
                return ;
            }
            var amount = $("#amount").val();
            if(parseInt(amount) > parseInt(dueAmount)) {
                $("#btnAdd").attr("disabled",true);
                toastr.error("Paid Amount Must be Less then Due Amount");
            } else {
                $("#btnAdd").attr("disabled",false);
            }
        });

    });
    var tabgroups = document.querySelectorAll("[data-tabgroup]");
    //        console.log(tabgroups);
    // Loop through each to attach thse listeners we need
    for (var i = 0; i < tabgroups.length; i++) {
        var inputs = tabgroups[i].querySelectorAll("[tabindex]");
//            alert(inputs);
        // Loop through all of the elements we want the tab to be changed for
        for (var j = 0; j < inputs.length; j++) {

            // Listen for the tab pressed on these elements
            inputs[j].addEventListener("keydown", function(myIndex, inputs, e) {
                if (e.key === "Tab") {
                    // Prevent the default tab behavior
                    e.preventDefault();

                    // Focus the next one in the group
                    if (inputs[myIndex + 1]) {
                        inputs[myIndex + 1].focus();
                    } else { // Or focus the first one again
                        inputs[0].focus();
                    }
                }
            }.bind(null, j, inputs)) // Make a copy of the variables to use in the addEventListener
        }
    }

</script>
@stop