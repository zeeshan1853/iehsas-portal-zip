@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="coursesData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-colun-id="date">Date</td>
                        <td data-column-id="name">Agent Name</td>
                        <td data-column-id="paid_amount">Paid Amount</td>
                        <td data-column-id="balance">Narration</td>
                        <td data-column-id="delete" data-sortable="false">Acions</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach($payments as $payment)
                        <tr>
                            <td>{{$i++}}</td>
                            <td>{{ $payment->created_at->toFormattedDateString() }}</td>
                            <td>{{ $payment->agent->name }}</td>
                            <td>{{ $payment->credit }}</td>
                            <td>{{ $payment->narration == "" ? "N/A" : $payment->narration }}</td>
                            <td>
                                <a href="{{ route('agentPayment.delete',['id'=>$payment->id]) }}" style="color:red;">
                                    <i class="ft-trash"></i>
                                </a>
                            </td>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#coursesData").DataTable();
        })
    </script>
@stop