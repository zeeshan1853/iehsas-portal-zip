@extends('app')


@section('header-styles')
@stop

@section('main')
<div class="row">
    <div class="card col-md-12">
        <div class="card-body">
            <form class="form form-horizontal" method="post" action="{{route('role.store')}}"
                enctype="multipart/form-data">
                @csrf
                <div class="form-body">
                    <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                    <div class="row">
                        <div class="col-md-6 offset-md-2">
                            <div class="form-group row">
                                <label class="col-md-3 label-control" for="userinput1">Role Name:</label>
                                <div class="col-md-9">
                                    <input type="text" id="name" autofocus
                                        class="form-control {{$errors->has('name') ? 'border-danger' : ''}}"
                                        placeholder="Role Name" name="name">
                                </div>
                                @if($errors->has('name'))
                                <span class="offset-md-4 text-danger">{{$errors->first('name')}}</span>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-actions text-center">
                    <input type="submit" value="Store" id="btnAdd" class="btn btn-primary">
                </div>
            </form>
        </div>
    </div>
</div>

@stop

@section('footer-scripts')

@stop