@extends('app')

@section('header-styles')
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.css" rel="stylesheet">
@stop

@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('advertisement.sendCustomAdvertisement')}}" id="instalmentForm">
                    @csrf
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Course :</label>
                                    <div class="col-md-9">
                                        <select name="course_id" class="form-control">
                                            <option value=""> -- Select Course --</option>
                                            @foreach($courses as $course)
                                                <option value="{{ $course->id }}">{{ $course->course_name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    @if($errors->has('course_id'))
                                    <span class="offset-md-4 text-danger">
                                        {{ $errors->first('course_id') }}
                                    </span>
                                    @endif
                                    
                                </div>

                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group row">
                                    <label class="col-md-1 label-control" for="mail_draft">Mail Draft</label>
                                    <div class="col-md-11">
                                        <textarea id="editor" name="content">{{ old('content') }}</textarea>
                                    </div>
                                    <span class="text-danger offset-md-4">
                                        @if($errors->has('content'))
                                            {{$errors->first('content')}}
                                        @endif
                                    </span>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="form-actions ">
                        <input type="submit" value="Send" id="btnAdd" class="btn btn-primary offset-md-5">
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.js"></script>
<script>
    $(document).ready(function(e) {
        $("#editor").summernote({
            height:300,
        });
    })
</script>
@stop

