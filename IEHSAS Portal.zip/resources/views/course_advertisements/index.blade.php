@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="mailsData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Course</td>
                        <td data-column-id="content">Content</td>
                        <td data-column-id="edit" data-sortable="false">Action</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach ($advertisements as $advertisement)
                        <tr>
                            <td>{{ $i++ }}</td>
                            <td>{{ $advertisement->course->course_name }}</td>
                            <td>{!! str_limit(strip_tags($advertisement->content), 50) !!}</td>
                            <td>
                                <a href="{{ route('advertisement.delete',['id'=>$advertisement->id]) }}"><i class="ft-trash" style="color:red;"></i></a>
                                <a href="{{ route('advertisement.edit',['id'=>$advertisement->id]) }}"><i class="ft-edit" style="color:blue;"></i></a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#mailsData").DataTable();
        })
    </script>
@stop