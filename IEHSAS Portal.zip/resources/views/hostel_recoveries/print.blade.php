@extends('layouts.app_print')


@section('header-styles')
    <link rel="stylesheet" type="text/css" href="{{asset('css/pages/invoice.min.css')}}">
    <style>
        @media print {
            body * {
                visibility: hidden;
            }
            #invoice, #invoice * {
                visibility: visible;
            }
            #invoice {
                position: absolute;
                left: 0;
                top: 0;
                margin-top: -40px;
            }

        }
        @media print {

            html, body {
                height:100%;
                margin: 0 !important;
                padding: 0 !important;
                overflow: hidden;
            }

        }
        @page {  margin: 0mm; }
    </style>
@stop

@section('main')
    <div class="content-body" id="invoice">
        <section class="card">
            <div id="invoice-template" class="card-body">
                <!-- Invoice Company Details -->
                <div id="invoice-company-details" class="row">
                    <div class="col-md-6 col-sm-12 text-left text-md-left">
                        <img src="{{asset(Auth::user()->branch->setting->logo)}}" alt="company logo" class="mb-2" width="70">
                        <ul class="px-0 list-unstyled">
                            <li class="text-bold-700">{{ Auth::user()->branch->setting->name }}</li>
                            <li><b>Branch :</b> {{ Auth::user()->branch->name }}</li>
                            <li><b>Address :</b> {{ Auth::user()->branch->setting->address }}</li>
                            <li><b>Country :</b> {{ Auth::user()->branch->setting->country }}</li>
                            <li><b>Mobile No :</b> {{ Auth::user()->branch->setting->mobile_no }}</li>
                            <li><b>Phone No :</b> {{ Auth::user()->branch->setting->phone_no }}</li>
                        </ul>

                    </div>
                    <div class="col-md-6 col-sm-12 text-center text-md-right">
                        <h2>Student</h2>
                        <p><b>Name :</b> <span class="student_name"></span></p>
                        <p><b>Contact No :</b><span class="contact_no"></span></p>
                        <p><b>Email :</b> <span class="email"></span></p>
                        <p> <b>Date :</b> <span class="date"></span></p>
                    </div>
                </div>
                <!--/ Invoice Company Details -->

                <!-- Invoice Items Details -->
                <div id="invoice-items-details" class="pt-2">
                    <div class="row">
                        <div class="table-responsive col-sm-12">
                            <table class="table table-bordered text-center">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Student Name</th>
                                    <th class="">Paid</th>
                                    <th class="">Remaining Amount</th>
                                </tr>
                                </thead>
                                <tbody class="tbody">
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-7 col-sm-12 text-center text-md-left">
                            <p class="lead">Payment Methods:</p>
                            <div class="row">
                                <div class="col-md-8">
                                    <table class="table table-borderless table-sm">
                                        <tbody>
                                        <tr>
                                            <td>Receptionist:</td>
                                            <td class="text-right">{{ ucfirst(Auth::user()->name) }}</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5 col-sm-12">
                            <p class="lead">Total due</p>
                            <div class="table-responsive">
                                <table class="table">
                                    <tbody>
                                    <tr>
                                        <td class="text-bold-800">Total Paid</td>
                                        <td class="text-bold-800 text-right"> <span class="total"></span></td>
                                    </tr>
                                    <tr class="bg-grey bg-lighten-4">
                                        <td class="text-bold-800">Course Fee Due</td>
                                        <td class="text-bold-800 text-right"><span class="due"></span></td>
                                    </tr>
                                    <tr class="bg-grey bg-lighten-4">
                                        <td class="text-bold-800">Hostel Fee Due</td>
                                        <td class="text-bold-800 text-right"><span class="hostel_due"></span></td>
                                    </tr>
                                    <tr class="bg-grey bg-lighten-4">
                                        <td class="text-bold-800">Total Due Amount</td>
                                        <td class="text-bold-800 text-right"><span class="total_due"></span></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="text-center">
                                <p style="margin-bottom: 70px;">Authorized person</p>

                                <h6>Name</h6>
                                <p class="text-muted">Managing Director</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Invoice Footer -->
                <div id="invoice-footer">
                    <div class="row">
                        <div class="col-md-7 col-sm-12">
                            <h6>Terms & Condition</h6>
                            <p>This Invoice may conatin some errors. So kindly if you face any contact administrator. If the amount you
                                submit isnt same on invoice please contact administration.
                            </p>
                        </div>
                    </div>
                </div>
                <!--/ Invoice Footer -->

            </div>
        </section>
    </div>
@stop

@section('footer-scripts')
<script>
    $(document).ready(function (e) {
        var body = document.getElementsByTagName('body')[0];
        body.classList.remove('menu-expanded');
        body.classList.add("menu-collapsed");
        var invoice = $("#invoice");
        var hostel = JSON.parse(localStorage.hostelInstalment);
        console.log(hostel);
        $(".student_name").html(hostel.student_name);
        $(".contact_no").html(hostel.contact_no);
        $(".email").html(hostel.email);
        $(".date").html(hostel.date);
        var output = "";
        output = "<tr><td>1</td><td>"+hostel.student_name+"</td><td>"+hostel.paid_amount+"</td><td>"+hostel.remaining+"</td></tr>";
        $(".total").html(hostel.paid_amount);
        $(".due").html(hostel.due_amount);
        $(".hostel_due").html(hostel.hostel_due);
        $(".total_due").html(parseInt(hostel.due_amount) + parseInt(hostel.due_amount));
        $(".tbody > tr").remove();
        $(".tbody").append(output);
        window.print();
    });
</script>
@stop