<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Fee Challam Form</title>
    <link href="{{ asset('css/challan.css') }}" rel="stylesheet" type="text/css">
    <style>
            @media print{@page {size: landscape}}
    </style>
</head>
<body>
    <div id="main">
        <div id="section">
            <div id="one">
                <div class="border">
                    <center><span>4</span></center>
                    <center><span class="company_name"></span></center>
                    <center><span class="copy">Bank Copy</span></center>
                    <center><span class="bank"></span></center>
                    <span class="other">Collection A/c # : <span class="account_no"></span></span><br>
                    <span class="other">Branch : <u class="branch"></u></span><br>
                    <span class="other">Dated : <u class="today"></u></span><br>
                    <span class="other">Depositor Name : <u class="student_name"></u></span><br>
                    <span class="other">Father's Name :  <u class="father_name"></u></span>
                    <br>
                    <span class="other">CNIC # :<u class="cnic"></u></span>
                    <br>
                    <span class="other">Purpose Of Deposit <u class="purpose">Fee Deposit</u></span>
                    <br>
                    <span class="other">Mode Of Deposit: Cash/Cheque</span>
                    <br>
                    <span class="other">Cheque N0: ____________________</span>
                    <table border="1px">
                        <thead>
                            <tr>
                                <td>No.</td>
                                <td class="particulars">Particulars</td>
                                <td>Amount</td>
                            </tr>
                        </thead>
                        <tbody class="tbody">
                        </tbody>
                        <tfoot>
                            <td></td>
                            <td class="total">Total:</td>
                            <td><b class="total_amount"></b></td>
                        </tfoot>
                            
                        </tr>
                    </table>
                </div>
                <div class="signature">
                    <span class="officer">Officer</span>
                    <span class="cashier">Cashier</span>
                </div>
                
            </div>
            <div id="two">
                <div class="border">
                    <center><span>3</span></center>
                    <center><span class="company_name"></span></center>
                    <center><span class="copy">Copy For College</span></center>
                    <center><span class="bank"></span></center>
                    <span class="other">Collection A/c # : <span class="account_no"></span></span><br>
                    <span class="other">Branch : <u class="branch"></u></span><br>
                    <span class="other">Dated : <u class="today"></u></span><br>
                    <span class="other">Depositor Name : <u class="student_name"></u></span>
                    <br>
                    <span class="other">Father's Name :  <u class="father_name"></u></span>
                    <br>
                    <span class="other">CNIC # :<u class="cnic"></u></span>
                    <br>
                    <span class="other">Purpose Of Deposit <u class="purpose">Fee Deposit</u></span>
                    <br>
                    <span class="other">Mode Of Deposit: Cash/Cheque</span>
                    <br>
                    <span class="other">Cheque No: ____________________</span>
                    <table border="1px">
                        <thead>
                            <tr>
                                <td>No.</td>
                                <td class="particulars">Particulars</td>
                                <td>Amount</td>
                            </tr>
                        </thead>
                        <tbody class="tbody">
                            
                        </tbody>
                        <tfoot>
                            <tr>
                                <td></td>
                                <td class="total">Total:</td>
                                <td><b class="total_amount"></b></td>
                            </tr>
                        </tfoot>
                        
                    </table>
                </div>
                <div class="signature">
                    <span class="officer">Officer</span>
                    <span class="cashier">Cashier</span>
                </div>
                
            </div>
            <div id="three">
                <div class="border">
                    <center><span>2</span></center>
                    <center><span class="company_name"></span></center>
                    <center><span class="copy">Copy For Department</span></center>
                    <center><span class="bank"></span></center>
                    <span class="other">Collection A/c # : <span class="account_no"></span></span><br>
                    <span class="other">Branch : <u class="branch"></u></span><br>
                    <span class="other">Dated : <u class="today"></u></span><br>
                    <span class="other">Depositor Name : <u class="student_name"></u></span>
                    <br>
                    <span class="other">Father's Name :  <u class="father_name"></u></span>
                    <br>
                    <span class="other">CNIC # :<u class="cnic"></u></span>
                    <br>
                    <span class="other">Purpose Of Deposit <u class="purpose">Fee Deposit</u></span>
                    <br>
                    <span class="other">Mode Of Deposit: Cash/Cheque</span>
                    <br>
                    <span class="other">Cheque N0: ____________________</span>
                    <table border="1px">
                        <thead>
                            <tr>
                                <td>No.</td>
                                <td class="particulars">Particulars</td>
                                <td>Amount</td>
                            </tr>
                        </thead>
                        <tbody class="tbody">

                        </tbody>
                        <tfoot>
                            <tr>
                                <td></td>
                                <td class="total">Total:</td>
                                <td><b class="total_amount"></b></td>
                            </tr>
                        </tfoot>
                        
                    </table>
                </div>
                <div class="signature">
                    <span class="officer">Officer</span>
                    <span class="cashier">Cashier</span>
                </div>
                
            </div>
            <div id="four">
                <div class="border-last">
                    <center><span>1</span></center>
                    <center><span class="company_name"></span></center>
                    <center><span class="copy">Depositor's Copy</span></center>
                    <center><span class="bank"></span></center>
                    <span class="other">Collection A/c # :<span class="account_no"></span></span><br>
                    <span class="other">Branch : <u class="branch"></u></span><br>
                    <span class="other">Dated : <u class="today"></u></span><br>
                    <span class="other">Depositor Name : <u class="student_name"></u></span><br>
                    <span class="other">Father's Name :  <u class="father_name"></u></span>
                    <br>
                    <span class="other">CNIC # :<u class="cnic"></u></span>
                    <br>
                    <span class="other">Purpose Of Deposit <u class="purpose">Fee Deposit</u></span>
                    <br>
                    <span class="other">Mode Of Deposit: Cash/Cheque</span>
                    <br>
                    <span class="other">Cheque No: ____________________</span>
                    <table border="1px">
                        <thead>
                            <tr>
                                <td>No.</td>
                                <td class="particulars">Particulars</td>
                                <td>Amount</td>
                            </tr>
                        </thead>
                        <tbody class="tbody">

                        </tbody>
                        <tfoot>
                            <tr>
                                <td></td>
                                <td class="total">Total:</td>
                                <td><b class="total_amount"></b></td>
                            </tr>
                        </tfoot>
                        
                    </table>
                </div>
                <div class="signature">
                    <span class="officer">Officer</span>
                    <span class="cashier">Cashier</span>
                </div>
                
            </div>
                        
        </div>
    </div>
</body>
<script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>
<script>
    var data = JSON.parse(localStorage.challanFormData);

    var today = new Date();
    $(".company_name").html(data.branch.name);
    $(".branch").html(data.bank.bank_branch);
    $(".account_no").html(data.bank.account_no);
    $(".bank").html(data.bank.name);
    $(".today").html(today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate());
    $(".student_name").html(data.student.student_name.toUpperCase());
    $(".father_name").html(data.student.father_name);
    data.student.id_card == null ? $(".cnic").html("N/A") : $(".cnic").html(data.student.id_card);
    
    var i = 0;
    var output = "";
    var total = 0;
    if(data.instalments.length == 0) {
        for(i=i+1;i<22;i++) {
            output+= "<tr><td class='sr_no'>"+i+"</td><td></td><td></td></tr>";
        }
    } else {
        data.instalments.forEach(function(instalment) {
            i++;
            total += parseInt(instalment.instalment_price);
            output += "<tr><td class='sr_no'>"+i+"</td><td class='particulars'>"+instalment.course_name+"</td><td>"+instalment.instalment_price+"</td></tr>";
        });
        for(i=i+1;i<22;i++) {
            output+= "<tr><td class='sr_no'>"+i+"</td><td></td><td></td></tr>";
        }    
    }
    
    $(".tbody > tr").remove();
    $("tbody").html(output);
    $(".total_amount").html(total);
    console.log(data);
    window.print();
</script>
</html>