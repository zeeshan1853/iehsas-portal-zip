<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>{{ config('app.name') }}</title>
    <style>
        body{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
    </style>
</head>
<body>
    <h4>Dear {{ ucfirst($enquiry->student_name) }}</h4>
    <h5>Greeting From {{ ucfirst(config('app.name')) }}</h5>
    {!! $email->content !!}
</body>
</html>