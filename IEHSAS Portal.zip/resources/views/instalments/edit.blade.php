@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/forms/selects/select2.min.css')}}" rel="stylesheet" type="text/css">

@stop

@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('instalment.update',['id'=>$instalment->id])}}" id="instalmentForm">
                    @csrf
                    <input type="hidden" name="payment_id" value="{{ $instalment->payment_id }}">
                    <input type="hidden" name="course_id" value="{{ $instalment->course_id }}">
                    <input type="hidden" name="batch_id" value="{{ $instalment->batch_id }}">
                    <input type="hidden" name="student_id" value="{{ $instalment->student_id }}">
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Paid Amount</label>
                                    <div class="col-md-9">
                                        <div class="input-group">
                                            <input type="text" @if(old('paid_amount')) value="{{ old('paid_amount') }}" @else value="{{ $instalment->paid_amount }}" @endif  class="form-control {{$errors->has('paid_amount') ? 'is-invalid' : ''}}" placeholder="Paid Amount" aria-label="Amount (to the nearest dollar)" name="paid_amount" id="paidAmount">
                                        </div>
                                    </div>
                                    <span class="offset-md-4 text-danger"></span>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="form-actions ">
                        <input type="submit" value="Update" id="btnAdd" class="btn btn-info offset-md-5">
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/forms/select/select2.full.min.js')}}"></script>

@stop

