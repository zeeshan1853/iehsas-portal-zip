@extends('app')

@section('header-styles')

@stop

@section('main')
<div class="row">
    <div class="card col-md-12 ">
        <div class="card-body">
            <table class="table table-bordered table-striped" id="feedbacks">
                <thead class="bg-primary text-white text-center">
                    <tr>
                        <th>Sr.No</th>
                        <th>Student Name</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>

                </thead>
                <tbody class="text-center">
                    @php $i=1; @endphp
                    @foreach($feedbacks as $feedback)
                    <tr>
                        <td>{{ $i++ }}</td>
                        <td>{{ $feedback['student_name'] }}</td>
                        @if($feedback['id'] == 0)
                        <td><i class="badge badge-danger">Pending</i></td>
                        @else
                        <td><i class="badge badge-success">Submited</i></td>
                        @endif
                        @if($feedback['id'] != 0)
                        <td>
                            <a href="#" title="Print Student Feedback Form" class="btn btn-sm btn-primary print"
                                data-id="{{ $feedback['id'] }}"><span class="ft-printer"></span> Print</a>
                            <a href="#" title="View Student Feedback Form" class="btn btn-sm btn-primary view"
                                data-id="{{ $feedback['id'] }}"><span class="ft-eye"></span> Feedback</a>
                        </td>
                        @else
                        <td></td>
                        @endif

                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- Feedback Modal --->
<div class="modal fade text-left" id="feedbackModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-cyan">
                <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Batch Assessment Report</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table class="table table-striped table-bordered">
                    <thead class="bg-info text-white">
                        <tr>
                            <th>Observations</th>
                            <th>Unsatisfied</th>
                            <th>Saisfied</th>
                            <th>Remarks / Improvement Plan</th>
                        </tr>
                    </thead>
                    <tbody class="tbody">

                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
</div>
@stop

@section('footer-scripts')
<script>
    $(document).ready(function(e) {
        $(".view").click(function(e) {
            var id = $(this).data("id");
            var route = "{{ route('studentRandomFeedback.show',':id') }}";
            route = route.replace(":id",id);
            $.ajax({
                url:route,
                dataType:'JSON',
                type:'GET',
                complete:function(jqXHR,textStatus) {
                    if(jqXHR.status == 200) {
                        var result = JSON.parse(jqXHR.responseText);
                        var output = "";
                        if(result.hasOwnProperty('success')) {
                            var feedback = result.feedback;
                            output += "<tr>";
                            output += "<td>Did the tutor explain well the qualification overview </td>";
                            output += feedbackStatus(feedback.overview);
                            output += feedback.overview_remarks == "" ? "<td>N/A</td>" : "<td>"+feedback.overview_remarks+"</td>";
                            output +="</tr>";

                            output += "<tr>";
                            output += "<td>Did the tutor explain well about the command words </td>";
                            output += feedbackStatus(feedback.words);
                            output += feedback.words_remarks == "" ? "<td>N/A</td>" : "<td>"+feedback.words_remarks+"</td>";
                            output +="</tr>";

                            output += "<tr>";
                            output += "<td>Did the tutor explain well examination pattern </td>";
                            output += feedbackStatus(feedback.examination);
                            output += feedback.examination_remarks == "" ? "<td>N/A</td>" : "<td>"+feedback.examination_remarks+"</td>";
                            output +="</tr>";

                            output += "<tr>";
                            output += "<td>How did the tutor teach IGC 1? </td>";
                            output += feedbackStatus(feedback.teach);
                            output += feedback.teach_remarks == "" ? "<td>N/A</td>" : "<td>"+feedback.teach_remarks+"</td>";
                            output +="</tr>";

                            output += "<tr>";
                            output += "<td>Did the tutor explain well the management system cycle ?</td>";
                            output += feedbackStatus(feedback.cycle);
                            output += feedback.cyce_remarks == "" ? "<td>N/A</td>" : "<td>"+feedback.cycle_remarks+"</td>";
                            output +="</tr>";

                            output += "<tr>";
                            output += "<td>Did the tutor give learner the homework assignments ?</td>";
                            output += feedbackStatus(feedback.homework);
                            output += feedback.homework_remarks == "" ? "<td>N/A</td>" : "<td>"+feedback.homework_remarks+"</td>";
                            output +="</tr>";

                            output += "<tr>";
                            output += "<td>Did the learner participate into group discussion ?</td>";
                            output += feedbackStatus(feedback.discussion);
                            output += feedback.discussion_remarks == "" ? "<td>N/A</td>" : "<td>"+feedback.discussion_remarks+"</td>";
                            output +="</tr>";

                            output += "<tr>";
                            output += "<td>How well the tutor presents the relevant videos ?</td>";
                            output += feedbackStatus(feedback.video);
                            output += feedback.video_remarks == "" ? "<td>N/A</td>" : "<td>"+feedback.video_remarks+"</td>";
                            output +="</tr>";
                            $(".tbody > tr").remove();
                            $(".tbody").append(output);
                            $("#feedbackModal").modal();
                        }
                    }
                }
            });
        });
        $(".print").click(function(e) {
            var id = $(this).data("id");
            var route = "{{ route('studentRandomFeedback.show',':id') }}";
            route = route.replace(":id",id);
            $.ajax({
                url:route,
                dataType:'JSON',
                type:'GET',
                complete:function(jqXHR,textStatus) {
                    if(jqXHR.status == 200) {
                        var result = JSON.parse(jqXHR.responseText);
                        var output = "";
                        if(result.hasOwnProperty('success')) {
                            var feedback = result.feedback;
                            var batch = result.batch;
                            localStorage.setItem("feedback",JSON.stringify(feedback));
                            localStorage.setItem("batch",JSON.stringify(batch));
                            window.open("{{ route('studentRandomFeedback.print') }}");
                        }
                    }
                }
            });
        });
    });
    function feedbackStatus(feedback) {
        var output = "";
        if(feedback == 1) {
            output += "<td></td><td><i class='ft-check'></i></td>"
        } else {
            output += "<td><i class='ft-check'></i></td><td></td>"
        }
        return output;
    }
</script>
@stop