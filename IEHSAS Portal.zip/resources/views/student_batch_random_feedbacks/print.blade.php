<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Feedback</title>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <style>
        body{
            font-size: 18px;
        }
        table {
            border-collapse: collapse;
            width:100%;
        }
        table tbody {
            font-size: 20px;
        }
        .center {
            text-align: center;
        }
        .left {
            text-align: left;
        }
    </style>
</head>
<body>
    <center><img src="{{ asset('images/logo/tcx.png') }}" width="200px"></center>
    <center><h2>Tutor Observation Form</h2></center>
    <table border="1px" style="margin-bottom: 20px;">
        <tr>
            <th>Tutor Name</th>
            <th class="tutor_name"></th>
            <th>Observer Name</th>
            <th class="observer_name"></th>
            <th>Session</th>
            <th class="session"></th>
        </tr>
    </table>
    <table border="1px">
        <thead>
            <tr>
                <th>Observations</th>
                <th>Unsatisfied</th>
                <th>Satisfied</th>
                <th>Remarks/ Improvement plan</th>
            </tr>
        </thead>
        <tbody class="tbody center">
        </tbody>
    </table>
</body>
</html>
<script>
    document.addEventListener("DOMContentLoaded",function(e) {
        var feedback = JSON.parse(localStorage.getItem("feedback"));
        var output = "";
        output += "<tr>";
        output += "<td class='left'>Did the tutor explain well the qualification overview </td>";
        output += feedbackStatus(feedback.overview);
        output += feedback.overview_remarks == null ? "<td>N/A</td>" : "<td class='left'>"+feedback.overview_remarks+"</td>";
        output +="</tr>";

        output += "<tr>";
        output += "<td class='left'>Did the tutor explain well about the command words </td>";
        output += feedbackStatus(feedback.words);
        output += feedback.words_remarks == null ? "<td>N/A</td>" : "<td class='left'>"+feedback.words_remarks+"</td>";
        output +="</tr>";

        output += "<tr>";
        output += "<td class='left'>Did the tutor explain well examination pattern </td>";
        output += feedbackStatus(feedback.examination);
        output += feedback.examination_remarks == null ? "<td>N/A</td>" : "<td class='left'>"+feedback.examination_remarks+"</td>";
        output +="</tr>";

        output += "<tr>";
        output += "<td class='left'>How did the tutor teach IGC 1? </td>";
        output += feedbackStatus(feedback.teach);
        output += feedback.teach_remarks == null ? "<td>N/A</td>" : "<td class='left'>"+feedback.teach_remarks+"</td>";
        output +="</tr>";

        output += "<tr>";
        output += "<td class='left'>Did the tutor explain well the management system cycle ?</td>";
        output += feedbackStatus(feedback.cycle);
        output += feedback.cyce_remarks == null ? "<td>N/A</td>" : "<td class='left'>"+feedback.cycle_remarks+"</td>";
        output +="</tr>";

        output += "<tr>";
        output += "<td class='left'>Did the tutor give learner the homework assignments ?</td>";
        output += feedbackStatus(feedback.homework);
        output += feedback.homework_remarks == null ? "<td>N/A</td>" : "<td class='left'>"+feedback.homework_remarks+"</td>";
        output +="</tr>";

        output += "<tr>";
        output += "<td class='left'>Did the learner participate into group discussion ?</td>";
        output += feedbackStatus(feedback.discussion);
        output += feedback.discussion_remarks == null ? "<td>N/A</td>" : "<td class='left'>"+feedback.discussion_remarks+"</td>";
        output +="</tr>";

        output += "<tr>";
        output += "<td class='left'>How well the tutor presents the relevant videos ?</td>";
        output += feedbackStatus(feedback.video);
        output += feedback.video_remarks == null ? "<td>N/A</td>" : "<td class='left'>"+feedback.video_remarks+"</td>";
        output +="</tr>";
        var tbody = document.querySelector(".tbody");
        //remove childerens
        while(tbody.hasChildNodes()) {
            tbody.removeChild(tbody.lastChild);
        }
        tbody.innerHTML += output;
        var batch = JSON.parse(localStorage.getItem("batch"));
        var tutor_name = document.querySelector(".tutor_name");
        var observer_name = document.querySelector(".observer_name");
        var session = document.querySelector(".session");
        tutor_name.innerHTML = batch.teacher_name;
        observer_name.innerHTML = batch.student_name;
        session.innerHTML = batch.batch_name;
        //localStorage.removeItem("feedback");
        //localStorage.removeItem("batch");
    });
    function feedbackStatus(feedback) {
        var output = "";
        if(feedback == 1) {
            output += "<td></td><td><i class='fa fa-check'></i></td>"
        } else {
            output += "<td><i class='fa fa-check'></i></td><td></td>"
        }
        return output;
    }
</script>