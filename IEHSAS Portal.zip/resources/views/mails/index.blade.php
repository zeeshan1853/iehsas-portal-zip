@extends('app')

@section('header-styles')
    <link href="{{asset('vendors/css/tables/datatable/datatables.min.css')}}" rel="stylesheet" type="text/css">
@stop


@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="mailsData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">For</td>
                        <td data-column-id="content">Content</td>
                        <td data-column-id="edit" data-sortable="false">Action</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    @foreach ($emails as $email)
                        <tr>
                            <td>{{ $i++ }}</td>
                            <td>{{ $email->for }}</td>
                            <td>{!! str_limit(strip_tags($email->content),50) !!}</td>
                            <td>
                                <a href="{{ route('email.edit',['id'=>$email->id]) }}"><i class="ft-edit"></i></a>
                                <a href="{{ route('email.delete',['id'=>$email->id]) }}"><i class="ft-trash" style="color:red;"></i></a>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/tables/datatable/datatables.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-styling.min.js')}}"></script>
    <script src="{{asset('js/scripts/tables/datatables/datatable-basic.min.js')}}"></script>
    <script>
        $(document).ready(function(e) {
            $("#mailsData").DataTable();
        })
    </script>
@stop