<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <style>
        table {
            border-collapse: collapse;
            width:100%;
        }
        h3{
            text-align: center;
        }
        
    </style>
    <title>Student Batch Quiz Report</title>
</head>
<body>
    <center><img src="{{ asset(Auth::user()->branch->setting->logo) }}" width="100"></center>
    <h3>Batch Quiz Report</h3>
    <table border="1px">
        <thead class="quiz_thead">

        </thead>
        <tbody class="quiz_tbody">

        </tbody>
    </table>
</body>
</html>
<script>
    $(document).ready((e)=> {
        if(localStorage.quizzes != "") {
            var results = JSON.parse(localStorage.quizzes);
            var totalQuiz = results.total_quiz;
            var tbody = "";
            var totalObtain = 0;
            var total = 0;
            var thead = "<tr><th>Sr.No</th><th>Student Name</th>";
            for(var i = 1;i<=2;i++) {
                thead += "<th>Test # "+i+"</th>";
            }
            thead += "<th>Total</th>"
            thead += "<th>Total (%)</th>";
            thead += "</tr>";
            delete results.total_quiz;
            var results = results;
            console.log(results);
            var i = 0;
            for(var res in results) {
                i++;
                tbody += "<tr><td>"+i+"</td><td>"+results[res].student_name+"</td>";
                delete results[res].student_name;
                
                var quizResult = results[res];
                for(var r in quizResult) {
                    tbody += "<td>"+quizResult[r].obtain_marks+"</td>";
                    totalObtain += quizResult[r].obtain_marks == "N/A" ? 0 : parseInt(quizResult[r].obtain_marks);
                    total += quizResult[r].total_marks == "N/A" ? 0 : parseInt(quizResult[r].total_marks);
                }
                tbody += "<td>"+totalObtain+"</td>";
                var percentage = ((parseInt(totalObtain) / parseInt(total)) * 100).toFixed(2);
                tbody += "<td>"+percentage+"</td>";
                tbody += "</tr>";
            }
            $(".quiz_thead > tr").remove();
            $(".quiz_tbody > tr").remove();
            $(".quiz_thead").append(thead);
            $(".quiz_tbody").append(tbody);
            window.print();
        }
    });
</script>