@extends('app')

@section('header-styles')
<link href="{{asset('vendors/css/forms/selects/select2.min.css')}}" rel="stylesheet" type="text/css">
@stop

@section('main')
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="{{route('outgoingCertificate.update',['id'=>$outgoing->id])}}" enctype="multipart/form-data">
                    @csrf
                    <input type="hidden" name="branch_id" value="{{Auth::user()->branch->id}}">
                    <input type="hidden" name="certificate_id" value="{{ $outgoing->certificate->id }}">
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Certificate No</label>
                                    <div class="col-md-9">
                                        <input type="text" id="courierName" autofocus @if(old('courier_name') == '') value="{{ $outgoing->courier_name }}" @else vlaue="{{ old('courier_name') }}" @endif class="form-control {{$errors->has('courier_name') ? 'border-danger' : ''}}" placeholder="Enter Courier Name" name="courier_name">
                                        @if($errors->has('courier_name'))
                                            <span class=" text-danger">{{ $errors->first('courier_name') }}</span>
                                        @endif
                                    </div>
                                </div>

                            </div>

                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Tracking No</label>
                                    <div class="col-md-9">
                                        <input type="text" id="trackingNo" @if(old('tracking_no') == '') value="{{ $outgoing->tracking_no }}" @else value="{{ old('tracking_no') }}" @endif class="form-control {{$errors->has('tracking_no') ? 'border-danger' : ''}}" placeholder="Enter Tracking No" name="tracking_no">
                                        @if($errors->has('tracking_no'))
                                            <span class=" text-danger">{{ $errors->first('tracking_no') }}</span>
                                        @endif
                                    </div>
                                </div>

                            </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Dispatcher</label>
                                    <div class="col-md-9">
                                        <input type="text" id="dispatcher" @if(old('dispatcher') == '') value="{{ $outgoing->dispatcher }}" @else {{ old('dispatcher') }} @endif class="form-control {{$errors->has('dispatcher') ? 'border-danger' : ''}}" placeholder="Enter Dispatcher Name" name="dispatcher">
                                        @if($errors->has('dispatcher'))
                                            <span class=" text-danger">{{ $errors->first('dispatcher') }}</span>
                                        @endif
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Update" id="btnAdd" class="btn btn-primary">
                        {{--<input type="submit" value="Print Invoice" id="btnAdd" class="btn btn-success">--}}
                    </div>
                </form>
            </div>
        </div>
    </div>

@stop


@section('footer-scripts')
    <script src="{{asset('vendors/js/forms/select/select2.full.min.js')}}"></script>

@stop

