@extends('layouts.app')

@section('header-styles')


@stop

@section('main')
<div id="app">
    <div class="row">
        <add-permission :path="'{{ url('/admin') }}'" :asset="'{{ asset('/') }}'"></add-permission>
        <role-permissions :path="'{{ url('/admin') }}'" :asset="'{{ asset('/') }}'"></role-permissions>
    </div>    
</div>


@stop

@section('footer-scripts')
<script src="{{ asset('js/app.js') }}"></script>
@stop