@extends('app')

@section('header-styles')
{{--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">  --}}

<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="{{ asset('css/jquery.bootgrid.min.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('css/bootgridcustom.css') }}" rel="stylesheet" type="text/css">
@stop

@section('main')
<div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered" id="users">
                    <thead >
                        <tr class="bg-info text-white">
                            <td data-column-id="sr_no">Sr.No</td>
                            <td data-column-id="name">User Name</td>
                            <td data-column-id="email">Email</td>
                            <td data-column-id="password">Password</td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Sohaib</td>
                            <td>sohaib@yahoo.com</td>
                            <td>abc</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Sohaib</td>
                            <td>sohaib@yahoo.com</td>
                            <td>abc</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Sohaib</td>
                            <td>sohaib@yahoo.com</td>
                            <td>abc</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Sohaib</td>
                            <td>sohaib@yahoo.com</td>
                            <td>abc</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Sohaib</td>
                            <td>sohaib@yahoo.com</td>
                            <td>abc</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Sohaib</td>
                            <td>sohaib@yahoo.com</td>
                            <td>abc</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Sohaib</td>
                            <td>sohaib@yahoo.com</td>
                            <td>abc</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Sohaib</td>
                            <td>sohaib@yahoo.com</td>
                            <td>abc</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Sohaib</td>
                            <td>sohaib@yahoo.com</td>
                            <td>abc</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Sohaib</td>
                            <td>sohaib@yahoo.com</td>
                            <td>abc</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Sohaib</td>
                            <td>sohaib@yahoo.com</td>
                            <td>abc</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Sohaib</td>
                            <td>sohaib@yahoo.com</td>
                            <td>abc</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Sohaib</td>
                            <td>sohaib@yahoo.com</td>
                            <td>abc</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Sohaib</td>
                            <td>sohaib@yahoo.com</td>
                            <td>abc</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
</div>

@stop

@section('footer-scripts')
<script src="{{ asset('js/jquery.bootgrid.min.js') }}"></script>
<script src="{{ asset('js/jquery.bootgrid.fa.min.js') }}"></script>
<script>
    $(document).ready(function(e) {
        $("#users").bootgrid({
        });
    });
    
</script>
@stop