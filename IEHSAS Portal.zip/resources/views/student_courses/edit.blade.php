@extends('app')

@section('header-styles')

@stop



@section('main')
<div class="row">
    <div class="card col-md-12">
        <div class="card-body">
            <form class="form form-horizontal" method="post" action="{{ route('studentCourses.update',['id'=>$student_courses->id]) }}" enctype="multipart/form-data">
                @csrf
                <div class="form-body">
                    <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group row">
                                <label class="col-md-3 label-control" for="userinput2">Share Price</label>
                                <div class="col-md-9">
                                    <input type="text" id="sharePrice" autofocus value="{{ $student_courses->share }}" class="form-control {{ $errors->has('share') ? 'is-invalid' : ''}}" placeholder="Share Price" name="share">
                                    <!-- Error Field -->
                                    @if($errors->has('share'))
                                        <span class="text-danger ">{{ $errors->first('share') }}</span>
                                    @endif
                                </div>

                            </div>
                        </div>
                        <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Hostel Fee</label>
                                    <div class="col-md-9">
                                        <input type="text" name="hostel_fee" value="{{ $student_courses->hostel_fee }}" placeholder="Hostel Fee" class="form-control {{ $errors->has('hostel_fee') ? 'is-invalid' : '' }} ">
                                        @if($errors->has('hostel_fee'))
                                            <span class="text-danger ">{{ $errors->first('hostel_fee') }}</span>
                                        @endif
                                    </div>

                                </div>
                            </div>
                    </div>

                    @php
                        $course = preg_split("/ /",$student_courses->course->course_name);
                    @endphp
                    @if(in_array("nebosh",$course) || in_array("Nebosh",$course)) 
                        <input type="hidden" name="nebosh">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Fresh / Resit</label>
                                    <div class="col-md-9">
                                        <input type="text" id="freshResit" value="{{ $student_courses->fresh_resit }}" placeholder="Fresh / Resit ?" class="form-control {{ $errors->has('fresh_resit') ? 'is-invalid' : '' }}"  name="fresh_resit">
                                    </div>
                                    @if($errors->has('fresh_resit'))
                                        <span class="text-danger offset-md-4">{{ $errors->first('fresh_resit') }}</span>
                                    @endif
                                    
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Units</label>
                                    <div class="col-md-9">
                                        <input type="number" id="units" value="{{ $student_courses->units }}" class="form-control {{ $errors->has('units') ? 'is-invalid' : '' }}" placeholder="Enter No of Units"  name="units">
                                    </div>
                                    @if($errors->has('units'))
                                        <span class="text-danger offset-md-4">{{ $errors->first('units') }}</span>
                                    @endif
                                </div>
                            </div>
    
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Center</label>
                                    <div class="col-md-9">
                                        <input type="text" name="center" value="{{ $student_courses->center }}" placeholder="Enter Center Name" class="form-control {{ $errors->has('center') ? 'is-invalid' : '' }}">
                                        @if($errors->has('center'))
                                            <span class="text-danger">{{$errors->first('center')}}</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Nebosh Student ID</label>
                                    <div class="col-md-9">
                                        <input type="text" placeholder="Enter Nebosh Student ID" value="{{ $student_courses->nebosh_student_id }}" class="form-control {{ $errors->has('nebosh_student_id') ? 'is-invalid' : '' }}" name="nebosh_student_id">
                                        @if($errors->has('nebosh_student_id'))
                                            <span class="text-danger">{{$errors->first('nebosh_student_id')}}</span>
                                        @endif
                                    </div>
    
                                </div>
                            </div>
                        </div>
                    @endif
                    @php
                        $i = 1;
                    @endphp
                    @foreach($student_courses->examDates as $date)
                    
                    <div class="row">
                        <div class="offset-md-2 col-md-6">
                            <div class="form-group row">
                                <label for="Exam Date" class="col-md-3">Exam Date {{ $i++ }}</label>
                                <div class="col-md-9">
                                    <div class="input-group">
                                        <input type="date" class="date form-control" name="exam_date[]" value="{{ $date->exam_date->format('Y-m-d') }}">
                                        <span class="input-group-append mt-1">
                                            &nbsp;&nbsp;
                                            <input type="checkbox" name="willing[]" @if($date->willing == 1) checked @endif value="1">
                                        </span>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>

                    @endforeach
                </div>

                <div class="form-actions text-center">
                    <input type="submit" value="Update" id="btnAdd" class="btn btn-primary">
                    {{--<input type="submit" value="Print Invoice" id="btnAdd" class="btn btn-success">--}}
                </div>
            </form>
        </div>
    </div>
</div>

@stop


@section('footer-scripts')
<script>
        
</script>
@stop