@extends('app')


@section('header-styles')
<link href="{{asset('css/jasny-bootstrap.min.css')}}" rel="stylesheet" type="text/css">

@stop

@section('main')
<div class="row">
    <div class="card col-md-8 offset-md-2">
        <div class="card-body">
            <form method="post" action="{{ route('user.updatePassword') }}">
                @csrf
                <h4 class="form-section"><i class="ft-info"></i> {{$page_heading}}</h4>
                <div class="form-group">
                    <label>
                        <h5 class="mt-2">Old Password:</h5>
                    </label>
                    <input type="password" name="old_password" class="form-control {{$errors->has('old_password') ? 'is-invalid' : ''}}"
                        id="basicInput" placeholder="Enter Old Password">
                    <span class="text-danger">
                        @if($errors->has('old_password'))
                        {{$errors->first('old_password')}}
                        @endif
                    </span>
                </div>
                <div class="form-group">
                    <label><h5 class="mt-2">New Password:</h5></label>
                    <input type="password" name="password" class="form-control {{$errors->has('password') ? 'is-invalid' : ''}}"
                        id="basicInput" placeholder="Enter New Password">
                    <span class="text-danger">
                        @if($errors->has('password'))
                        {{$errors->first('password')}}
                        @endif
                    </span>
                </div>
                <div class="form-group">
                    <label><h5 class="mt-2">Confirm Password:</h5></label>
                    <input type="password" name="password_confirmation" class="form-control {{$errors->has('password_confirmation') ? 'is-invalid' : ''}}"
                        id="basicInput" placeholder="Confirm Password">
                    <span class="text-danger">
                        @if($errors->has('password_confirmation'))
                        {{$errors->first('password_confirmation')}}
                        @endif
                    </span>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary offset-md-4 col-md-4">
                        Edit Profile
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@stop

@section('footer-scripts')
<script src="{{asset('js/jasny-bootstrap.min.js')}}"></script>
@stop