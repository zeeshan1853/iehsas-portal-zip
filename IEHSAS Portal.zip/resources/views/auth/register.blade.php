@extends('app')


@section('header-styles')
<link href="{{asset('css/jasny-bootstrap.min.css')}}" rel="stylesheet" type="text/css">
@stop

@section('main')
    <div class="row">
        <div class="card col-md-8 offset-md-2">
            <div class="card-body">
                <form method="post" action="{{route('user.save_user')}}" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group">
                        <label><h5 class="mt-2">User Name:</h5></label>
                        <input type="text" name="name" class="form-control {{$errors->has('name') ? 'is-invalid' : ''}}" id="basicInput" placeholder="User Name" value="{{old('name')}}">
                        <span class="text-danger">
                            @if($errors->has('name'))
                                {{$errors->first('name')}}
                            @endif
                        </span>
                    </div>
                    <div class="form-group">
                        <label><h5 class="mt-2">Email:</h5></label>
                        <input type="text" name="email" class="form-control {{$errors->has('email') ? 'is-invalid' : ''}}" id="basicInput" placeholder="Email" value="{{old('email')}}">
                        <span class="text-danger">
                            @if($errors->has('email'))
                                {{$errors->first('email')}}
                            @endif
                        </span>
                    </div>
                    <div class="form-group">
                        <label><h5 class="mt-2">Password:</h5></label>
                        <input type="password" name="password" class="form-control {{$errors->has('password') ? 'is-invalid' : ''}}" id="basicInput" placeholder="Password">
                        <span class="text-danger">
                            @if($errors->has('password'))
                                {{$errors->first('password')}}
                            @endif
                        </span>
                    </div>
                    <div class="form-group">
                        <label><h5 class="mt-2">Confirm Password:</h5></label>
                        <input type="password" name="password_confirmation" class="form-control " id="basicInput" placeholder="Confirm Password">
                        <span class="text-danger"></span>
                    </div>

                    <div class="form-group">
                        <label><h5 class="mt-2">Select Branch:</h5></label>
                        <select class="form-control @if($errors->has('branch_id')) is-invalid @endif" name="branch_id" >
                            <option value="">--Select Branch--</option>
                            @foreach($branches as $branch)
                                <option value="{{$branch->id}}">{{ $branch->name }}</option>
                            @endforeach
                        </select>
                        @if($errors->has('branch_id'))
                            <span class="text-danger">{{ $errors->first('branch_id') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label><h5 class="mt-2">Select Role:</h5></label>
                        <select class="form-control @if($errors->has('role_id')) is-invalid @endif" name="role_id" >
                            <option value="">--Select Role--</option>
                            @foreach($roles as $role)
                                <option value="{{ $role->id }}">{{ $role->name }}</option>
                            @endforeach
                        </select>
                        @if($errors->has('branch_id'))
                            <span class="text-danger">{{ $errors->first('branch_id') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label>
                            <h5 class="mt-2">Image:</h5>
                        </label>
                        <!-- Student Image-->
                        <div class="form-group">
                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                <div class="fileinput-preview img-thumbnail" data-trigger="fileinput"
                                    style="width: 300px; height: 200px;">
                                </div>
                                <div>
                                    <span class="btn btn-outline-secondary btn-file">
                                        <span class="fileinput-new">Select image</span>
                                        <span class="fileinput-exists">Change</span>
                                        <input type="file" name="image">
                                    </span>
                                    <a href="#" class="btn btn-outline-secondary fileinput-exists"
                                        data-dismiss="fileinput">Remove</a>
                                </div>
                            </div>
                        </div>
                        @if($errors->has('image'))
                        <span class="text-danger offset-md-3">{{$errors->first('image')}}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary offset-md-4 col-md-4" >
                            Add User
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@stop

@section('footer-scripts')
<script src="{{asset('js/jasny-bootstrap.min.js')}}"></script>
@stop


