<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('student-portal/app/css/core/colors/palette-callout.min.css')); ?>">
<style>
    .form-section {
        color: #1D2B36;
        line-height: 3rem;
        margin-bottom: 20px;
        border-bottom: 1px solid #1D2B36;
    }

    .bor {
        border-right: 1px solid grey;
    }
</style>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
    
    <?php if(count($courses) == 0): ?>
    <div class="col-md-12">
        <h3 class="text-danger mt-2 text-center text-bold-700">No Course Found</h3>
    </div>
    <?php else: ?>
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xl-6 col-md-6 col-12">
            <div class="card">
                <div class="text-center">
                    <div class="card-body bg-info" style="padding:15px;">
                        <h3 class="text-bold-700 mb-1 text-white"><?php echo e($course['course_name']); ?></h3>
                        <h6 class="card-subtitle  text-white"><?php echo e($course['batch_name']); ?></h6>
                    </div>
                </div>
                <div class="list-group list-group-flush text-bold-600">
                    <li class="list-group-item">
                        <span class="col-md-6 col-sm-6 bor float-left"><i class="fa fa-clock-o"></i> Duration</span>
                        <span class="col-md-6 col-lg-6 col-sm-6 text-center"><?php echo e($course['duration']); ?> Months</span>
                    </li>
                    <li class="list-group-item">
                        <span class="col-md-6 col-sm-6 bor pull-left"><i class="fa fa-graduation-cap"></i> Tutor</span>
                        <span class="col-md-6 col-sm-6 col-xs-6 text-center"><?php echo e($course['teacher_name']); ?> </span>
                    </li>
                    <li class="list-group-item">
                        <span class="col-md-6 col-sm-6 bor pull-left"><i class="fa fa-calendar"></i> Admission Date</span>
                        <span class="col-md-6 col-sm-6 text-center"><?php echo e($course['admission_date']); ?></span>
                    </li>
                </div>
                <div class="card-footer col-md-12">
                    <center>
                        <a href="" class="btn btn-sm btn-round btn-primary course_exam" data-id="<?php echo e($course['student_course_id']); ?>" title="Check Exam Dates">Exam</a>
                        <a href="<?php echo e(route('student.batchAssessment',['batch_id'=>$course['batch_id'],'student_id'=>Session::get('student_id')])); ?>" class="btn btn-sm btn-info btn-round " title="Check Assessment Result">Assessment</a>
                        <a href="<?php echo e(route('quizResult.index',['id'=>$course['batch_id']])); ?>" class="btn btn-sm btn-rounded btn-amber btn-round " title="Check Quiz Result">Quiz</a>
                        <?php if($course['feedback'] == 1): ?>
                            <span class="badge badge-success" style="border-radius:10px;" title="Your Feedback is submited">Submited <i class="ft-check"></i></span>
                        <?php else: ?>
                            <?php
                                $now = date("Y-m-d");   
                            ?>
                            <?php if($course['end_date'] > $now): ?>
                                <a href="#"   onclick="return false;" class="btn btn-sm btn-primary end btn-round" title="Batch Feedback">Feedback <i class="ft-clock"></i></a>
                                <?php else: ?>
                                <a href="<?php echo e(route('batchFeedback.create',['id'=>$course['student_course_id']])); ?>"   class="btn btn-sm btn-primary btn-round" title="Batch Feedback">Feedback
                                <?php endif; ?>
                            <?php endif; ?>
                            <a href="<?php echo e(route('student.course.type',['id'=>$course['course_id']])); ?>" class="btn btn-sm btn-github btn-round" title="Course Documents">
                                Docs
                            </a>
                            
                            
                    </center>
                </div>
            </div>
        </div>    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

</div>
<!-- Exam Dates Modal -->
<div class="modal fade text-left" id="examModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-cyan">
                <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Course Exam Dates</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table class="table table-striped table-bordered">
                    <tr class="bg-info text-white">
                        <th>Sr.No</th>
                        <th>Exam Date</th>
                        <th>Willingness ?</th>
                        <th>Result Status</th>
                    </tr>
                    <tbody class="tbody">

                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
</div>
<!-- Result Modal -->
<div class="modal fade text-left" id="resultModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-cyan">
                <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Student Exam Result</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <tr>
                            <td>Status</td>
                            <td class="status"></td>
                        </tr>
                        <tr>
                            <td>Total Marks</td>
                            <td class="total_marks"></td>
                        </tr>
                        <tr>
                            <td>Obtain Marks</td>
                            <td class="obtain_marks"></td>
                        </tr>
                        <tr>
                            <td>Certificate</td>
                            <td class="certificate"></td>
                        </tr>
                        <tr>
                            <td>Result Attachments</td>
                            <td class="result_attachment"></td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function(e) {
            //check list of student exam dates
            $(".course_exam").click(function(e) {
                e.preventDefault();
                var id = $(this).data("id");
                var route = "<?php echo e(route('ExamDate.courseExamDate',':id')); ?>";
                route = route.replace(":id",id);
                $.ajax({
                    url:route,
                    dataType:'JSON',
                    type:'GET',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var output = "";
                                var i = 0;
                                result.exam_dates.forEach(function(exam_date) {
                                    i++;
                                    output += "<tr><td>"+i+"</td><td>"+exam_date.exam_date+"</td>";
                                    if(exam_date.willing == 1) {
                                        output += "<td>Yes</td>"
                                    } else {
                                        output += "<td>No</td>"
                                    }
                                    if(exam_date.result_status == "0" ) {
                                        output +="<td><i class='badge badge-primary'>Pending</i> "  
                                                    +"</td>";
                                    } else {
                                        output += "<td><a href='#' class='view-result' data-id='"+exam_date.result_id+"'><i class='badge badge-primary'>Announced &nbsp;&nbsp;<i class='ft-eye'></i> </i> </a></td>";
                                    }
                                    output += "</tr>";
                                    $(".tbody > tr").remove();
                                    $(".tbody").append(output);
                                    $("#examModal").modal();
                                })
                            }
                        }
                    }
                });
            })
            //announced result
            $(document).on("click",".announce",function(e) {
                var id =  $(this).data("id");
                var route = "<?php echo e(route('studentResult.create',':id')); ?>";
                route = route.replace(":id",id);
                window.location.replace(route);
            });
            //view result 
            $(document).on("click",".view-result",function(e) {
                var id = $(this).data("id");
                var route = "<?php echo e(route('studentResult.show',':id')); ?>";
                route = route.replace(":id",id);
                $.ajax({
                    url:route,
                    dataType:'JSON',
                    type:'GET',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var data = result.course_result;
                                if(data.result == "1") {
                                    $(".status").html("Pass");
                                    var status = document.getElementsByClassName("status")[0];
                                    status.parentNode.parentNode.classList += " text-success";
                                } else {
                                    $(".status").html("Fail");   
                                    var status = document.getElementsByClassName("status")[0];
                                    status.parentNode.parentNode.classList += " text-danger";
                                }
                                $(".total_marks").html(data.total_marks);
                                $(".obtain_marks").html(data.obtain_marks);
                                if(data.certificate == "") {
                                    $(".certificate").html("N/A");
                                } else {
                                    $(".certificate").html("<i class='ft-eye'></i>");
                                }
                                if(data.result_attachment == "") {
                                    $(".result_attachment").html("N/A");
                                } else {
                                    $(".result_attachment").html("<i class='ft-eye'></i>");
                                }
                                $("#resultModal").modal();
                            }
                        }
                    }
                });
            });
            $(".end").click(function(e) {
                alert("Batch is Not Over Yet");
            });
            
        })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_student', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>