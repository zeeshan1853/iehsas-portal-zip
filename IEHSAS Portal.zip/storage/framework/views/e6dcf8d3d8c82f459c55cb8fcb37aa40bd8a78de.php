

<?php $__env->startSection('header-styles'); ?>
<link href="<?php echo e(asset('vendors/css/tables/datatable/datatables.min.css')); ?>" rel="stylesheet" type="text/css">
<style>
thead .big-col{
    width:400px !important;
}
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
<section id="base-style">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-content collapse show">
                    <div class="card-body card-dashboard">
                        <table class="table table-striped table-bordered base-style" id="studentsData">
                                <thead>
                                    <tr class="bg-blue " style="color:white;">
                                        <th data-column-id="sr_no">Sr.No</th>
                                        <th data-column-id="name">S. Name</th>
                                        <th data-column-id="type">Type</th>
                                        <th data-column-id="contact_no">Con. No</th>
                                        <th data-column-id="admission_date">Adm Date</th>
                                        <th data-column-id="paid_amount">Paid</th>
                                        <th data-column-id="due_amount">Due</th>
                                        <th data-column-id="course">Course</th>
                                        <th data-column-id="discount">Dis</th>
                                        <th data-column-id="hostel_fee">H. Fee</th>
                                        <th>ID</th>
                                        <th data-column-id="feedback">Feeback</th>
                                        <th data-column-id="delete" data-sortable="false" class="big-col">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 1;
                                    ?>
                                    <?php $__currentLoopData = $batch_students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td><a
                                                href="<?php echo e(route('student.student_instalments',['student_id'=>$student['student_id'],'batch_id'=>$student['batch_id']])); ?>"><?php echo e($student['student_name']); ?> <?php echo e($student['father_name']); ?></a>
                                        </td>
                                        <td><?php echo e($student['type']); ?></td>
                                        <td><?php echo e($student['contact_no']); ?></td>
                                        <td><?php echo e($student['admission_date']); ?></td>
                                        <td><?php echo e($student['paid_amount']); ?></td>
                                        <td><?php echo e($student['due_amount']); ?></td>
                                        <td><?php echo e($student['course_name']); ?></td>
                                        <td><?php echo e($student['discount']); ?></td>
                                        <td><?php echo e($student['hostel_fee']); ?></td>
                                        <?php if($student['id_card'] != ""): ?>
                                        <td><?php echo e($student['id_card']); ?></td>
                                        <?php else: ?>
                                        <td>N/A</td>
                                        <?php endif; ?>
                                        <td>
                                            <?php if($student['facebook'] == "1"): ?>
                                            <span class="ft-facebook" title="Facebook Status (Submited)" style="color:green"></span>
                                            <?php else: ?>
                                            <a href="<?php echo e(route('studentCourse.facebookFeedback',['id'=>$student['student_course_id']])); ?>"><span class="ft-facebook" title="Click to submit feedback" style="color:red"></span></a>
                                            <?php endif; ?>
                                            <?php if($student['feedback']): ?>
                                                <a href="#" data-id="<?php echo e($student['feedback_id']); ?>" class="batch_feedback"><span class="ft-home" title="Insitute Feedback ( Submited )" style="color:green" ></span></a>
                                            <?php else: ?>
                                                <span class="ft-home" title="Insitute Feedback ( Pending )" style="color:red;" ></span>
                                            <?php endif; ?>
                                            
                                            
                                            <?php if($student['google'] == "1"): ?>
                                            <span class="ft-award" title="Google ( Submited ) " style="color:green;"></span>
                                            <?php else: ?>
                                            <a href="<?php echo e(route('studentCourse.googleFeedback',['id'=>$student['student_course_id']])); ?>"><span class="ft-codepen" title="Click to submit feedback " style="color:red;"></span></a>
                                            <?php endif; ?>
                                            
                                        </td>
                                        
                                        <td>
                                            <a href="#" class="view" style="color:green;margin-left: 0px;"
                                                data-id="<?php echo e($student['student_id']); ?>" title="Student History"><i class="ft-eye"></i></a>
                                            <a href="<?php echo e(route('student.edit',['id'=>$student['student_id']])); ?>"
                                                title="Edit Student" class="" style="margin-left: 5px;"><i
                                                    class="ft-edit"></i></a>
                                            <a href="<?php echo e(route('student.print',['id'=>$student['student_id']])); ?>" target="_blank"
                                                style="color:#1ab7ea;margin-left: 5px;"><i class="ft-printer" title="Print Student Registration Form"></i></a>
                                            <a href="<?php echo e(route('studentCourses.edit',['id'=>$student['student_course_id']])); ?>"
                                                style="color:orange;margin-left:5px;" title="Edit Student Course Detail"><i
                                                    class="ft-edit-2"></i></a>
                                            <a href="#" style="color:green;margin-left:5px;" id="quiz" data-batch-id="<?php echo e($student['batch_id']); ?>" data-student-id="<?php echo e($student['student_id']); ?>" title="Check Student Quiz Report">
                                                <span class="ft-activity"></span>
                                            </a>
                                            <br>
                                            <a href="#" title="Course Exam Dates" style="" class="exam_date" data-id="<?php echo e($student['student_course_id']); ?>">
                                                <i class="ft-book"></i>
                                            </a>
                                            <a href="#" title="Check Student Attendance" style="margin-left:5px;" data-batch-id="<?php echo e($student['batch_id']); ?>" data-student-id="<?php echo e($student['student_id']); ?>" class="attendence" >
                                                <i class="ft-monitor"></i>
                                            </a>
                                            <a href="<?php echo e(route('studentCourse.delete',['id'=>$student['student_course_id']])); ?>" title="Delete Student Enrolment" id="delete">
                                                <i class="ft-trash" style="color:red;margin-left:5px;"></i>
                                            </a>
                                            <?php if($student['status'] == 1): ?>
                                                <a href="<?php echo e(route('student.deactive',['id'=>$student['student_id']])); ?>" style="color:red;margin-left:5px;">
                                                    <i class="ft-delete" title="Deactive Student"></i>
                                                </a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('student.active',['id'=>$student['student_id']])); ?>" style="color:green;margin-left:5px;">
                                                    <i class="ft-check-circle" title="Activate Student"></i>
                                                </a>
                                            <?php endif; ?>
                                            <a href="<?php echo e(route('studentAssessment.showAdmin',['batch_id'=>$student['batch_id'],'student_id'=>$student['student_id']])); ?>" style="margin-left:5px;" title="Check Student Batch Assessment Report">
                                                <span class="ft-compass"></span>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Modal for student Data--->
<div class="modal" tabindex="-1" role="dialog" id="myModal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content ">
            <div class="modal-header">
                <center>
                    <h3 class="modal-title">Student Details</h3>
                </center>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <a href="" class="linkStudentImage"><img src="" class="rounded-circle offset-md-4 studentImage"
                        width="100" height="200"></a>
                <hr>
                <div class="row">
                    <h4 class="pull-left offset-md-2 col-md-4">Email</h4>
                    <p class="col-md-6"><b class="email"></b></p>
                </div>
                <div class="clearfix"></div>
                <hr>
                <div class="row">
                    <h4 class="pull-left offset-md-2 col-md-4">Date Of Birth</h4>
                    <p class="col-md-6"><b class="dateOfBirth"></b></p>
                </div>
                <div class="clearfix"></div>
                <hr>
                <div class="row">
                    <h4 class="pull-left offset-md-2 col-md-4">Education</h4>
                    <p class="col-md-6"><b class="education"></b> </p>
                </div>
                <div class="clearfix"></div>
                <hr>
                <div class="row">
                    <h4 class="pull-left offset-md-2 col-md-4">How he find Us ?</h4>
                    <p class="col-md-6"><b class="find"></b> </p>
                </div>
                <div class="clearfix"></div>
                <hr>
                <div class="row">
                    <h4 class="pull-left offset-md-2 col-md-4">Emergency Contact No</h4>
                    <p class="col-md-6"><b class="emergencyContactNo"></b> </p>
                </div>
                <div class="clearfix"></div>
                <hr>
                <div class="row">
                    <h4 class="pull-left offset-md-2 col-md-4">Address</h4>
                    <p class="col-md-6"><b class="address"></b> </p>
                </div>
                <div class="clearfix"></div>
                <hr>
                <div class="row">
                    <h4 class="pull-left offset-md-2 col-md-4">Paid Amount</h4>
                    <p class="col-md-6"><b class="paidAmount"></b> </p>
                </div>
                <div class="clearfix"></div>
                <hr>

                <div class="row">
                    <h4 class="pull-left offset-md-2 col-md-4">Due Amount</h4>
                    <p class="col-md-6"><b class="dueAmount"></b> </p>
                </div>
                <div class="clearfix"></div>
                <hr>
                <div class="row">
                    <h4 class="pull-left offset-md-2 col-md-4">Hostel Fee</h4>
                    <p class="col-md-6"><b class="hostelFee"></b> </p>
                </div>
                <div class="clearfix"></div>
                <hr>
                <div>
                    <h4 class="pull-left offset-md-2">ID Card</h4>
                    <img src="" alt="idCard" class="idCard1 pull-left offset-md-2 img-thumbnail" style="height: 120px;">
                    <img src="" alt="idCard" class="idCard2 pull-left offset-md-1 img-thumbnail" style="height: 120px;">
                </div>
                <div class="clearfix"></div>
                <hr>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Exam Dates Modal -->
<div class="modal fade text-left" id="examModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-cyan">
            <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Course Exam Dates</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <table class="table table-striped table-bordered">
                    <tr class="bg-info text-white">
                        <th>Sr.No</th>
                        <th>Exam Date</th>
                        <th>Willingness ?</th>
                        <th>Result Status</th>
                        <th>Admission</th>
                    </tr>
                    <tbody class="tbody">

                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
        </div>
    </div>
</div>
<!-- Result Modal -->
<div class="modal fade text-left" id="resultModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-cyan">
            <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Student Exam Result</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="exam_result_id" id="examResultId">
                <table class="table table-striped table-bordered">
                    <tr>
                        <td>Status</td>
                        <td class="status"></td>
                    </tr>
                    <tr>
                        <td>Total Marks</td>
                        <td class="total_marks"></td>
                    </tr>
                    <tr>
                        <td>Obtain Marks</td>
                        <td class="obtain_marks"></td>
                    </tr>
                    <tr>
                       <td>Certificate</td> 
                       <td class="certificate"></td>
                    </tr>
                    <tr>
                        <td>Result Attachments</td>
                        <td class="result_attachment"></td>
                    </tr>
                </table>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-info" id="edit">Edit</button>
            </div>
        </div>
        </div>
    </div>
</div>

<!-- Btach Feedback Modal -->
<div class="modal fade text-left" id="feedbackModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-cyan">
            <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Batch Feedback</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <table class="table table-striped table-bordered">
                    <tr>
                        <td class="text-bold-700" colspan="2" >1. How do you rate the overall course ?</td>
                    </tr>
                    <tr>
                        <td class=" course_rating"></td>
                        <td class="course_rating_star">
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-bold-700" colspan="2">Comments</td>
                    </tr>
                    <tr>
                        <td class="course_comments" colspan="2">this is comment section</td>
                    </tr>
                </table>
                <h3>What do you think about your trainer(s) ?</h3>
                <table class="table table-striped table-bordered">
                    <tr>
                        <td class="text-bold-700" colspan="2" >2.How well did they present the course ?</td>
                    </tr>
                    <tr>
                        <td class="text-bold-500 course_present"></td>
                        <td class="course_present_star">
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-bold-700" colspan="2" >3. Did they make the course intresting ?</td>
                    </tr>
                    <tr>
                        <td class="text-bold-500 course_intrest"></td>
                        <td class="course_intrest_star">
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-bold-700" colspan="2" >4. How well did they answer your questions  ?</td>
                    </tr>
                    <tr>
                        <td class="text-bold-500 question"></td>
                        <td class="course_question_star">
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-bold-700" colspan="2">Comments</td>
                    </tr>
                    <tr>
                        <td class="teaching_comments" colspan="2">this is comment section</td>
                    </tr>
                </table>
                <table class="table table-striped table-bordered">
                    <tr>
                        <td class="text-bold-700" colspan="2" >5. How were training facilities ?</td>
                    </tr>
                    <tr>
                        <td class="facilities"></td>
                        <td class="course_rating_facilities">
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                            <span class="ft-star"></span>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-bold-700" colspan="2">Comments</td>
                    </tr>
                    <tr>
                        <td class="facilities_comment" colspan="2"></td>
                    </tr>
                </table>
                <table class="table table-striped table-bordered">
                    <tr>
                        <td class="text-bold-700" colspan="2" >6. How was the Level of this Course ?</td>
                    </tr>
                    <tr>
                        <td class="difficulty text-center" colspan="2" ></td>
                    </tr>
                    <tr>
                        <td class="text-bold-700" colspan="2">Comments</td>
                    </tr>
                    <tr>
                        <td class="course_suggestion" colspan="2">this is comment section</td>
                    </tr>
                </table>
                <table class="table table-striped table-bordered">
                    <tr>
                        <td class="text-bold-700" colspan="2" >7. What did you enjoy most and least about the course and why Give reason ?</td>
                    </tr>
                    <tr>
                        <td class="enjoy" colspan="2" ></td>
                    </tr>
                </table>
                <table class="table table-striped table-bordered">
                    <tr>
                        <td class="text-bold-700" colspan="2" >8. Whould you like to recommend this course toothers ?</td>
                    </tr>
                    <tr>
                        <td class="recommend"></td>
                    </tr>
                    <tr>
                        <td class="text-bold-700" colspan="2">Comments</td>
                    </tr>
                    <tr>
                        <td class="recommend_to " colspan="2"></td>
                    </tr>
                </table>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
        </div>
    </div>
</div>

<!-- Quiz Modal -->
<div class="modal fade text-left" id="quizModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-cyan">
            <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Student Quizzes Result</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="exam_result_id" id="examResultId">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Sr.No</th>
                            <th>Quiz No</th>
                            <th>Obtain Marks</th>
                            <th>Reamarks</th>
                        </tr>
                    </thead>
                    <tbody class="quiz_tbody"></tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button> 
            </div>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
<script src="<?php echo e(asset('vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/scripts/tables/datatables/datatable-styling.min.js')); ?>"></script>
<script>
    $(document).ready(function(e) {
            setTimeout(()=>{
                var body = document.getElementsByTagName('body')[0];
                body.classList.remove('menu-expanded');
                body.classList.add("menu-collapsed");
            },1000)
            $("#studentsData").DataTable();
            $(".view").click(function (e) {
                e.preventDefault();
                var id = $(this).attr('data-id');
                var data = {
                    id:id,
                };
                $.ajax({
                    url:"<?php echo e(route('student.show')); ?>",
                    data:data,
                    dataType:'JSON',
                    type:'POST',
                    complete:function (jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var student = result.student;

                                var src = '<?php echo e(asset("/")); ?>'+student.student_image;
                                var idCardSrc = "<?php echo e(asset('/')); ?>"+student.id_card_front;
                                var idCardSrc2 = "<?php echo e(asset('/')); ?>"+student.id_card_back;
                                $(".studentImage").attr('src',src);
                                $(".linkStudentImage").attr('href',src);

                                $(".idCard1").attr('src',idCardSrc);
                                $(".idCard2").attr('src',idCardSrc2);
                                console.log(result);
                                $(".email").html(student.email);
                                $(".dateOfBirth").html(student.date_of_birth);
                                $(".education").html(result.education);
                                $(".find").html(student.find);
                                $(".address").html(student.address);
                                $(".examDate").html(result.exam_date);
                                $(".paidAmount").html(student.paid_amount);
                                $(".dueAmount").html(student.due_amount)
                                $(".emergencyContactNo").html(student.emergency);
                                $(".hostelFee").html(student.hostel_fee);
                            }
                        }
                    }
                });
                $("#myModal").modal();
            });
            //edit student result
            $("#edit").click(function(e) {
                var id = $("#examResultId").val();
                var route = "<?php echo e(route('studentResult.edit',':id')); ?>";
                route = route.replace(":id",id);
                window.location.replace(route); 
            });
            //check list of student exam dates
            $(".exam_date").click(function(e) {
                e.preventDefault();
                var id = $(this).data("id");
                var route = "<?php echo e(route('ExamDate.courseExamDate',':id')); ?>";
                route = route.replace(":id",id);
                $.ajax({
                    url:route,
                    dataType:'JSON',
                    type:'GET',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var output = "";
                                var i = 0;
                                result.exam_dates.forEach(function(exam_date) {
                                    i++;
                                    output += "<tr><td>"+i+"</td><td>"+exam_date.exam_date+"</td>";
                                    if(exam_date.willing == 1) {
                                        output += "<td>Yes</td>"
                                    } else {
                                        output += "<td>No</td>"
                                    }
                                    if(exam_date.result_status == "0" ) {
                                        output +="<td><i class='badge badge-primary'>Pending</i> / "  
                                                    +"<a href='#' class='badge badge-info announce' data-id='"+exam_date.course_exam_id+"'>Anncounce</a>"
                                                    +"</td>";
                                    } else {
                                        output += "<td><a href='#' class='view-result' data-id='"+exam_date.result_id+"'><i class='badge badge-primary'>Announced &nbsp;&nbsp;<i class='ft-eye'></i> </i> </a></td>";
                                    }
                                    if(exam_date.admission == "0") {
                                        if(exam_date.willing == 0) {
                                            output += "<td><button class='btn btn-sm btn-danger' disabled>Pending</button></td>"; 
                                        } else {
                                            output += "<td class='text-white'> <a href='#' class='btn btn-sm btn-danger admission' data-id='"+exam_date.course_exam_id+"'>Pending</a></td>"; 
                                        }
                                        
                                    } else {
                                        output += "<td> <span class='badge badge-primary'>Applied</span></td>";  
                                    } 
                                    output += "</tr>";
                                    $(".tbody > tr").remove();
                                    $(".tbody").append(output);
                                    $("#examModal").modal();
                                })
                            }
                        }
                    }
                });
            });
            //announced result
            $(document).on("click",".announce",function(e) {
                var id =  $(this).data("id");
                var route = "<?php echo e(route('studentResult.create',':id')); ?>";
                route = route.replace(":id",id);
                window.location.replace(route);
            });
            //view result 
            $(document).on("click",".view-result",function(e) {
                var id = $(this).data("id");
                var route = "<?php echo e(route('studentResult.show',':id')); ?>";
                route = route.replace(":id",id);
                $.ajax({
                    url:route,
                    dataType:'JSON',
                    type:'GET',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var data = result.course_result;
                                if(data.result == "1") {
                                    $(".status").html("Pass");
                                    var status = document.getElementsByClassName("status")[0];
                                    status.parentNode.parentNode.classList += " text-success";
                                } else {
                                    $(".status").html("Fail");   
                                    var status = document.getElementsByClassName("status")[0];
                                    status.parentNode.parentNode.classList += " text-danger";
                                }
                                $(".total_marks").html(data.total_marks);
                                $(".obtain_marks").html(data.obtain_marks);
                                if(data.certificate == "") {
                                    $(".certificate").html("N/A");
                                } else {
                                    $(".certificate").html("<i class='ft-eye'></i>");
                                }
                                if(data.result_attachment == "") {
                                    $(".result_attachment").html("N/A");
                                } else {
                                    $(".result_attachment").html("<i class='ft-eye'></i>");
                                }
                                $("#examResultId").val(data.result_id);
                                $("#resultModal").modal();
                            }
                        }
                    }
                });
            });
            //getting batch feedback
            $(".batch_feedback").click(function(e) {
                var id = $(this).data("id");
                var route = "<?php echo e(route('batchFeedback.show',':id')); ?>";
                route = route.replace(":id",id);
                $.ajax({
                    url:route,
                    dataType:'JSON',
                    type:'GET',
                    complete:function(jqXHR,textStatus)  {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var feedback = result.feedback;                     
                                for(let key in feedback) {
                                    if(feedback[key] == "" || feedback[key] == null) {
                                        $("."+key).html("N/A");
                                    } else {
                                        $("."+key).html(feedback[key]);
                                    }
                                }
                                //making rating
                                var course_rating = makeRating(feedback.course_rating);
                                var child = document.getElementsByClassName('course_rating_star')[0].children;
                                printRating(course_rating,child);

                                var present_rating = makeRating(feedback.course_present);
                                var child = document.getElementsByClassName('course_present_star')[0].children;
                                printRating(present_rating,child);


                                var course_intrest_star = makeRating(feedback.course_intrest);
                                var child = document.getElementsByClassName('course_intrest_star')[0].children;
                                printRating(course_intrest_star,child);
                                
                                var course_question_star = makeRating(feedback.question);
                                var child = document.getElementsByClassName('course_question_star')[0].children;
                                printRating(course_question_star,child);

                                var facilities_rating = makeRating(feedback.facilities);
                                var child = document.getElementsByClassName('course_rating_facilities')[0].children;
                                printRating(facilities_rating,child);
                            }
                        }
                    }
                });
                $("#feedbackModal").modal();
            });
            //student batch attendance
            $(".attendence").click(function(e) {
                var batch_id = $(this).data("batch-id");
                var student_id = $(this).data("student-id");
                var data = {
                    'batch_id':batch_id,
                    'student_id':student_id,
                };
                $.ajax({
                    url:"<?php echo e(route('attendance.showStudentAttendance')); ?>",
                    data:data,
                    dataType:'JSON',
                    type:'POST',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var attendances = result.days;
                                var table = "<table border='2px'>";
                                table += "<tr>";
                                attendances.forEach(function(attendance) {
                                    table+= "<td>"+attendance.day_date+"</td>"
                                });
                                table += "</tr>";
                                table += "<tr>";
                                attendances.forEach(function(attendance) {
                                    table+= "<td>"+attendance.status+"</td>"
                                });
                                table += "</tr>";
                                table += "</table>";
                                var postfix = "Attendence-sheet";
                                var a = document.createElement('a');
                                var dataType = "data:application/vnd.ms-excel";
                                a.href = dataType + ',' + encodeURIComponent(table);
                                a.download = postfix + '.xls';
                                a.click();
                            }
                        }
                    }
                });
            });
            //getting batch student quiz report
            $("#quiz").click(function(e) {
                var batchId = $(this).data("batch-id");
                var studentId = $(this).data('student-id');
                var data = {
                    'student_id':studentId,
                    'batch_id':batchId
                };
                $.ajax({
                    url:"<?php echo e(route('quizResult.adminIndex')); ?>"  ,
                    data:data,
                    dataType:'JSON',
                    type:'POST',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            var output = "";
                            var i = 0;
                            if(result.hasOwnProperty('success')) {
                                var results = result.results;
                                results.forEach((res)=>{
                                    console.log(res);
                                    i++;
                                    if(res != null) {
                                        output += "<tr><td>"+i+"</td><td>Quiz # "+i+"</td><td>"+res.obtain_marks+"</td><td>"+res.remarks+"</td></tr>";
                                    } else {
                                        output += "<tr><td>"+i+"</td><td>Quiz # "+i+"</td><td>N/A</td><td>N/A</td></tr>";
                                    }
                                });
                                $(".quiz_tbody > td").remove();
                                $(".quiz_tbody").append(output);
                                $("#quizModal").modal();
                            }
                        }
                    }
                });
                
            });
            $(document).on("click",".admission",function(e) {
                var id = $(this).data("id");
                var route = "<?php echo e(route('ExamDate.sendAdmission',':id')); ?>";
                route = route.replace(":id",id);
                $.ajax({
                    url:route,
                    type:'GET',
                    dataType:'JSON',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                toastr.success(result.msg);
                                $("#examModal").modal('hide');
                            }
                        }
                    }
                }); 
            });
        });
        function makeRating(feedback) {
            if(feedback == "Excellent") 
                return 5;
            else if(feedback == "Good")
                return 4;
            else if(feedback == "Poor")
                return 3;
            else if(feedback == "Ver Poor")
                return 2;
            else 
                return 1;

        }
        function printRating(rating,nodes) {
            if(rating > 2) {
                //console.log(child);
                for(var i=0;i< rating;i++) {
                    nodes[i].style="color:green";
                }
            } else {
                for(var i=0;i< rating;i++) {
                    nodes[i].style="color:red";
                }
            }
        }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>