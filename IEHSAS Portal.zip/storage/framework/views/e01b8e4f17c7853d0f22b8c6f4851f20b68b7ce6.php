<?php $__env->startSection('styles'); ?>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('student-portal/app/vendors/css/forms/selects/selectize.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('student-portal/app/vendors/css/forms/selects/selectize.default.css')); ?>">

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('student-portal/app/css/plugins/forms/selectize/selectize.min.css')); ?>">
<link href="<?php echo e(asset('css/jasny-bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-content collpase show">
                <div class="card-body">
                    <form class="form form-horizontal" method="POST" action="<?php echo e(route('teacher.updateProfile')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" value="<?php echo e($teacher->id); ?>">
                        <div class="form-body">
                            <h4 class="form-section"><i class="ft-edit"></i> Edit Profile</h4>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="last_name">Qualification :</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <input type="text" class="input-selectize" value="<?php echo e($teacher->profile->qualification); ?>" name="qualification" placeholder="Enter Your Qualification">
                                    </div>
                                    <span class="text-danger"></span>
                                    
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="last_name">Experience:</label>
                                <div class="col-md-8">
                                    <input type="text" id="last_name" class="form-control" value="<?php echo e($teacher->profile->experience); ?>" name="experience" placeholder="Enter Working Experience" name="last_name">
                                    <span class="text-danger"></span>
                                    
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="last_name">Skills:</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <input type="text" class="input-selectize" value="<?php echo e($teacher->profile->skills); ?>" name="skills" placeholder="Enter Your Skills Set">
                                    </div>
                                    <span class="text-danger"></span>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="last_name">Professional Courses:</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <input type="text" class="input-selectize" value="<?php echo e($teacher->profile->professional_courses); ?>" name="professional_courses" placeholder="Enter Your Professional Courses">
                                    </div>
                                    
                                    <span class="text-danger"></span>
                                    
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="last_name">Profile Image:</label>
                                <div class="col-md-8">
                                    <div class="form-group row">
                                        <div>
                                            <!-- Student Image-->
                                            <div class="form-group">
                                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                                    <div class="fileinput-preview img-thumbnail" data-trigger="fileinput" style="width: 300px; height: 200px;">
                                                        <!-- Demo Image -->
                                                        <img src="<?php echo e(asset($teacher->profile_image)); ?>">
                                                    </div>
                                                    <div>
                                                <span class="btn btn-outline-secondary btn-file">
                                                  <span class="fileinput-new">Select image</span>
                                                  <span class="fileinput-exists">Change</span>
                                                  <input type="file" name="profile_image">
                                                </span>
                                                        <a href="#" class="btn btn-outline-secondary fileinput-exists" data-dismiss="fileinput">Remove</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <?php if($errors->has('profile_image')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('profile_image')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-actions">
                            <center>
                                <button type="submit" class="btn btn-primary">Update</button>
                            </center>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('student-portal/app/vendors/js/forms/select/selectize.min.js')); ?>"></script>
<script src="<?php echo e(asset('app/js/core/libraries/jquery_ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('student-portal/app/js/scripts/forms/select/form-selectize.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jasny-bootstrap.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>