

<?php $__env->startSection('header-styles'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
    <div id="app">
        <student-component></student-component>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
<script> window.Laravel = { csrfToken : '<?php echo e(csrf_token()); ?> ',asset:'<?php echo e(asset('/')); ?>',path:'<?php echo e(url('')); ?>'}</script>
<script>
    var ajaxLoading = "<img src='<?php echo e(asset('images/loader.gif')); ?>' style='width:70px;'>";
</script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>