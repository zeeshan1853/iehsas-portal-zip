<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="dom">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="float-right">
                        <a href="<?php echo e(route('quiz.create',['id'=>Route::input('id')])); ?>" class="btn btn-primary round btn-min-width mr-1 mb-1" id="addAssessment">
                            <i class="fa fa-plus-circle"></i>&nbsp;
                            Add New Quiz
                        </a>
                    </div>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Sr.No</th>
                                <th>Total Marks</th>
                                <th>Document</th>
                                <th>Deadline</th>
                                <th>Time <small> (H:m:s)</small></th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($quiz->total_marks); ?></td>
                                    <td>
                                        <a href="<?php echo e(asset($quiz->document)); ?>" target="_blank">Document File</a>
                                    </td>
                                    <td><?php echo e($quiz->deadline->toFormattedDateString()); ?></td>
                                    <td><?php echo e($quiz->time); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('quiz.delete',['id'=>$quiz->id])); ?>" style="color:red;">
                                            <span class="ft-trash"></span>
                                        </a>
                                        <a href="<?php echo e(route('studentQuiz.index',['id'=>$quiz->id])); ?>" style="margin-left:5px;" title="View Student Quizes">
                                            <span class="ft-eye"></span>
                                        </a>
                                        <?php
                                            $now = date("Y-m-d");
                                            if($now > $quiz->deadline->format("Y-m-d")) {
                                                ?>
                                                <?php if($quiz->quizResults->count() > 0): ?>
                                                    <a href="<?php echo e(route('quizResult.show',['id'=>$quiz->id])); ?>" style="margin-left:5px; color:orange;" title="Show Student Quiz Report">
                                                        <span class="ft-book"></span>
                                                    </a>
                                                <?php else: ?>
                                                    <a href="<?php echo e(route('quizResult.create',['id'=>$quiz->id])); ?>" style="margin-left:5px;" title="Upload Student Quiz Marks">
                                                        <span class="ft-activity"></span>
                                                    </a>
                                                <?php endif; ?>
                                                    
                                                <?php
                                            }
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>