<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(asset('vendors/css/tables/datatable/datatables.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="branchesData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Name</td>
                        <td data-column-id="account_no">Account No</td>
                        <td data-column-id="bank_branch">Bank Branch</td>
                        <td data-column-id="debit">Debit</td>
                        <td data-column-id="credit">Credit</td>
                        <td data-column-id="balance">Balance</td>
                        <td data-column-id="balance">Opening</td>
                        <td data-column-id="status">Status</td>
                        <td data-column-id="edit" data-sortable="false">Actions</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($bank->name); ?></td>
                            <td><?php echo e($bank->account_no); ?></td>
                            <td><?php echo e($bank->bank_branch); ?></td>
                            <td><?php echo e($bank->debit); ?></td>
                            <td><?php echo e($bank->credit); ?></td>
                            <td><?php echo e($bank->debit - $bank->credit); ?></td>
                            <td><?php echo e($bank->opening); ?></td>
                            <?php if($bank->status == 1): ?>
                                <td>
                                    <span href="" class="badge badge-info">Active For Bank Transactions</span>
                                </td>
                            <?php else: ?> 
                                <td>
                                    <a href="<?php echo e(route('bank.activate',['id'=>$bank->id])); ?>" class="btn btn-sm btn-primary">Activate Bank</a>
                                </td>
                            <?php endif; ?>
                            <td>
                                <a href="<?php echo e(route('bank.edit',['id'=>$bank->id])); ?>" title="Edit Bank Detail"><i class="ft-edit"></i></a>
                                <a href="<?php echo e(route('bank.delete',['id'=>$bank->id])); ?>" title="Delete Account"><i class="ft-trash" style="color:red;"></i></a>
                                <a href="<?php echo e(route('bankBook.show',['id'=>$bank->id])); ?>" title="Bank Book"><i class="ft-eye" style="color:green;"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/tables/datatables/datatable-styling.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/tables/datatables/datatable-basic.min.js')); ?>"></script>
    <script>
        $(document).ready(function(e) {
            $("#branchesData").DataTable({
                language: {
                    searchPlaceholder: "Search Bank",
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>