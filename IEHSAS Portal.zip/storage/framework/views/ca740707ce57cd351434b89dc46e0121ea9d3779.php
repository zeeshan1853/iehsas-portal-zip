<?php $__env->startSection('header-styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('mail.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="branch_id" value="<?php echo e(Auth::user()->branch->id); ?>">
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">From</label>
                                    <div class="col-md-9">
                                        <input type="text" id="=from" autofocus value="<?php echo e(old('from')); ?>" class="form-control <?php echo e($errors->has('from') ? 'border-danger' : ''); ?>" placeholder="Mail From" name="from">
                                        <?php if($errors->has('from')): ?>
                                            <span class=" text-danger"><?php echo e($errors->first('from')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">To</label>
                                    <div class="col-md-9">
                                        <input type="text" id="to" value="<?php echo e(old('to')); ?>" class="form-control <?php echo e($errors->has('to') ? 'border-danger' : ''); ?>" placeholder="Mail To" name="to">
                                        <?php if($errors->has('to')): ?>
                                            <span class=" text-danger"><?php echo e($errors->first('to')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Address</label>
                                    <div class="col-md-9">
                                        <textarea class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" placeholder="Enter Mail Address" name="address" rows="8"><?php echo e(old('address')); ?></textarea>
                                        <?php if($errors->has('address')): ?>
                                            <span class="text-danger "><?php echo e($errors->first('address')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput4">Content</label>
                                        <div class="col-md-9">
                                                <textarea class="form-control <?php echo e($errors->has('content') ? 'is-invalid' : ''); ?>" name="content" placeholder="Enter Mail Content" rows="8"><?php echo e(old('content')); ?></textarea>
                                            <?php if($errors->has('content')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('content')); ?></span>
                                            <?php endif; ?>
                                        </div>
    
                                    </div>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Courier Name</label>
                                    <div class="col-md-9">
                                        <input type="text" id="courierName" placeholder="Enter Courier Name" value="<?php echo e(old('courier_name')); ?>" class="form-control <?php echo e($errors->has('courier_name') ? 'border-danger' : ''); ?>"  name="courier_name">
                                        <?php if($errors->has('courier_name')): ?>
                                            <span class="text-danger courier_name">
                                                <?php echo e($errors->first('courier_name')); ?>

                                            </span>
                                        <?php endif; ?>  
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Receiving Date</label>
                                    <div class="col-md-9">
                                        <input type="date" id="receivingDate" class="form-control date <?php echo e($errors->has('receiving_date') ? 'border-danger' : ''); ?>"  name="receiving_date">
                                    </div>
                                    <?php if($errors->has('receiving_date')): ?>
                                        <span class="text-danger offset-md-4"><?php echo e($errors->first('receiving_date')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Stacking / placement</label>
                                    <div class="col-md-9">
                                        <input type="text" value="<?php echo e(old('stacking_placement')); ?>" name="stacking_placement" id="stackingPlacement" placeholder="Enter Mail is Stack / Placed" class="form-control <?php echo e($errors->has('stacking_placement') ? 'is-invalid' : ''); ?>">
                                        <?php if($errors->has('stacking_placement')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('stacking_placement')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Reciver Name:</label>
                                    <div class="col-md-9">
                                        <input type="text" value="<?php echo e(old('receiver_name')); ?>" class="form-control <?php echo e($errors->has('receiver_name') ? 'is-invalid' : ''); ?>" name="receiver_name" id="receiverName" placeholder="Enter Reciver Name">
                                        <?php if($errors->has('receiver_name')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('receiver_name')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>

                        </div>

                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Add Mail" id="btnAdd" class="btn btn-primary">
                        
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script>
        var dueAmount = 0;
        $(document).ready(function (e) {
            var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month + 1;
            if(month < 10) {
                month =  "0" +month;
            }
            if(fullDate < 10)
                fullDate = '0' + fullDate;


            $(".date").val(date.getFullYear() + "-" + month + "-" + fullDate);
        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>