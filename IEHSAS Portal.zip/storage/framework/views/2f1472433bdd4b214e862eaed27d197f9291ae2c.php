<html>
    <head>
        <title>Registration Form</title>
        <link href="<?php echo e(asset('css/print.css')); ?>" rel="stylesheet" type="text/css" media="all">
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all">
    </head>
    <body>
        <main>
            <div id="main">
                <div id="content">
                    <div id="header">
                        <div id="logo">
                            <img src="<?php echo e(asset(Auth::user()->branch->setting->logo)); ?>" alt="logo">
                            <p><b>Office:</b> <?php echo e($setting->address); ?> <b>Country:</b>  <?php echo e($setting->country); ?>. Cell # <?php echo e($setting->mobile_no); ?> Phone # <?php echo e($setting->phone_no); ?> 
                            <b>Website:</b> www.iehsas.com  <b>Email:</b><?php echo e($setting->email); ?>

                            </p>
                        </div>
                        <div id="student_image">
                        <img src="<?php echo e(asset($student->student_image)); ?>">
                        </div>
                        <br clear="all">
                        <center><h1 style="margin-top:0px;">REGISTRATION FORM</h1></center>
                        <p class="date">Date.<u><?php echo e(date("Y-m-d",strtotime($student->created_at))); ?></u></p>
                        <p class="registeration">Registration No.<u><?php echo e($student->id); ?></u></p>
                        <br clear="all">
                        <hr class="border">
                    </div>
                    <div id="courses">
                        <section>
                            <p>Training title in which student Enroll. </p>
                            <table border="1px">
                                <tr>
                                    <th>Sr.</th>
                                    <th>Course Name</th>
                                    <th>Batch Name</th>
                                    <th>Nebosh ID</th>
                                    <th>Fresh / Resit</th>
                                    <th>Enrolment Date</th>
                                    <th>Training Date</th>
                                    <th>Course Price</th>
                                    <th>Exam Dates</th>
                                </tr>
                                <?php
                                    $i=1;
                                ?>
                                <?php $__currentLoopData = $student->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($course->course->course_name); ?> </td>
                                <td><?php echo e($course->batch->batch_name); ?></td>
                                <td><?php echo e($course->nebosh_student_id == "" ? "N/A" : $course->nebosh_student_id); ?></td>
                                <td>
                                    <?php if($course->fresh_resit == ""): ?>
                                        N/A
                                    <?php elseif($course->fresh_resit == "0"): ?>
                                        Fresh
                                    <?php else: ?>
                                        Resit
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($course->admission_date->toFormattedDateString()); ?></td>
                                <td><?php echo e($course->batch->start_date->toFormattedDateString()); ?><br><?php echo e($course->batch->end_date->toFormattedDateString()); ?></td>
                                <td><?php echo e($course->fresh_resit == 0 ? $course->batch->course_price : $course->resit_fee); ?></td>
                                <td style="width:14%;">
                                    <?php $__currentLoopData = $course->examDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                            <?php echo e($date->exam_date->toFormattedDateString()); ?>

                                            <?php if($date->willing == 1): ?>
                                            <span class="fa fa-check"></span><br>
                                            <?php else: ?>
                                            <span class="fa fa-times"></span><br>
                                            <?php endif; ?>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </section>
                    </div>
                    <div id="student_info">
                        <center><h3>STUDENT INFORMATION</h3></center>
                        <table >
                            <tr>
                                <td>Candidate Name</td>
                                <td><?php echo e($student->student_name); ?></td>
                                <td>Date Of Birth</td>
                                <td><?php echo e($student->date_of_birth); ?></td>
                            </tr>
                            <tr>
                                <td>National ID Card</td>
                                <?php if(empty($student->id_card)): ?>
                                    <td>N/A</td>
                                <?php else: ?> 
                                    <td><?php echo e($student->id_card); ?></td>
                                <?php endif; ?>
                                
                                <td>Email Address</td>
                                <td><?php echo e($student->email); ?></td>
                            </tr>
                            <tr>
                                <td>Father Name</td>
                                <td><?php echo e($student->father_name); ?></td>
                                <td>Gender</td>
                                <td>
                                    <label for="male">Male<input type="checkbox" <?php if($student->gender == "male"): ?> checked <?php endif; ?>></label>
                                    <label for="female">Female<input type="checkbox" <?php if($student->gender == "female"): ?> checked <?php endif; ?>></label>
                                </td>
                            </tr>
                            <tr>
                                <td>Mobile No</td>
                                <td><?php echo e($student->contact_no); ?></td>
                                <td>Emergency No.</td>
                                <td><?php echo e($student->emergency); ?></td>
                            </tr>
                            <tr>
                                <td>Qualifications</td>
                                <td colspan="3"><center><?php echo e($student->education->name); ?></center></td>
                            </tr>
                            <tr>
                                <td>Home Address</td>
                                <td colspan="3"><center><?php echo e($student->address); ?></center></td>
                            </tr>
                            <tr>
                                <td>How You Find Us ?</td>
                                <td colspan="3"><center><?php echo e($student->find); ?></center></td>
                            </tr>
                            <tr>
                                <td colspan="2"><b><center>Documents Attached</center></b></td>
                                <td colspan="2"><b><center>Method Of Payment</center></b></td>
                            </tr>
                            <tr class="documents">
                                <td>Copy Of Cnic / Form B</td>
                                <td><input type="checkbox"></td>
                                <td>Cash</td>
                                <td><input type="checkbox"></td>
                            </tr>
                            <tr class="documents">
                                <td colspan="1">Education Certification</td>
                                <td><input type="checkbox"></td>
                                <td colspan="1">Cheque</input>
                                <td><input type="checkbox"></td>
                            </tr>
                            <tr class="documents">
                                <td colspan="1">One Photograph</td>
                                <td><input type="checkbox"></td>
                                <td colspan="1">Bank Transfer</td>
                                <td><input type="checkbox"></td>
                            </tr>
                            <tr class="documents">
                                <td colspan="2">Comments:</td>
                                <td colspan="1">Credit</td>
                                <td><input type="checkbox"></td>
                            </tr>
                        </table>
                    </div>
                    <div id="insitute">
                        <br>
                        <center><h3 class="title">For Training Insitute Use Only</h3></center>
                        <div id="info">
                            <table>
                                <tr>
                                    <td colspan="2"><b>Form</b></td>
                                    <td></td>
                                    <td>Approved <input type="checkbox"></td>
                                    <td>Rejected <input type="checkbox"></td>
                                </tr>
                                <tr>
                                    <td colspan="2"><b>ID Card</b></td>
                                    <td></td>
                                    <td><img src="<?php echo e(asset('images/cards/front.jpg')); ?>" width="300px"></td>
                                    <td><img src="<?php echo e(asset('images/cards/back.jpg')); ?>" width="300px"></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div id="footer">
                        <table>
                            <tr>
                                <td><span style="border-top:1px solid black;">Executive Signature</span> </td>
                                <td><span style="border-top:1px solid black;">Candidiate Signature</span> </td>
                                <td><span style="border-top:1px solid black;">Admin Signature</span></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </main>
        
    </body>
</html>
<script>
    window.print();

</script>