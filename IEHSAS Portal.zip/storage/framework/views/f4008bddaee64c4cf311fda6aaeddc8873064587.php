<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="author" content="techcodex">
    <title>Login| <?php echo e(config('app.name')); ?></title>
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('student-portal/app/css/vendors.min.css')); ?>">
    <!-- END VENDOR CSS-->
    <!-- BEGIN ROBUST CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('student-portal/app/css/app.min.cs')); ?>s">
    <!-- END ROBUST CSS-->
    
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <!-- END Custom CSS-->
</head>

<body class="vertical-layout vertical-menu 1-column  bg-full-screen-image menu-expanded blank-page blank-page" data-open="click" data-menu="vertical-menu" data-col="1-column">
    <div class="app-content content">
        <div class="content-wrapper">
            <div class="content-body">
                <section class="flexbox-container">
                    <div class="col-12 d-flex align-items-center justify-content-center">
                        <div class="col-md-4 col-10 box-shadow-2 p-0">
                            <div class="card border-grey border-lighten-3 px-1 py-1 m-0">
                                <div class="card-header border-0">
                                    <div class="card-title text-center">
                                        <img src="<?php echo e(asset('images/logo/tcx.png')); ?>" alt="Company Logo" height="80px" width="220px">
                                    </div>
                                </div>
                                <div class="card-content">
                                    <div class="card-body">
                                        <form method="POST" action="<?php echo e(route('teacher.verifyLogin')); ?>" class="form-horizontal">
                                            <?php echo csrf_field(); ?>
                                            <?php if(Session::has('login')): ?>
                                            <span class="text-danger" role="alert">
                                                <strong><?php echo e(Session::get('login')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                            
                                            <fieldset class="form-group position-relative has-icon-left mt-1">
                                                <input id="email" type="email" autofocus class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email">
                                                <div class="form-control-position">
                                                    <i class="ft-user"></i>
                                                </div>
                                                <!-- Validation --->
                                                <?php if($errors->has('email')): ?>
                                                <span class="text-danger" role="alert">
                                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </fieldset>

                                            <fieldset class="form-group position-relative has-icon-left">
                                                <input id="password" type="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" name="password" placeholder="password">
                                                <div class="form-control-position">
                                                    <i class="fa fa-key"></i>
                                                </div>
                                                <!-- Validation --->
                                                <?php if($errors->has('password')): ?>
                                                <span class="text-danger" role="alert">
                                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                                </span>
                                                <?php endif; ?>
                                            </fieldset>
                                            <div class="form-group row">
                                                <div class="col-md-6 col-12 text-center text-sm-left">
                                                    <fieldset>
                                                        <input type="checkbox" id="remember" class="chk-remember form-check-input" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                                        <label for="remember-me"> Remember Me</label>
                                                    </fieldset>
                                                </div>
                                                <div class="col-md-6 col-12 float-sm-left text-center text-sm-right">
                                                    <a href="#" class="card-link">Forgot Password?</a>
                                                </div>
                                            </div>
                                            <button type="submit" class="btn btn-outline-info btn-block"><i class="ft-unlock"></i> Login</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

            </div>
        </div>
    </div>
</body>

</html>