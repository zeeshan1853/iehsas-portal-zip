<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(url('public/vendors/css/tables/datatable/datatables.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="studentsData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Name</td>
                        <td data-column-id="paid">Paid Amount</td>
                        <td data-column-id="delete" data-sortable="false">Delete</td>
                        <td data-column-id="edit" data-sortable="false">Edit</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    <?php $__currentLoopData = $instalments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instalment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($instalment->student->student_name); ?></td>
                            <td><?php echo e($instalment->paid_amount); ?></td>
                            <td><a href="" class="btn btn-danger">Delete</a> </td>
                            <td><a href="" class="btn btn-primary">Edit</a> </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(url('public/vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/js/scripts/tables/datatables/datatable-styling.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/js/scripts/tables/datatables/datatable-basic.min.js')); ?>"></script>
    <script>
        $(document).ready(function(e) {
            $("#studentsData").DataTable();
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>