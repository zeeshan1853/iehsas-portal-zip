<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <title>Batch Assessment Report</title>
    <style>
        table{
            border-collapse: collapse;
            width:100%;
        }
        img{
            margin-left:40%;
        }
        h3{
            text-align: center;
        }
    </style>
</head>
<body>
    <img src="<?php echo e(asset(Auth::user()->branch->setting->logo)); ?>" width="100">
    <h3><?php echo e(config('app.name')); ?> Student Batch Assessment Report</h3>
    <table border="1px">
        <thead class="thead">

        </thead>
        <tbody class="tbody">

        </tbody>
    </table>
</body>
<script>
    $(document).ready(function(e) {
        var reports = JSON.parse(localStorage.reports);
        var thead = "";
        var thead,tbody = "";
        var i = 0;
        var obtain_marks = 0;
        var percentage = 0;
        var total_marks = 0;
        var j = 0;
        thead += "<tr><th>Sr. No</th><th>Sudent Name</th>";
        reports.forEach((report)=>{
            var total = 0;
            i++;
            tbody += "<tr>";
            report.forEach(function(rep){
                if(j == 0) {
                    tbody += "<td>"+i+"</td><td>"+rep.student_name+"</td><td>"+rep.obtain_marks+"</td>";
                    rep.obtain_marks != "N/A" ? obtain_marks += rep.obtain_marks : obtain_marks += 0;
                    total_marks += rep.total_marks;
                    j++;
                } else {
                    tbody += "<td>"+rep.obtain_marks+"</td>";
                    rep.obtain_marks != "N/A" ? obtain_marks += rep.obtain_marks : obtain_marks += 0;
                    total_marks += rep.total_marks;
                }
            });
            percentage = ((obtain_marks / total_marks) * 100).toFixed(3);
            tbody += "<td>"+obtain_marks+"</td>";
            tbody += "<td>"+percentage+"</td>";
            tbody += "</tr>";
            obtain_marks = 0;
            j = 0;
            thead += "<th>Test # "+i+"</th>";

        });
        thead += "<th>Total Marks</th>";
        thead += "<th>Total (%)</th>";
        thead += "</tr>";
        $(".thead > tr").remove();
        $(".tbody > tr").remove();
        $(".thead").append(thead);
        $(".tbody").append(tbody);
        window.print();
    });
</script>
</html>