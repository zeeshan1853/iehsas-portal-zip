<?php $__env->startSection('header-styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="row">
    <div class="card col-md-12">
        <div class="card-body">
            <form class="form form-horizontal" method="post" action="<?php echo e(route('role.store')); ?>"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-body">
                    <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                    <div class="row">
                        <div class="col-md-6 offset-md-2">
                            <div class="form-group row">
                                <label class="col-md-3 label-control" for="userinput1">Role Name:</label>
                                <div class="col-md-9">
                                    <input type="text" id="name" autofocus
                                        class="form-control <?php echo e($errors->has('name') ? 'border-danger' : ''); ?>"
                                        placeholder="Role Name" name="name">
                                </div>
                                <?php if($errors->has('name')): ?>
                                <span class="offset-md-4 text-danger"><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-actions text-center">
                    <input type="submit" value="Store" id="btnAdd" class="btn btn-primary">
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>