<div class="main-menu menu-fixed menu-light menu-accordion    menu-shadow " data-scroll-to-active="true" data-img="<?php echo e(url('public/images/backgrounds/02.jpg')); ?>">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item mr-auto"><a class="navbar-brand" href="index-2.html"><img class="brand-logo" alt="TCX Logo" src="<?php echo e(url('public/images/logo/tcx.png')); ?>"/>
            <li class="nav-item d-md-none"><a class="nav-link close-navbar"><i class="ft-x"></i></a></li>
        </ul>
    </div>
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <li class="nav-item"><a href="<?php echo e(url('home')); ?>"><i class="ft-home"></i><span class="menu-title" data-i18n="">Dashboard</span></a></li>
            <li class="nav-item"><a href="#"><i class="ft-users"></i><span class="menu-title" data-i18n="">Users</span></a>
                <ul class="menu-content">
                    <li><a class="menu-item" href="<?php echo e(url('users/add_user')); ?>">Add User</a>
                    </li>
                    <li><a class="menu-item" href="<?php echo e(route('user.user_list')); ?>">Show All Users</a>
                    </li>

                </ul>
            </li>
            <li class="nav-item"><a href="#"><i class="ft-user-check"></i><span class="menu-title" data-i18n="">Teachers</span></a>
                <ul class="menu-content">
                    <li><a class="menu-item" href="<?php echo e(url('teachers/add_teacher')); ?>">Add Teacher</a>
                    </li>
                    <li><a class="menu-item" href="<?php echo e(url('teachers/teachers_list')); ?>">Show All Teachers</a>
                    </li>

                </ul>
            </li>
            <li class="nav-item"><a href="#"><i class="ft-book"></i><span class="menu-title" data-i18n="">Courses</span></a>
                <ul class="menu-content">
                    <li><a class="menu-item" href="<?php echo e(route('course.add_course')); ?>">Add Course</a>
                    </li>
                    <li><a class="menu-item" href="<?php echo e(route('course.courses_list')); ?>">Show All Courses</a>
                    </li>

                </ul>
            </li>
            <li class="nav-item"><a href="#"><i class="ft-clipboard"></i><span class="menu-title" data-i18n="">Batches</span></a>
                <ul class="menu-content">
                    <li><a class="menu-item" href="<?php echo e(route('batch.add_batch')); ?>">Add New Batch</a>
                    </li>
                    <li><a class="menu-item" href="<?php echo e(route('batch.batches_list')); ?>">Show All Batches</a>
                    </li>

                </ul>
            </li>
            <li class="nav-item"><a href="#"><i class="ft-cast"></i><span class="menu-title" data-i18n="">Students</span></a>
                <ul class="menu-content">
                    <li><a class="menu-item" href="<?php echo e(route('student.add_student')); ?>">Add New Student</a>
                    </li>
                    <li><a class="menu-item" href="<?php echo e(route('batch.batches_list')); ?>">Show All Batches</a>
                    </li>
                </ul>
            </li>
            <li class="nav-item"><a href="#"><i class="ft-activity"></i><span class="menu-title" data-i18n="">Instalments</span></a>
                <ul class="menu-content">
                    <li><a class="menu-item" href="<?php echo e(route('instalment.add')); ?>">Add New Instalment</a></li>
                </ul>
            </li>
            <li class="nav-item"><a href="#"><i class="ft-star"></i><span class="menu-title" data-i18n="">Education</span></a>
                <ul class="menu-content">
                    <li><a class="menu-item" href="<?php echo e(route('education.create')); ?>">Add New Degree</a></li>
                    <li><a class="menu-item" href="<?php echo e(route('education.index')); ?>">Show All Degress</a></li>
                </ul>
            </li>
            <li class="nav-item"><a href="<?php echo e(route('setting.index')); ?>"><i class="ft-globe"></i><span class="menu-title" data-i18n="">Settings</span></a></li>
        </ul>
    </div>
    <div class="navigation-background"></div>
</div>