<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Student Instalment</title>
    <style>
    table{
        width:100%;
        border-collapse: collapse;
        text-align: center;
    }
</style>
</head>
<body>
    <?php echo $content; ?>


    <center><h3>Instalment Information </h3></center>
    <table border="1px">
        <tr>
            <td>Course Name</td>
            <td>Batch Name</td>
            <td>Payment Type</td>
            <td>Paid Amount</td>
            <td>Payment Date</td>
        </tr>
        <tr>
            <td><?php echo e($instalment->course->course_name); ?></td>
            <td><?php echo e($instalment->batch->batch_name); ?></td>
            <td><?php echo e($instalment->payment->name); ?></td>
            <td><?php echo e($instalment->paid_amount); ?></td>
            <td><?php echo e($instalment->created_at->toFormattedDateString()); ?></td>
        </tr>
    </table>
</body>
</html>