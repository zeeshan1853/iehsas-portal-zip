<?php $__env->startSection('header-styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('studentResult.update',['id'=>$result->id])); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Total Marks</label>
                                    <div class="col-md-9">
                                        <input type="text" autofocus id="totalMarks" <?php if(old('total_marks') == ''): ?> value="<?php echo e($result->total_marks); ?>" <?php else: ?> value="<?php echo e(old('total_marks')); ?>" <?php endif; ?> class="form-control  <?php echo e($errors->has('total_marks') ? 'border-danger' : ''); ?>" placeholder="Enter Exam Total Marks" name="total_marks">
                                    </div>
                                    <?php if($errors->has('total_marks')): ?>
                                    <span class="offset-md-4 text-danger"><?php echo e($errors->first('total_marks')); ?></span>
                                    <?php endif; ?>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Obtain Marks</label>
                                    <div class="col-md-9">
                                        <input type="text" autofocus id="obtainMarks" <?php if(old('obtain_marks') == ''): ?> value="<?php echo e($result->obtain_marks); ?>" <?php else: ?> value="<?php echo e(old('obtain_marks')); ?>" <?php endif; ?> class="form-control  <?php echo e($errors->has('obtain_marks') ? 'border-danger' : ''); ?>" placeholder="Enter Obtain Marks" name="obtain_marks">
                                        <span class="text-danger">
                                            <?php if($errors->has('obtain_marks')): ?>
                                                <?php echo e($errors->first('obtain_marks')); ?>

                                            <?php endif; ?>
                                        </span>
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Result Status</label>
                                    <div class="col-md-9">
                                        <select class="form-control select2  <?php echo e($errors->has('result') ? 'border-danger' : ''); ?>" name="result" id="result">
                                            <option value="">--Select Result Status--</option>
                                            <option value="1" <?php if($result->result == "1"): ?> selected <?php endif; ?>>Pass</option>
                                            <option value="2" <?php if($result->result > "1"): ?> selected <?php endif; ?>>Fail</option>
                                        </select>
                                        <span class="text-danger">
                                            <?php if($errors->has('result')): ?>
                                                <?php echo e($errors->first('result')); ?>

                                            <?php endif; ?>
                                        </span>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Result Attachment:</label>
                                    <div class="col-md-9">
                                        <input type="file" id="resultAttachment" class="form-control  date <?php echo e($errors->has('result_attachment') ? 'border-danger' : ''); ?>"  name="result_attachment">
                                        <span class="text-danger">
                                        <?php if($errors->has('result_attachment')): ?>
                                                <?php echo e($errors->first('result_attachment')); ?>

                                            <?php endif; ?>
                                    </span>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Certificate</label>
                                    <div class="col-md-9">
                                        <input type="file" id="certificate" class="form-control date <?php echo e($errors->has('certificate') ? 'border-danger' : ''); ?>"  name="certificate">
                                        <span class="text-danger">
                                        <?php if($errors->has('certificate')): ?>
                                                <?php echo e($errors->first('certificate')); ?>

                                            <?php endif; ?>
                                        </span>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-actions text-center">
                        <input type="submit" value="Update" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>