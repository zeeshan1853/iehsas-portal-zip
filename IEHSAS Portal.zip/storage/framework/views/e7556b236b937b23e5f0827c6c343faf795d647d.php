<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(url('public/vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(url('public/css/jasny-bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('student.save_student')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Student Name</label>
                                    <div class="col-md-9">
                                        <input type="text" id="student_name" autofocus value="<?php echo e(old('student_name')); ?>" class="form-control <?php echo e($errors->has('student_name') ? 'border-danger' : ''); ?>" placeholder="Student Name" name="student_name">
                                    </div>
                                    <span class="offset-md-4 text-danger"></span>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Father Name</label>
                                    <div class="col-md-9">
                                        <input type="text" id="father_name" value="<?php echo e(old('father_name')); ?>" class="form-control <?php echo e($errors->has('father_name') ? 'border-danger' : ''); ?>" placeholder="Father Name" name="father_name">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Contact No</label>
                                    <div class="col-md-9">
                                        <input type="text" id="contact_no" value="<?php echo e(old('contact_no')); ?>" class="form-control  <?php echo e($errors->has('contact_no') ? 'border-danger' : ''); ?>" placeholder="Contact No" name="contact_no">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Admission Date</label>
                                    <div class="col-md-9">
                                        <input type="date" id="admissionDate" class="form-control date <?php echo e($errors->has('admission_date') ? 'border-danger' : ''); ?>"  name="admission_date">
                                        <span class="text-danger">
                                        <?php if($errors->has('admission_date')): ?>
                                                <?php echo e($errors->first('admission_date')); ?>

                                        <?php endif; ?>
                                    </span>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Course Name:</label>
                                    <div class="col-md-9">
                                        <select class="form-control select2  <?php echo e($errors->has('course_id') ? 'border-danger' : ''); ?>" name="course_id" id="course_id">
                                            <option value="" data-teacher = "">--Select Course--</option>
                                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="text-danger">
                                            <?php if($errors->has('course_id')): ?>
                                                <?php echo e($errors->first('course_id')); ?>

                                            <?php endif; ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Batch:</label>
                                    <div class="col-md-9">
                                        <select class="form-control select2  <?php echo e($errors->has('batch_id') ? 'border-danger' : ''); ?>" name="batch_id" id="batch_id">
                                            <option value="" data-teacher = "">--Select Batch--</option>

                                        </select>
                                        <span class="text-danger">
                                            <?php if($errors->has('batch_id')): ?>
                                                <?php echo e($errors->first('batch_id')); ?>

                                            <?php endif; ?>
                                        </span>
                                    </div>

                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Paid Amount</label>
                                    <div class="col-md-9">
                                        <input type="number" id="paid_amount" placeholder="Paid Amount" value="<?php echo e(old('paid_amount')); ?>" class="form-control <?php echo e($errors->has('paid_amount') ? 'border-danger' : ''); ?>"  name="paid_amount">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Due Amount</label>
                                    <div class="col-md-9">
                                        <input type="number" id="dueAmount" readonly value="<?php echo e(old('due_amount')); ?>" class="form-control date <?php echo e($errors->has('due_amount') ? 'border-danger' : ''); ?>"  name="due_amount">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Email</label>
                                    <div class="col-md-9">
                                        <input type="email" id="email" placeholder="Enter Student Email" value="<?php echo e(old('email')); ?>" class="form-control <?php echo e($errors->has('email') ? 'border-danger' : ''); ?>"  name="email">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Date Of Birth</label>
                                    <div class="col-md-9">
                                        <input type="date" id="dateOfBirth" class="form-control date <?php echo e($errors->has('date_of_birth') ? 'border-danger' : ''); ?>"  name="date_of_birth">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Education</label>
                                    <div class="col-md-9">
                                        <select class="form-control select2" name="education_id">
                                            <option value="">--Select Education--</option>
                                            <?php $__currentLoopData = $degress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($degree->id); ?>"><?php echo e($degree->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <?php if($errors->has('education_id')): ?>
                                    <span class="text-danger offset-md-4"><?php echo e($errors->first('education_id')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">How you Find Us. ?</label>
                                    <div class="col-md-9">
                                        <textarea class="form-control" name="find" cols="10" placeholder="How Student Find Us"></textarea>
                                    </div>
                                    <?php if($errors->has('find')): ?>
                                    <span class="text-danger offset-md-4"><?php echo e($errors->first('find')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Student Image</label>
                                    <div class="col-md-9">
                                        <!-- Student Image-->
                                        <div class="form-group">
                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                <div class="fileinput-preview img-thumbnail" data-trigger="fileinput" style="width: 300px; height: 200px;">
                                                    <!-- Demo Image -->

                                                </div>
                                                <div>
                                            <span class="btn btn-outline-secondary btn-file">
                                              <span class="fileinput-new">Select image</span>
                                              <span class="fileinput-exists">Change</span>
                                              <input type="file" name="student_image">
                                            </span>
                                                    <a href="#" class="btn btn-outline-secondary fileinput-exists" data-dismiss="fileinput">Remove</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if($errors->has('studentImage')): ?>
                                        <span class="text-danger offset-md-3"><?php echo e($errors->first('student_image')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">ID Card Image:</label>
                                    <div class="col-md-9">
                                        <input type="file" multiple id="idCardImage" class="form-control idCardImage <?php echo e($errors->has('idCardImage') ? 'border-danger' : ''); ?>"  name="idCardImage[]">
                                    </div>
                                    <?php if($errors->has('idCardImage')): ?>
                                    <span class="text-danger offset-md-4">
                                        <?php echo e($errors->first('idCardImage')); ?>

                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Add Student" id="btnAdd" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(url('public/js/jasny-bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script>
        var dueAmount = 0;
        $(document).ready(function (e) {
            $('.select2').select2();
            var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month + 1;
            if(month < 10) {
                month =  "0" +month;
            }
            if(fullDate < 10)
                fullDate = '0' + fullDate;


            $(".date").val(date.getFullYear() + "-" + month + "-" + fullDate);
        });
        $("#course_id").change(function (e) {
           document.getElementById("paid_amount").value = "";
           document.getElementById("dueAmount").value = "";
           var id = $("#course_id").val();
           $("#batch_id > option ~option").remove();
           if(id == "") {
               return;
           }

           var data = {
               id:id,
           };
           $.ajax({
              url:"<?php echo e(route('batch.get_batch')); ?>",
              data:data,
              dataType:'JSON',
              type:'POST',
              complete:function (jqXHR,textStatus) {
                  if(jqXHR.status == 200) {
                      var result = JSON.parse(jqXHR.responseText);
                      if(result.hasOwnProperty('success')) {
                            var output = "";
                            $.each(result.batches,function (index,batch) {
                                output += "<option value='"+batch.id+"' data-amount='"+batch.course_price+"'>"+batch.batch_name+"</option>";
                            });
                            $("#batch_id").append(output);
                      }
                  }
              } 
           });
        });
        $("#batch_id").change(function (e) {
            dueAmount = $('option:selected',this).data('amount');
            $("#dueAmount").val(dueAmount);
        });
        $("#paid_amount").change(function (e) {
            var due = parseInt(dueAmount);
            var paidAmount = parseInt($("#paid_amount").val());
            if(paidAmount == "" || paidAmount == 0 || isNaN(paidAmount)) {
                $("#dueAmount").val(dueAmount);
                return;
            }
            if(paidAmount > due) {
                toastr.error("Paid Amount not be greater then due amount");
                $("#paid_amount").val(0);
                $("#dueAmount").val(dueAmount);
                return ;
            }
            var net = due  - paidAmount;
            $("#dueAmount").val(net);
        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>