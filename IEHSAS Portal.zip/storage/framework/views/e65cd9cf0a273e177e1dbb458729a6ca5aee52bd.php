<?php $__env->startSection('header-styles'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div id="app">
    <div class="row">
        <add-permission :path="'<?php echo e(url('/admin')); ?>'" :asset="'<?php echo e(asset('/')); ?>'"></add-permission>
        <role-permissions :path="'<?php echo e(url('/admin')); ?>'" :asset="'<?php echo e(asset('/')); ?>'"></role-permissions>
    </div>    
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>