

<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(asset('vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('expense.store')); ?>">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> Expense Details</h4>
                            <div class="form-group row">
                                <label class="col-md-2 label-control">Expense Type:</label>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <select class="form-control select2" tabindex="01" autofocus name="expense_type_id" id="expenseTypeId">
                                            <option value="">--Select Expense Type--</option>
                                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="input-group-append">
                                            <span class="input-group-text">
                                                <a href="#" id="addExpenseType" class="color:blue"><span class="ft-plus"></span></a>
                                            </span>
                                        </div>
                                    </div>
                                    <?php if($errors->has('expense_type_id')): ?>
                                        <span  class="text-danger"><?php echo e($errors->first('expense_type_id')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-2 label-control">Expense Name:</label>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <select class="form-control select2" tabindex="02" name="expense_name_id" id="expenseNameId">
                                            <option value="">--Select Expense Name--</option>
                                        </select>
                                        <div class="input-group-append">
                                            <span class="input-group-text">
                                                <a href="#" id="addExpenseName" class="color:blue"><span class="ft-plus"></span></a>
                                            </span>
                                        </div>
                                    </div>
                                    <?php if($errors->has('expense_name_id')): ?>
                                        <span  class="text-danger"><?php echo e($errors->first('expense_name_id')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-2 label-control">Description:</label>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <textarea id="" name="description" tabindex="03" placeholder="Expense Description" class="form-control" rows="5"></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-2 label-control">Amount:</label>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <input type="number" name="amount" tabindex="04" <?php if(old('amount')): ?> value="<?php echo e(old('amount')); ?>" <?php endif; ?> placeholder="Enter Expense Amount" class="form-control">
                                    </div>
                                    <?php if($errors->has('amount')): ?>
                                        <span  class="text-danger"><?php echo e($errors->first('amount')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-2 label-control">Payment Type:</label>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <select class="form-control" name="payment_id">
                                            <option>--Select Type Of Payment</option>
                                            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($payment->id); ?>" <?php if(strtolower($payment->name) == "cash"): ?> selected <?php endif; ?> ><?php echo e($payment->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <?php if($errors->has('payment_id')): ?>
                                        <span  class="text-danger"><?php echo e($errors->first('payment_id')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-2 label-control">Date:</label>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <input type="date" name="date" tabindex="05" class="form-control date">
                                    </div>
                                </div>
                                <?php if($errors->has('date')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('date')); ?></span>
                                <?php endif; ?>
                            </div>

                        </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Add Expense" class="btn btn-primary" tabindex="06">
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Add New Expense Type Modal -->
    <div class="modal fade" id="expenseTypeModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
            <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Add New Expense Type</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <form method="post" id="expenseTypeForm">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="name">Expense Type Name * <small>(Required)</small></label>
                        <input type="text" name="name" id="typeName" placeholder="Enter Expense Type Name" class="form-control">
                    </div>
                </form>
                
            <div class="modal-footer">
            <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-danger" id="saveType">Save</button>
            </div>
        </div>
        </div>
    </div>
    </div>
    <!-- Ending -->

    <!-- Add New Expense Name Modal -->
    <div class="modal fade" id="expenseNameModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
            <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Add New Expense Name</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <form method="post" id="expenseNameForm">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="name">Expense Name * (Required)</label>
                        <input type="text" name="name" placeholder="Enter Expense Name" id="expenseName" class="form-control">
                    </div>
                </form>
            <div class="modal-footer">
            <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-danger" id="saveName">Save</button>
            </div>
        </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script>
        $(document).ready(function (e) {
           $('.select2').select2();
            var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month + 1;
            if(month < 10)
                month = '0'+ month;
            if(fullDate < 10)
                fullDate = '0' + fullDate;

            $(".date").val(date.getFullYear() + "-" + month + "-" + fullDate);
        });
        $(document).ready(function (e) {
            $(document).on('focus','.select2',function (e) {
                $(this).siblings('select').select2('open');
            });
            $("#expenseTypeId").focus();
        });
        $("#addExpenseType").click(function(e) {
            $("#expenseTypeModal").modal();
        })
        $("#addExpenseName").click(function(e) {
            $("#expenseNameModal").modal();
        });
        $("#saveType").click(function() {
            
            var name = $("#typeName").val();
            if(name == "" || name.length < 2) {
                toastr.error("Check Your Errors");
                return;
            }
            var data = $("#expenseTypeForm").serializeArray();
            $.ajax({
                url:"<?php echo e(route('expenseType.store')); ?>",
                data:data,
                dataType:'JSON',
                type:'POST',
                complete:function(jqXHR,textStatus) {
                    if(jqXHR.status == 200) {
                        var result = JSON.parse(jqXHR.responseText);
                        if(result.hasOwnProperty('success')) {
                            var types = result.types;
                            var output = "";
                            types.forEach(function(type) {
                                output += "<option value='"+type.id+"'>"+type.name+"</option>";
                            });
                            $("#expenseTypeId > option ~ option").remove();

                            $("#expenseTypeId").append(output);
                            $("#typeName").val("");
                            $("#expenseTypeModal").modal('hide');
                            $("#typeName").val("");
                            $("#expenseTypeId").focus();
                            toastr.success("Expense Type Added Successfully");
                            
                        }
                    } else if(jqXHR.status == 422) {
                        var result = JSON.parse(jqXHR.responseText);
                        var errors = result.errors;
                        for(error in errors) {
                            toastr.error(errors[error]);
                        }
                    } 
                    else {
                        toastr.error("Opss Someting Went Wrong");            
                    }
                }
            });
        });
        $(document).ready(function() {
            $("#saveName").click(function(e) {
                var name = $("#expenseName").val();
                if(name == "" || name.length < 2) {
                    toastr.error("Please Fill all Required Fields");
                    return;
                }
                var expense_type_id = $("#expenseTypeId").val();
                if(expense_type_id == "") {
                    toastr.error("Please Select Any Expense Type");
                }
                var data = {
                    'name':name,
                    'expense_type_id':expense_type_id,
                };
                $.ajax({
                    data:data,
                    url:"<?php echo e(route('expenseName.store')); ?>",
                    dataType:'JSON',
                    type:'POST',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var output = "";
                                var names = result.names;
                                names.forEach(function(name) {
                                    output += "<option value='"+name.id+"'>"+name.name+"</option>";
                                });
                                $("#expenseNameId > option ~ option").remove();
                                $("#expenseNameId").append(output);
                                $("#expenseName").val("");
                                $("#expenseNameModal").modal('hide');
                                toastr.success("Expense Name Added Successsfully");
                            }
                        } else if(jqXHR.status == 422) {
                            var result = JSON.parse(jqXHR.responseText);
                            var errors = result.errors;
                            for(error in errors) {
                                toastr.error(errors[error]);
                            }
                        } 
                        else {
                            toastr.error("Opss Something Went Worng");
                        }
                    }
                });
            });
            $("#expenseTypeId").change(function(e) {
                var id = $("#expenseTypeId").val();
                var data = {
                    id:id,
                };
                $.ajax({
                    url:"<?php echo e(route('expenseName.showAjax')); ?>",
                    data:data,
                    dataType:'JSON',
                    type:'POST',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var names = result.names;
                                var output = "";
                                names.forEach(function(name) {
                                    output += "<option value='"+name.id+"'>"+name.name+"</option>";
                                });
                                $("#expenseNameId > option ~option").remove();
                                $("#expenseNameId").append(output);
                            }
                        }
                         else {
                            toastr.error("Opss Someting Went Wrong");
                        }
                    }
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>