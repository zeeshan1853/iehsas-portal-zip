<?php $__env->startSection('header-styles'); ?>
<link href="<?php echo e(asset('vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('outgoingCertificate.update',['id'=>$outgoing->id])); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="branch_id" value="<?php echo e(Auth::user()->branch->id); ?>">
                    <input type="hidden" name="certificate_id" value="<?php echo e($outgoing->certificate->id); ?>">
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Certificate No</label>
                                    <div class="col-md-9">
                                        <input type="text" id="courierName" autofocus <?php if(old('courier_name') == ''): ?> value="<?php echo e($outgoing->courier_name); ?>" <?php else: ?> vlaue="<?php echo e(old('courier_name')); ?>" <?php endif; ?> class="form-control <?php echo e($errors->has('courier_name') ? 'border-danger' : ''); ?>" placeholder="Enter Courier Name" name="courier_name">
                                        <?php if($errors->has('courier_name')): ?>
                                            <span class=" text-danger"><?php echo e($errors->first('courier_name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>

                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Tracking No</label>
                                    <div class="col-md-9">
                                        <input type="text" id="trackingNo" <?php if(old('tracking_no') == ''): ?> value="<?php echo e($outgoing->tracking_no); ?>" <?php else: ?> value="<?php echo e(old('tracking_no')); ?>" <?php endif; ?> class="form-control <?php echo e($errors->has('tracking_no') ? 'border-danger' : ''); ?>" placeholder="Enter Tracking No" name="tracking_no">
                                        <?php if($errors->has('tracking_no')): ?>
                                            <span class=" text-danger"><?php echo e($errors->first('tracking_no')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Dispatcher</label>
                                    <div class="col-md-9">
                                        <input type="text" id="dispatcher" <?php if(old('dispatcher') == ''): ?> value="<?php echo e($outgoing->dispatcher); ?>" <?php else: ?> <?php echo e(old('dispatcher')); ?> <?php endif; ?> class="form-control <?php echo e($errors->has('dispatcher') ? 'border-danger' : ''); ?>" placeholder="Enter Dispatcher Name" name="dispatcher">
                                        <?php if($errors->has('dispatcher')): ?>
                                            <span class=" text-danger"><?php echo e($errors->first('dispatcher')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Update" id="btnAdd" class="btn btn-primary">
                        
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>