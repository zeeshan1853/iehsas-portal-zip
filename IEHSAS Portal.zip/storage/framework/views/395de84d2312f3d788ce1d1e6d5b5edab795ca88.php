<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-content collpase show">
                <div class="card-body">
                    <form class="form form-horizontal" method="POST" action="<?php echo e(route('batchAssessment.update',['id'=>$assessment->id])); ?>">

                        <?php echo e(csrf_field()); ?>

                        <div class="form-body">
                            <h4 class="form-section"><i class="fa fa-edit"></i> <?php echo e($page_heading); ?></h4>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="first_name">Obtain Marks :</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <input type="number"  id="obtain_marks" value="<?php echo e($assessment->obtain_marks); ?>" class="form-control" placeholder="Enter Obtain Marks" name="obtain_marks" min="0" autofocus>
                                        <div class="form-control-position">
                                            <i class="ft-percent"></i>
                                        </div>
                                        <?php if($errors->has('obtain_marks')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('obtain_marks')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="first_name">Remarks :</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <textarea class="form-control" name="remarks" placeholder="Enter Remarks"><?php echo e($assessment->remarks); ?></textarea>
                                        <div class="form-control-position">
                                            <i class="ft-percent"></i>
                                        </div>
                                        <?php if($errors->has('remarks')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('remarks')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                            </div>
                        </div>

                        <div class="form-actions">
                            <center>
                                <button type="submit" class="btn btn-primary">Update</button>
                            </center>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>