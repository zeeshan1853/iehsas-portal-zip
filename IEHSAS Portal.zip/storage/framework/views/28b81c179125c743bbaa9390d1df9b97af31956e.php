<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(url('public/vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('batch.store_batch')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> Batch Details</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Batch Name</label>
                                    <div class="col-md-9">
                                        <input type="text" autofocus id="batch_name" value="<?php echo e(old('batch_name')); ?>" class="form-control  <?php echo e($errors->has('batch_name') ? 'border-danger' : ''); ?>" placeholder="Batch Name" name="batch_name">
                                    </div>
                                    <span class="offset-md-4 text-danger"></span>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Course Name</label>
                                    <div class="col-md-9">
                                        <select class="form-control select2   <?php echo e($errors->has('course_id') ? 'border-danger' : ''); ?>" name="course_id" id="course_id">
                                            <option value="" data-teacher = "">--Select Course--</option>
                                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($course->id); ?>" data-teacher="<?php echo e($course->teacher_id); ?>"><?php echo e($course->course_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="text-danger">
                                            <?php if($errors->has('course_id')): ?>
                                                <?php echo e($errors->first('course_id')); ?>

                                            <?php endif; ?>
                                        </span>
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Teacher Name</label>
                                    <div class="col-md-9">
                                        <select class="form-control select2  <?php echo e($errors->has('teacher_id') ? 'border-danger' : ''); ?>" name="teacher_id" id="teacher_id">
                                            <option value="">--Select Teacher--</option>
                                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($teacher->id); ?>"><?php echo e($teacher->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="text-danger">
                                            <?php if($errors->has('teacher_id')): ?>
                                                <?php echo e($errors->first('teacher_id')); ?>

                                            <?php endif; ?>
                                        </span>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Start Date</label>
                                    <div class="col-md-9">
                                        <input type="date" id="startDate" class="form-control  date <?php echo e($errors->has('start_date') ? 'border-danger' : ''); ?>"  name="start_date">
                                        <span class="text-danger">
                                        <?php if($errors->has('start_date')): ?>
                                                <?php echo e($errors->first('start_date')); ?>

                                            <?php endif; ?>
                                    </span>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">End Date</label>
                                    <div class="col-md-9">
                                        <input type="date" id="endDate" class="form-control date <?php echo e($errors->has('end_date') ? 'border-danger' : ''); ?>"  name="end_date">
                                        <span class="text-danger">
                                        <?php if($errors->has('end_date')): ?>
                                                <?php echo e($errors->first('end_date')); ?>

                                            <?php endif; ?>
                                        </span>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Course Price</label>
                                    <div class="col-md-9">
                                        <input type="number" id="coursePrice" value="<?php echo e(old('course_price')); ?>" class="form-control <?php echo e($errors->has('course_price') ? 'border-danger' : ''); ?>"  name="course_price">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Share Price</label>
                                    <div class="col-md-9">
                                        <input type="number" id="sahrePrice" value="<?php echo e(old('share_price')); ?>" class="form-control  date <?php echo e($errors->has('share_price') ? 'border-danger' : ''); ?>"  name="share_price">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Add Batch" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(url('public/vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script>
        $(document).ready(function (e) {
           $('.select2').select2();
            var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month+1;
            if(month < 10)
                month = '0'+month;
            if(fullDate < 10)
                fullDate = '0' + fullDate;

            $(".date").val(date.getFullYear() + "-" + month + "-" + fullDate);
        });
        $("#course_id").change(function (e) {
            var id = $('option:selected',this).data("teacher");
            $("#teacher_id").val(id);
            $("#teacher_id").trigger('change');
        })
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>