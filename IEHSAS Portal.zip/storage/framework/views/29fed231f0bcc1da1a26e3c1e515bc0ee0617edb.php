<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('student-portal/app/css/plugins/forms/wizard.min.css')); ?>">
<style>
    #number-tabs {
        font-size: 20px;
    }

    input[type=radio] {
        width: 100%;
        height: 1.2em;
    }

    #courseComments {
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<section id="validation">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-content collapse show">
                    <div class="card-body">
                        <form action="#" class="steps-validation wizard-circle">
                            <input type="hidden" name="student_course_id" value="<?php echo e(collect(request()->segments())->last()); ?>">
                            <!-- Step 1 -->
                            <h6>Step 1</h6>
                            <fieldset>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="location1" class="text-bold-600">How Do you rate Overall Course ?</label>
                                            <br>
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <label>1. Excellent</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Excellent" class="course_rating required"
                                                        name="course_rating[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <label>2. Good</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Good" class="course_rating required"
                                                        name="course_rating[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <label>3. Poor</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Poor" class="course_rating required"
                                                        name="course_rating[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-2">
                                                    <label>4. Very Poor</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Very Poor" class="course_rating required"
                                                        name="course_rating[]">
                                                </div>
                                            </div>
                                            <div class="row" id="courseComments">
                                                <div class="form-group mt-4 col-md-12">
                                                    <label class="label-control" for="course_reason">Specify Reason for
                                                        the Improvement ?</label>
                                                    <textarea class="form-control" name="course_comments" id="comment" rows="10"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>

                            <!-- Step 2 -->
                            <h6>Step 2</h6>
                            <fieldset>
                                <h3>What do you think about your trainer(s) ?</h3>
                                <hr>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="location1" class="text-bold-600">1.How well did they present the
                                                Course ?</label>
                                            <br>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>1. Excellent</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Excellent"
                                                        class="course_present required" name="course_present[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>2. Good</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Good" class="course_present required"
                                                        name="course_present[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>3. Poor</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Poor" class="course_present required"
                                                        name="course_present[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>4. Very Poor</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Very Poor"
                                                        class="course_present required" name="course_present[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>5. Not Sure</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Not Sure" class="course_present required"
                                                        name="course_present[]">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="location1" class="text-bold-500">2. Did they make the course
                                                intresting ?</label>
                                            <br>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>1. Excellent</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Excellent"
                                                        class="course_intrest required" name="course_intrest[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>2. Good</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Good" class="course_intrest required"
                                                        name="course_intrest[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>3. Poor</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Poor" class="course_intrest required"
                                                        name="course_intrest[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>4. Very Poor</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Very Poor"
                                                        class="course_intrest required" name="course_intrest[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>4. Not Sure</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Not Sure" class="course_intrest required"
                                                        name="course_intrest[]">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="location1" class="text-bold-500">3. How well did they answer
                                                your Questions ? ?</label>
                                            <br>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>1. Excellent</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Excellent" class="question required"
                                                        name="question[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>2. Good</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Good" class="question required"
                                                        name="question[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>3. Poor</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Poor" class="question required"
                                                        name="question[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>4. Very Poor</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Very Poor" class="question required"
                                                        name="question[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>4. Not Sure</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Not Sure" class="question required"
                                                        name="question[]">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="text-bold-500">4. In Case of Poor or Very Poor please Specify
                                                the reason for the improvement ?</label>
                                            <textarea class="form-control" rows="8" name="teaching_comment"></textarea>

                                        </div>
                                    </div>
                                </div>
                            </fieldset>

                            <!-- Step 3 -->
                            <h6>Step 3</h6>
                            <fieldset>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="location1" class="text-bold-600">1.How were the Training Facilities ? ?</label>
                                            <br>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>1. Excellent</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Excellent"
                                                        class="facilities required" name="facilities[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>2. Good</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Good" class="facilities required"
                                                        name="facilities[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>3. Poor</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Poor" class="facilities required"
                                                        name="facilities[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>4. Very Poor</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Very Poor"
                                                        class="facilities required" name="facilities[]">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label>5. Not Sure</label>
                                                </div>
                                                <div class="col-md-1">
                                                    <input type="radio" value="Not Sure" class="facilities required"
                                                        name="facilities[]">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="suggesion text-bold-600">2. Any Suggestions to improve the training facilities ?</label>
                                            <textarea class="form-control" name="facilities_comment" placeholder="Enter Suggestion.." rows="5"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="level" class="text-bold-500">3. How was the level of this course ?</label>
                                                <br>
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <label>1. Excellent</label>
                                                    </div>
                                                    <div class="col-md-1">
                                                        <input type="radio" value="Excellent"
                                                            class="difficulty required" name="difficulty[]">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <label>2. Good</label>
                                                    </div>
                                                    <div class="col-md-1">
                                                        <input type="radio" value="Good" class="difficulty required"
                                                            name="difficulty[]">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <label>3. Poor</label>
                                                    </div>
                                                    <div class="col-md-1">
                                                        <input type="radio" value="Poor" class="difficulty required"
                                                            name="difficulty[]">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <label>4. Very Poor</label>
                                                    </div>
                                                    <div class="col-md-1">
                                                        <input type="radio" value="Very Poor"
                                                            class="difficulty required" name="difficulty[]">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-3">
                                                        <label>5. Not Sure</label>
                                                    </div>
                                                    <div class="col-md-1">
                                                        <input type="radio" value="Not Sure" class="difficulty required"
                                                            name="difficulty[]">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="suggesion text-bold-600">4. Any Suggestions to improve the Course ?</label>
                                                <textarea class="form-control" name="course_suggestion" placeholder="Enter Suggestion.." rows="5"></textarea>
                                            </div>
                                        </div>
                                    </div>
                            </fieldset>

                            <!-- Step 4 -->
                            <h6>Step 4</h6>
                            <fieldset>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <label for="enjoy" class="text-bold-600">1. What Did you enjoy and least about the course and why? Give Reason</label>
                                        <textarea class="form-control required" rows="6" placeholder="Give Reason" name="enjoy"></textarea>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <label for="recommend" class="text-bold-600">2. Would you like to recommend this course to others ?</label>
                                        <br>
                                        <label class="label-control">Yes &nbsp;<input type="radio" value="yes" class="required" name="recommend[]"></label>
                                        <label class="label-control">No  &nbsp;<input type="radio" value="no" class="required" name="recommend[]"></label>
                                        <textarea class="form-control required" name="recommed_to" rows="5"></textarea>
                                    </div>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    window.Laravel = {
        url:"<?php echo e(url('student/')); ?>",
    };
</script>
<script src="<?php echo e(asset('student-portal/app/vendors/js/extensions/jquery.steps.min.js')); ?>"></script>
<script src="<?php echo e(asset('student-portal/app/vendors/js/forms/validation/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('student-portal/app/js/scripts/forms/wizard-steps.min.js')); ?>"></script>
<script>
    $(document).ready(function(e) {
        $('.course_rating').change(function(e) {
            if($(this).val() == "Very Poor" || $(this).val() == "Poor") {
                $("#courseComments").fadeIn(1000);
                $("#comment").addClass("required");
                $("#courseComments").show();
            } else {
                $("#courseComments").fadeOut(1000);
                $("#comment").removeClass("required");
                $("#courseComments").hide();
            }
        });
         
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_student', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>