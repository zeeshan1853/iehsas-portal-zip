<?php $__env->startSection('header-styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('studentType.update',['id'=>$type->id])); ?>" id="instalmentForm">
                    <?php echo csrf_field(); ?>
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Student Type:</label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('name') == "" ? $type->name : old('name')); ?>" name="name" placeholder="Enter Student Type">
                                    </div>
                                    <span class="offset-md-4 text-danger">
                                        <?php if($errors->has('name')): ?>
                                            <?php echo e($errors->first('name')); ?>

                                        <?php endif; ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-actions ">
                        <input type="submit" value="Update" id="btnAdd" class="btn btn-primary offset-md-5">
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>