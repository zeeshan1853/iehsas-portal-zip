<?php $__env->startSection('header-styles'); ?>
<link href="<?php echo e(asset('vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('certificateType.update',['id'=>$type->id])); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="course">Select Course:</label>
                        <select class="form-control" name="course_id" id="course_id">
                            <option value=""> -- Select Course --</option>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($type->course_id == $course->id): ?>
                                    <option value="<?php echo e($course->id); ?>" selected><?php echo e($course->course_name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_name); ?></option>   
                                <?php endif; ?>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('course_id')): ?>
                            <span class="text-danger"><?php echo e($errors->first('course_id')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="name"> Name</label>
                        <input type="text" name="name" value="<?php echo e($type->name); ?>" class="form-control" placeholder="Enter Certificate Name">
                        <?php if($errors->has('name')): ?>
                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                        <?php endif; ?>
                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Update Certificate Type" id="btnAdd" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
<script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
<script>
    $(document).ready(function(e) {
        $("#course_id").select2();
    })
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>