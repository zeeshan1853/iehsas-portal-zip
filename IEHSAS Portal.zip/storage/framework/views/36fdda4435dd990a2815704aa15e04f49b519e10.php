


<?php $__env->startSection('header-styles'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pages/invoice.min.css')); ?>">
    <style>
        @media  print {
            body * {
                visibility: hidden;
            }
            #invoice, #invoice * {
                visibility: visible;
            }
            #invoice {
                position: absolute;
                left: 0;
                top: 0;
                margin-top: -40px;
            }

        }
        @media  print {

            html, body {
                height:100%;
                margin: 0 !important;
                padding: 0 !important;
                overflow: hidden;
            }

        }
        @page  {  margin: 0mm; }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="content-body" id="invoice">
        <section class="card">
            <div id="invoice-template" class="card-body">
                <!-- Invoice Company Details -->
                <div id="invoice-company-details" class="row">
                    <div class="col-md-6 col-sm-12 text-left text-md-left">
                        <img src="<?php echo e(asset(Auth::user()->branch->setting->logo)); ?>" alt="company logo" class="mb-2" width="70">
                        <ul class="px-0 list-unstyled">
                            <li class="text-bold-700"><?php echo e(Auth::user()->branch->setting->name); ?></li>
                            <li><b>Branch :</b> <?php echo e(Auth::user()->branch->name); ?></li>
                            <li><b>Address :</b> <?php echo e(Auth::user()->branch->setting->address); ?></li>
                            <li><b>Country :</b> <?php echo e(Auth::user()->branch->setting->country); ?></li>
                            <li><b>Mobile No :</b> <?php echo e(Auth::user()->branch->setting->mobile_no); ?></li>
                            <li><b>Phone No :</b> <?php echo e(Auth::user()->branch->setting->phone_no); ?></li>
                        </ul>

                    </div>
                    <div class="col-md-6 col-sm-12 text-center text-md-right">
                        <h2>Student</h2>
                        <p><b>Name :</b> <span class="student_name"></span></p>
                        <p><b>Contact No :</b><span class="contact_no"></span></p>
                        <p><b>Email :</b> <span class="email"></span></p>
                        <p> <b>Date :</b> <span class="date"></span></p>
                    </div>
                </div>
                <!--/ Invoice Company Details -->

                <!-- Invoice Items Details -->
                <div id="invoice-items-details" class="pt-2">
                    <div class="row">
                        <div class="table-responsive col-sm-12">
                            <table class="table table-bordered text-center">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Courses</th>
                                    <th class="">Course Price</th>
                                    <th class="">Paid</th>
                                </tr>
                                </thead>
                                <tbody class="tbody">
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-7 col-sm-12 text-center text-md-left">
                            <p class="lead">Payment Methods:</p>
                            <div class="row">
                                <div class="col-md-8">
                                    <table class="table table-borderless table-sm">
                                        <tbody>
                                        <tr>
                                            <td>Receptionist:</td>
                                            <td class="text-right"><?php echo e(ucfirst(Auth::user()->name)); ?></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5 col-sm-12">
                            <p class="lead">Total due</p>
                            <div class="table-responsive">
                                <table class="table">
                                    <tbody>
                                    <tr>
                                        <td class="text-bold-800">Total</td>
                                        <td class="text-bold-800 text-right"> <span class="total"></span></td>
                                    </tr>
                                    <tr class="bg-grey bg-lighten-4">
                                        <td class="text-bold-800">Balance Due</td>
                                        <td class="text-bold-800 text-right"><span class="due"></span></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="text-center">
                                <p style="margin-bottom: 70px;">Authorized person</p>

                                <h6>Name</h6>
                                <p class="text-muted">Managing Director</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Invoice Footer -->
                <div id="invoice-footer">
                    <div class="row">
                        <div class="col-md-7 col-sm-12">
                            <h6>Terms & Condition</h6>
                            <p>This Invoice may conatin some errors. So kindly if you face any contact administrator. If the amount you
                                submit isnt same on invoice please contact administration.
                            </p>
                        </div>
                    </div>
                </div>
                <!--/ Invoice Footer -->

            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<script>
    $(document).ready(function (e) {
        var body = document.getElementsByTagName('body')[0];
        body.classList.remove('menu-expanded');
        body.classList.add("menu-collapsed");
        var invoice = $("#invoice");
        var instalments = JSON.parse(localStorage.instalments);
        // localStorage.instalments = [];
        console.log(instalments);
        var output = "";
        var total = 0;
        var i = 0;
        instalments.forEach(function (instalment) {
            i++;
            total += parseInt(instalment.paid_amount);
            output +="<tr>"+
                      "<td>"+i+"</td><td>"+instalment.course_name+"</td><td>"+instalment.course_price+"</td><td>"+instalment.paid_amount+"</td>"+
                      "</tr>";    
        });
        $(".tbody > option").remove();
        $(".tbody").append(output);
        $(".total").html(total);
        $(".due").html(instalments[0].due);
        $(".student_name").html(instalments[0].student_name);
        $(".contact_no").html(instalments[0].contact_no);
        $(".email").html(instalments[0].email);
        $(".date").html(instalments[0].date);
        window.print();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_print', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>