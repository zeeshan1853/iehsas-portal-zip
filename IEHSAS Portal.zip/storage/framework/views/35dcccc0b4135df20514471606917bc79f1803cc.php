

<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(asset('vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/jasny-bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <style>
        .idCard img {
            margin-top:10px;
            margin-left: 5px;
            border:1px solid #9ea5b0;
            animation: fadein 3;
            -moz-animation: fadein 2s; /* Firefox */
            -webkit-animation: fadein 2s; /* Safari and Chrome */
            -o-animation: fadein 2s; /* Opera */
        }
        .idCard img:first-of-type {
            margin-left: 0px;
        }
        @keyframes  fadein {
            from {
                opacity:0;
            }
            to {
                opacity:1;
            }
        }
        @-moz-keyframes fadein { /* Firefox */
            from {
                opacity:0;
            }
            to {
                opacity:1;
            }
        }
        @-webkit-keyframes fadein { /* Safari and Chrome */
            from {
                opacity:0;
            }
            to {
                opacity:1;
            }
        }
        @-o-keyframes fadein { /* Opera */
            from {
                opacity:0;
            }
            to {
                opacity: 1;
            }
        }
        
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('student.save_student')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="branch_id" value="<?php echo e(Auth::user()->branch->id); ?>">
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?> | Required <span class="text-danger">*</span></h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Student Name <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" id="student_name" autofocus value="<?php echo e(old('student_name')); ?>" class="form-control <?php echo e($errors->has('student_name') ? 'border-danger' : ''); ?>" placeholder="Student Name" name="student_name">
                                    </div>
                                    <span class="offset-md-4 text-danger"></span>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Father Name <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" id="father_name" value="<?php echo e(old('father_name')); ?>" class="form-control <?php echo e($errors->has('father_name') ? 'border-danger' : ''); ?>" placeholder="Father Name" name="father_name">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Contact No <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" id="contact_no" value="<?php echo e(old('contact_no')); ?>" class="form-control  <?php echo e($errors->has('contact_no') ? 'border-danger' : ''); ?>" placeholder="Contact No" name="contact_no">
                                        <?php if($errors->has('contact_no')): ?>
                                            <span class="text-danger "><?php echo e($errors->first('contact_no')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput4">Emergency Contact <span class="text-danger">*</span></label>
                                        <div class="col-md-9">
                                            <input type="text" name="emergency" placeholder="Emergency Contact No" class="form-control <?php echo e($errors->has('emergency') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('emergency')); ?>">
                                            <?php if($errors->has('emergency')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('emergency')); ?></span>
                                            <?php endif; ?>
                                        </div>
    
                                    </div>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Email <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="email" id="email" placeholder="Enter Student Email" value="<?php echo e(old('email')); ?>" class="form-control <?php echo e($errors->has('email') ? 'border-danger' : ''); ?>"  name="email">
                                    </div>
                                    <?php if($errors->has('email')): ?>
                                    <span class="text-danger offset-md-4"><?php echo e($errors->first('emails')); ?></span>
                                    <?php endif; ?>
                                    
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Date Of Birth <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="date" id="dateOfBirth" class="form-control date <?php echo e($errors->has('date_of_birth') ? 'border-danger' : ''); ?>"  name="date_of_birth">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Education <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <select class="form-control select2" name="education_id">
                                            <option value="">--Select Education--</option>
                                            <?php $__currentLoopData = $degress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($degree->id); ?>" <?php if(old('education_id') == $degree->id): ?> selected <?php endif; ?>><?php echo e($degree->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('education_id')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('education_id')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">How you Find Us. ? <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <textarea class="form-control <?php echo e($errors->has('find') ? 'is-invalid' : ''); ?>" name="find" cols="10" placeholder="How Student Find Us"> <?php if(old('find') != ""): ?> <?php echo e(old('find')); ?>  <?php endif; ?></textarea>
                                        <?php if($errors->has('find')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('find')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Address <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <textarea class="form-control" name="address" cols="10" placeholder="Student Address"><?php if(old('address') != ""): ?> <?php echo e(old('address')); ?> <?php endif; ?></textarea>
                                    </div>
                                    <?php if($errors->has('address')): ?>
                                        <span class="text-danger offset-md-4"><?php echo e($errors->first('address')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">ID Card No</label>
                                    <div class="col-md-9">
                                        <input type="text" name="id_card" value="<?php echo e(old('id_card')); ?>" placeholder="ID Card No" class="form-control">
                                        <?php if($errors->has('id_card')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('id_card')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Gender <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <label>Male &nbsp;&nbsp;<input type="radio" name="gender[]" value="male" checked></label>&nbsp;&nbsp;
                                        <label>Female &nbsp;&nbsp;<input type="radio" name="gender[]" value="female"></label>
                                        <?php if($errors->has('gender')): ?>
                                            <div class="text-danger"><?php echo e($errors->first('gender')); ?></div>
                                        <?php endif; ?>
                                    </div>

                                </div>
                                
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Reference By </label>
                                    <div class="col-md-9">
                                        <select class="select2 form-control" id="agent_id" name="agent_id">
                                            <option value="">--Select Agent --</option>
                                            <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($agent->id); ?>"><?php echo e($agent->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('reference')): ?>
                                            <div class="text-danger"><?php echo e($errors->first('reference')); ?></div>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Student Image <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <!-- Student Image-->
                                        <div class="form-group">
                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                <div class="fileinput-preview img-thumbnail" data-trigger="fileinput" style="width: 300px; height: 200px;">
                                                    <!-- Demo Image -->

                                                </div>
                                                <div>
                                            <span class="btn btn-outline-secondary btn-file">
                                              <span class="fileinput-new">Select image</span>
                                              <span class="fileinput-exists">Change</span>
                                              <input type="file" name="student_image">
                                            </span>
                                                    <a href="#" class="btn btn-outline-secondary fileinput-exists" data-dismiss="fileinput">Remove</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if($errors->has('student_image')): ?>
                                        <span class="text-danger offset-md-3"><?php echo e($errors->first('student_image')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row idCard">
                                    <label class="col-md-3 label-control" for="userinput3">ID Card Image </label>
                                    <div class="col-md-9">
                                        <input type="file" multiple id="images" class="form-control idCardImage <?php echo e($errors->has('idCardImage') ? 'border-danger' : ''); ?>"  name="idCardImage[]">
                                        <div class="images"></div>
                                    </div>
                                    <?php if($errors->has('idCardImage')): ?>
                                    <span class="text-danger offset-md-4">
                                        <?php echo e($errors->first('idCardImage')); ?>

                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Designation <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <select class="form-control <?php echo e($errors->has('designation') ? 'is-invalid' : ''); ?>" name="designation" id="job_designation">
                                            <option value="">--Select Designation--</option>
                                            <option value="0" <?php if(old('designation') == 0 && old('designation') != ''): ?> selected <?php endif; ?>>Unemployeed</option>
                                            <option value="1" <?php if(old('designation') == 1): ?> selected <?php endif; ?>>Employeed</option>
                                        </select>
                                        <?php if($errors->has('designation')): ?>
                                            <div class="text-danger"><?php echo e($errors->first('designation')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="designation">
                            <h4 class="form-section"><i class="ft-settings"></i> Student Designation Detail</h4>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput1">Current Designation <span class="text-danger">*</span></label>
                                        <div class="col-md-9">
                                            <input type="text" id="current_designation" value="<?php echo e(old('current_designation')); ?>" class="form-control <?php echo e($errors->has('current_designation') ? 'border-danger' : ''); ?>" placeholder="Current Designation" name="current_designation">
                                        </div>
                                        <?php if($errors->has('current_designation')): ?>
                                            <span class="offset-md-4 text-danger">
                                                <?php echo e($errors->first('current_designation')); ?>

                                            </span>
                                        <?php endif; ?>
                                        
                                    </div>
    
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput3">Company Name <span class="text-danger">*</span></label>
                                        <div class="col-md-9">
                                            <input type="text" id="company_name" value="<?php echo e(old('company_name')); ?>" class="form-control <?php echo e($errors->has('company_name') ? 'border-danger' : ''); ?>" placeholder="Company Name" name="company_name">
                                        </div>
                                        <?php if($errors->has('compnay_name')): ?>
                                            <span class="text-danger offset-md-4">
                                                <?php echo e($errors->first('compnay_name')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput1">Company Country <span class="text-danger">*</span></label>
                                        <div class="col-md-9">
                                            <div class="input-group">
                                                <select name="country_id" class="form-control <?php echo e($errors->has('country_id') ? 'is-invalid' : ''); ?>" id="country_id">
                                                    <option value="0">--Select Company Country--</option>
                                                </select>
                                            </div>
                                        </div>
                                        <?php if($errors->has('country_id')): ?>
                                            <span class="offset-md-4 text-danger">
                                                <?php echo e($errors->first('country_id')); ?>

                                            </span>
                                        <?php endif; ?>
                                        
                                    </div>
    
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput3">Company State <span class="text-danger">*</span></label>
                                        <div class="col-md-9">
                                            <div class="input-group">
                                                <select name="state_id" class="form-control <?php echo e($errors->has('country_id') ? 'is-invalid' : ''); ?>" id="state_id">
                                                    <option value="0">--Select Company State--</option>
                                                </select>
                                                <span class="state_loader"></span>
                                            </div>
                                        </div>
                                        <?php if($errors->has('state_id')): ?>
                                            <span class="text-danger offset-md-4">
                                                <?php echo e($errors->first('state_id')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput1">Company City <span class="text-danger">*</span></label>
                                        <div class="col-md-9">
                                            <div class="input-group">
                                                <select name="city_id" class="form-control <?php echo e($errors->has('country_id') ? 'is-invalid' : ''); ?>" id="city_id">
                                                    <option value="0">--Select Company City--</option>
                                                </select>
                                                <span class="city_loader"></span>
                                            </div>
                                        </div>
                                        <?php if($errors->has('city_id')): ?>
                                            <span class="offset-md-4 text-danger">
                                                <?php echo e($errors->first('city_id')); ?>

                                            </span>
                                        <?php endif; ?>
                                        
                                    </div>
    
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput3">Student C.v</label>
                                        <div class="col-md-9">
                                            <input type="file" name="resume" class="form-control <?php echo e($errors->has('resume') ? 'is-invalid' : ''); ?>">
                                        </div>
                                        <?php if($errors->has('resume')): ?>
                                            <span class="text-danger offset-md-4">
                                                <?php echo e($errors->first('resume')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Add Student" id="btnAdd" class="btn btn-primary">
                        
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('js/jasny-bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script>
        var dueAmount = 0;
        $(document).ready(function (e) {
            $('.select2').select2();
            var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month + 1;
            if(month < 10) {
                month =  "0" +month;
            }
            if(fullDate < 10)
                fullDate = '0' + fullDate;


            $(".date").val(date.getFullYear() + "-" + month + "-" + fullDate);
            <?php if(old('designation') == '' || old('designation') == 0 ): ?>
                $("#designation").hide();
            <?php endif; ?>
            $("#job_designation").change(function(e) {
                var value = $("#job_designation").val();
                if(value == 1) {
                    $("#designation").fadeIn(1000);
                    $("#designation").show();
                    //get countries
                    $.ajax({
                        url:"<?php echo e(route('location.countries')); ?>",
                        dataType:'JSON',
                        type:'GET',
                        complete:function(jqXHR,textStatus) {
                            if(jqXHR.status == 200) {
                                var result = JSON.parse(jqXHR.responseText);
                                if(result.hasOwnProperty('success')) {
                                    var countries = result.countries;
                                    var output = "";
                                    countries.forEach(function(country) {
                                        output += "<option value='"+country.id+"'>"+country.name+"</option>";
                                    });
                                    $("#country_id > option ~ option").remove();
                                    $("#country_id").append(output);
                                }
                            } else {
                                toastr.error("Contact Admin "+jqXHR.status);
                            }
                        }
                    });                     
                } else {
                    $("#designation").fadeOut(1000)
                    
                }
            });
            $("#country_id").change(function(e) {
                $("#satte_id > option ~ option").remove();
                $("#city_id > option ~ option").remove();
                var id = $("#country_id").val();
                if(id == "" || id == 0) {
                    return;
                }
                var data = {
                    country_id:id,
                };
                $.ajax({
                    url:"<?php echo e(route('location.states')); ?>",
                    data:data,
                    dataType:'JSON',
                    type:'POST',
                    beforeSend:function(xhr) {
                        $(".state_loader").html(ajaxLoader);
                    },
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var states = result.states;
                                var output = "";
                                states.forEach(function(state) {
                                    output += "<option value='"+state.id+"'>"+state.name+"</option>";
                                });
                                $("#state_id > option ~ option").remove();
                                $("#state_id").append(output);
                                $(".state_loader").html("");
                            }
                        }
                    }
                }); 
            });
            $("#state_id").change(function(e) {
                $("#city_id > option ~ option").remove();
                var id = $("#state_id").val();
                if(id == "" || id == 0) {
                    return;
                }
                var data = {
                    state_id:id,
                };
                $.ajax({
                    url:"<?php echo e(route('location.cities')); ?>",
                    data:data,
                    dataType:'JSON',
                    type:'POST',
                    beforeSend:function(xhr) {
                        $(".city_loader").html(ajaxLoader);
                    },
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var cities = result.cities;
                                var output = "";
                                cities.forEach(function(city) {
                                    output += "<option value='"+city.id+"'>"+city.name+"</option>";
                                });
                                $("#city_id > option ~ option").remove();
                                $("#city_id").append(output);
                                $(".city_loader").html("");
                            }
                        }
                    }
                });
            })
        });
        function previewImages() {

            var $preview = $('.images').empty();
            if (this.files) $.each(this.files, readAndPreview);

            function readAndPreview(i, file) {

                if (!/\.(jpe?g|png|gif)$/i.test(file.name)){
                    return alert(file.name +" is not an image");
                } // else...

                var reader = new FileReader();

                $(reader).on("load", function() {
                    $preview.append($("<img/>", {src:this.result, height:100}));
                });

                reader.readAsDataURL(file);
            }
        }
        $('#images').on("change", previewImages);
        
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>