<?php $__env->startSection('header-styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="row">
    <div class="card col-md-12">
        <div class="card-body">
            <table class="table table-striped text-center">
                <thead>
                    <tr class="bg-primary text-white" >
                        <td>Sr.No</td>
                        <td>Assessment No</td>
                        <td>Total marks</td>
                        <td>Obatain Marks</td>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; 
                        $total_marks = 0; 
                        $total_obtain = 0; 
                    ?>
                    <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td>Test <?php echo e($i++); ?></td>
                            <?php if($report != null): ?> 
                                <td> <?php echo e($report->batchAssessment->total_marks); ?> </td>
                            <?php else: ?>
                                <td>N/A</td>
                            <?php endif; ?>
                            <td><?php echo e($report != null ? $report->obtain_marks : "N/A"); ?></td>
                        </tr>
                        <?php
                            $report != null ? $total_marks += $report->batchAssessment->total_marks : 0;
                            $report != null ? $total_obtain += $report->obtain_marks : 0;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot >
                    <tr class="bg-info text-white">
                        <td></td>
                        <td></td>
                        <td class="text-bold-600"><?php echo e($total_marks); ?></td>
                        <td class="text-bold-600"><?php echo e($total_obtain); ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>