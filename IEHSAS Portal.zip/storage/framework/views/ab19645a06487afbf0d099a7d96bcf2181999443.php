<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Complain List</title>
    <style>
        table{
            border-collapse: collapse;
            width:100%;
        }
    </style>
</head>
<body>
    <center><img src="<?php echo e(asset(Auth::user()->branch->setting->logo)); ?>" width="200"></center>
    <hr>
    <table border="1px">
        <tr>
            <th>Sr.No</th>
            <th>Student Name</th>
            <th>Course</th>
            <th>Complain</th>
            <th>Remakrs</th>
            <th>Date</th>
            <th>Signed</th>
            <th>Principal</th>
        </tr>
        <tbody class="tbody"></tbody>
    </table>
</body>
</html>
<script>
    document.addEventListener("DOMContentLoaded",function(e) {
        var complains = JSON.parse(localStorage.getItem('complains'));
        let output = "";
        let i = 0;
        complains.forEach(function(complain) {
            i++;
            output += "<tr><td>"+i+"</td><td>"+complain.student+"</td><td>"+complain.course+"</td><td>"+complain.complain+"</td><td>"+complain.remarks+"</td><td>"+complain.created_at+"</td><td></td><td></td></tr>";
        });
        var body = document.querySelector(".tbody");
        body.html = "";
        body.innerHTML += output;
        localStorage.removeItem("complains");
        window.print();
    });
</script>