<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-striped">
                    <thead class="bg-amber">
                        <tr>
                            <td>Sr.No</td>
                            <td>Total Marks</td>
                            <td>Obtain Marks</td>
                            <td>Percentage</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($results) == 0): ?>
                            <tr>
                                <td colspan="4">No Result Found</td>
                            </tr>
                        <?php else: ?>
                            <?php $i=1; ?>
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($result == null ? "N/A" : $result->quiz->total_marks); ?></td>
                                    <td><?php echo e($result == null ? "N/A" : $result->obtain_marks); ?></td>
                                    <?php if($result != null): ?> 
                                        <td><?php echo e(round(($result->quiz->total_marks / $result->obtain_marks) * 100,2)); ?></td>
                                    <?php else: ?>
                                        <td>N/A</td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_student', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>