

<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(url('vendors/css/tables/datatable/datatables.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
<div class="row">
    <div class="card col-md-12">
        <div class="card-body">
            <table class="table table-bordered text-center" id="usersData">
                <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Name</td>
                        <td data-column-id="email">Email</td>
                        <td data-column-id="image">Profile Image</td>
                        <td data-column-id="status" data-sortable="false">Status</td>
                        <td data-column-id="actions">Actions</td>
                    </tr>
                </thead>
                <tbody>
                <?php
                $i = 1;
                ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <img src="<?php echo e(asset($user->image)); ?>" alt="profile image" class="rounded-circle" style="width:80px;height:80px;">
                            </td>
                            <?php if($user->admin): ?>
                                <td><a href="<?php echo e(route('user.remove_admin',['id'=>$user->id])); ?>" class="btn btn-danger">Remove Admin</a> </td>
                            <?php else: ?>
                                <td><a href="<?php echo e(route('user.make_admin',['id'=>$user->id])); ?>" class="btn btn-primary">Make Admin</a> </td>
                            <?php endif; ?>
                            <td>
                                <a href="<?php echo e(route('user.delete_user',['id'=>$user->id])); ?>">
                                    <i class="ft-trash" style="color:red;"></i>    
                                </a> 
                                <?php if($user->status == 1): ?>
                                    <a href="<?php echo e(route('user.deactive',['id'=>$user->id])); ?>" title="Deactive User">
                                        <i class="ft-x-circle" style="color:red;"></i>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('user.activate',['id'=>$user->id])); ?>" title="Activate User">
                                        <i class="ft-check-circle" style="color:green;"></i>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(url('vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/scripts/tables/datatables/datatable-styling.min.js')); ?>"></script>
    <script src="<?php echo e(url('js/scripts/tables/datatables/datatable-basic.min.js')); ?>"></script>
<script>
    $(document).ready(function(e) {
        $("#usersData").DataTable();
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>