<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Fee Challam Form</title>
    <link href="<?php echo e(asset('css/challan.css')); ?>" rel="stylesheet" type="text/css">
    <style>
            @media  print{@page  {size: landscape}}
    </style>
</head>
<body>
    <div id="main">
        <div id="section">
            <div id="one">
                <div class="border">
                    <center><span>4</span></center>
                    <center><span class="company_name"></span></center>
                    <center><span class="copy">Bank Copy</span></center>
                    <center><span class="bank"><?php echo e($bank->name); ?></span></center>
                    <span class="other">Collection A/c # : <span class="account_no"><?php echo e($bank->account_no); ?></span></span><br>
                    <span class="other">Branch : <u class="branch"><?php echo e($bank->bank_branch); ?></u></span><br>
                    <span class="other">Dated : <u class="today"><?php echo e(Date("Y-m-d")); ?></u></span><br>
                    <span class="other">Depositor Name : ___________________</span><br>
                    <span class="other">Father's Name : ____________________</span>
                    <br>
                    <span class="other">CNIC # :__________________________</span>
                    <br>
                    <span class="other">Purpose Of Deposit <u class="purpose">Fee Deposit</u></span>
                    <br>
                    <span class="other">Mode Of Deposit: Cash/Cheque</span>
                    <br>
                    <span class="other">Cheque N0: ____________________</span>
                    <table border="1px">
                        <thead>
                            <tr>
                                <td>No.</td>
                                <td class="particulars">Particulars</td>
                                <td>Amount</td>
                            </tr>
                        </thead>
                        <tbody class="tbody">
                            <?php for($i=1;$i<22;$i++): ?>
                                <tr style='height:15px;'>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            <?php endfor; ?>
                        </tbody>
                        <tfoot>
                            <td></td>
                            <td class="total">Total:</td>
                            <td><b class="total_amount"></b></td>
                        </tfoot>
                            
                        </tr>
                    </table>
                </div>
                <div class="signature">
                    <span class="officer">Officer</span>
                    <span class="cashier">Cashier</span>
                </div>
                
            </div>
            <div id="two">
                <div class="border">
                    <center><span>3</span></center>
                    <center><span class="company_name"></span></center>
                    <center><span class="copy">Copy For College</span></center>
                    <center><span class="bank"><?php echo e($bank->name); ?></span></center>
                    <span class="other">Collection A/c # : <span class="account_no"><?php echo e($bank->account_no); ?></span></span><br>
                    <span class="other">Branch : <u class="branch"><?php echo e($bank->bank_branch); ?></u></span><br>
                    <span class="other">Dated : <u class="today"><?php echo e(Date("Y-m-d")); ?></u></span><br>
                    <span class="other">Depositor Name : ___________________</span><br>
                    <span class="other">Father's Name : ____________________</span>
                    <br>
                    <span class="other">CNIC # :__________________________</span>
                    <br>
                    <span class="other">Purpose Of Deposit <u class="purpose">Fee Deposit</u></span>
                    <br>
                    <span class="other">Mode Of Deposit: Cash/Cheque</span>
                    <br>
                    <span class="other">Cheque No: ____________________</span>
                    <table border="1px">
                        <thead>
                            <tr>
                                <td>No.</td>
                                <td class="particulars">Particulars</td>
                                <td>Amount</td>
                            </tr>
                        </thead>
                        <tbody class="tbody">
                            <?php for($i=1;$i<22;$i++): ?>
                            <tr style='height:15px;'>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <?php endfor; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td></td>
                                <td class="total">Total:</td>
                                <td><b class="total_amount"></b></td>
                            </tr>
                        </tfoot>
                        
                    </table>
                </div>
                <div class="signature">
                    <span class="officer">Officer</span>
                    <span class="cashier">Cashier</span>
                </div>
                
            </div>
            <div id="three">
                <div class="border">
                    <center><span>2</span></center>
                    <center><span class="company_name"></span></center>
                    <center><span class="copy">Copy For Department</span></center>
                    <center><span class="bank"><?php echo e($bank->name); ?></span></center>
                    <span class="other">Collection A/c # : <span class="account_no"><?php echo e($bank->account_no); ?></span></span><br>
                    <span class="other">Branch : <u class="branch"><?php echo e($bank->bank_branch); ?></u></span><br>
                    <span class="other">Dated : <u class="today"><?php echo e(Date("Y-m-d")); ?></u></span><br>
                    <span class="other">Depositor Name : ___________________</span><br>
                    <span class="other">Father's Name : ____________________</span>
                    <br>
                    <span class="other">CNIC # :__________________________</span>
                    <br>
                    <span class="other">Purpose Of Deposit <u class="purpose">Fee Deposit</u></span>
                    <br>
                    <span class="other">Mode Of Deposit: Cash/Cheque</span>
                    <br>
                    <span class="other">Cheque N0: ____________________</span>
                    <table border="1px">
                        <thead>
                            <tr>
                                <td>No.</td>
                                <td class="particulars">Particulars</td>
                                <td>Amount</td>
                            </tr>
                        </thead>
                        <tbody class="tbody">
                            <?php for($i=1;$i<22;$i++): ?>
                                <tr style='height:15px;'>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            <?php endfor; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td></td>
                                <td class="total">Total:</td>
                                <td><b class="total_amount"></b></td>
                            </tr>
                        </tfoot>
                        
                    </table>
                </div>
                <div class="signature">
                    <span class="officer">Officer</span>
                    <span class="cashier">Cashier</span>
                </div>
                
            </div>
            <div id="four">
                <div class="border-last">
                    <center><span>1</span></center>
                    <center><span class="company_name"></span></center>
                    <center><span class="copy">Depositor's Copy</span></center>
                    <center><span class="bank"><?php echo e($bank->name); ?></span></center>
                    <span class="other">Collection A/c # : <span class="account_no"><?php echo e($bank->account_no); ?></span></span><br>
                    <span class="other">Branch : <u class="branch"><?php echo e($bank->bank_branch); ?></u></span><br>
                    <span class="other">Dated : <u class="today"><?php echo e(Date("Y-m-d")); ?></u></span><br>
                    <span class="other">Depositor Name : ___________________</span><br>
                    <span class="other">Father's Name : ____________________</span>
                    <br>
                    <span class="other">CNIC # :__________________________</span>
                    <br>
                    <span class="other">Purpose Of Deposit <u class="purpose">Fee Deposit</u></span>
                    <br>
                    <span class="other">Mode Of Deposit: Cash/Cheque</span>
                    <br>
                    <span class="other">Cheque No: ____________________</span>
                    <table border="1px">
                        <thead>
                            <tr>
                                <td>No.</td>
                                <td class="particulars">Particulars</td>
                                <td>Amount</td>
                            </tr>
                        </thead>
                        <tbody class="tbody">
                            <?php for($i=1;$i<22;$i++): ?>
                            <tr style='height:15px;'>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <?php endfor; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td></td>
                                <td class="total">Total:</td>
                                <td><b class="total_amount"></b></td>
                            </tr>
                        </tfoot>
                        
                    </table>
                </div>
                <div class="signature">
                    <span class="officer">Officer</span>
                    <span class="cashier">Cashier</span>
                </div>
                
            </div>
                        
        </div>
    </div>
</body>
<script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>
<script>
    window.print();
</script>
</html>