<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(url('public/vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('instalment.save')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Course Name</label>
                                    <div class="col-md-9">
                                        <select class="form-control select2" id="course_id" name="course_id">
                                            <option value="">--Select Course--</option>
                                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_name); ?></option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <span class="offset-md-4 text-danger">
                                        <?php if($errors->has('course_id')): ?>
                                            <?php echo e($errors->first('course_id')); ?>

                                        <?php endif; ?>
                                    </span>
                                </div>

                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Batch Name</label>
                                    <div class="col-md-9">
                                        <select class="form-control select2" id="batch_id" name="batch_id">
                                            <option value="">--Select Batch--</option>
                                        </select>
                                    </div>
                                    <span class="text-danger offset-md-4">
                                        <?php if($errors->has('batch_id')): ?>
                                            <?php echo e($errors->first('batch_id')); ?>

                                        <?php endif; ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Student</label>
                                    <div class="col-md-9">
                                        <select class="form-control select2" id="student_id" name="student_id">
                                            <option value="">--Select Student--</option>
                                        </select>
                                    </div>
                                    <span class="offset-md-4 text-danger">
                                        <?php if($errors->has('student_id')): ?>
                                            <?php echo e($errors->first('student_id')); ?>

                                        <?php endif; ?>
                                    </span>
                                </div>

                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Paid Amount</label>
                                    <div class="col-md-9">
                                        <div class="input-group">
                                            <input type="text" class="form-control <?php echo e($errors->has('paid_amount') ? 'is-invalid' : ''); ?>" placeholder="Paid Amount" aria-label="Amount (to the nearest dollar)" name="paid_amount" id="paidAmount">
                                            <div class="input-group-append">
                                                <span class="input-group-text due_amount">0</span>
                                            </div>
                                        </div>
                                    </div>
                                    <span class="offset-md-4 text-danger"></span>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="form-actions ">
                        <input type="submit" value="Add Instalment" disabled="false" id="btnAdd" class="btn btn-primary offset-md-4">
                        <button type="submit" name="print" value="print" class="btn btn-info">Print</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(url('public/vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script>
        var dueAmount = 0;
        $(document).ready(function (e) {

            $('.select2').select2();
            var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month+1;
            if(fullDate < 10)
                fullDate = '0' + fullDate;

            $(".date").val(date.getFullYear() + "-" + month + "-" + fullDate);
            $(".select2").select2();
            $("#course_id").change(function (e) {
                var id = $("#course_id").val();
                if(id == "") {
                    return ;
                }
                var data  = {
                    id:id,
                };
                $.ajax({
                    url:"<?php echo e(route('batch.get_active_batch')); ?>",
                    dataType:'JSON',
                    type:'POST',
                    data:data,
                    complete:function (jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var batches = result.batches;
                                var output = "";
                                batches.forEach(function (e) {
                                    output += "<option value='"+e.id+"'>"+e.batch_name+"</option>";
                                });
                                $("#batch_id > option ~option").remove();
                                $("#batch_id").append(output);
                            }
                        }
                    }
                });
            });
            $("#batch_id").change(function (e) {
                var id = $("#batch_id").val();
                if(id == "") {
                    return ;
                }
               var data = {
                    id:id,
               };
                $.ajax({
                   url:"<?php echo e(route('student.get_batch_student')); ?>",
                   data:data,
                   dataType:'JSON',
                   type:'POST',
                    complete:function (jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var students = result.students;
                                var output = "";
                                students.forEach(function (e) {
                                    output += "<option value='"+e.id+"' data-due-amount='"+e.due_amount+"'>"+e.student_name+"</option>";
                                });
                                $("#student_id > option ~ option").remove();
                                $("#student_id").append(output);
                            }
                        }
                    }
                });
            });
            $("#student_id").change(function (e) {
                var due_amount = $("option:selected",this).data("due-amount");
                $(".due_amount").html(due_amount);
            });
            $("#paidAmount").change(function (e) {
                var due_amount = parseInt($(".due_amount").text());
                var paid_amount = parseInt($("#paidAmount").val());
                if(paid_amount > due_amount) {
                    toastr.error("Paid Amount Cannot be greater then due Amount");
                    $(".btn").attr('disabled',true);
                } else {
                    $(".btn").attr('disabled',false);
                }
            });
        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>