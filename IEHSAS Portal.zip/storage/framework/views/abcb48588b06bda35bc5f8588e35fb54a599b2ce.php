<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(url('public/vendors/css/tables/datatable/datatables.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered" id="batchesData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Batch Name</td>
                        <td data-column-id="coure_name">Course Name</td>
                        <td data-column-id="teacher_name">Teacher Name</td>
                        <td data-column-id="start_date">Start Date</td>
                        <td data-column-id="end_date">End Date</td>
                        <td data-column-id="sahre">Share</td>
                        <td data-column-id="course_price">Course Price</td>
                        <td data-column-id="delete" data-sortable="false">Delete</td>
                        <td data-column-id="edit" data-sortable="false">Edit</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><a href="<?php echo e(route('student.batch_students',['id'=>$batch->id])); ?>"><?php echo e($batch->batch_name); ?></a> </td>
                            <td><a href="<?php echo e(route('course.course_by_id',['id'=>$batch->course_id])); ?>"><?php echo e($batch->course->course_name); ?></a></td>
                            <td><a href=""><?php echo e($batch->teacher->name); ?></a></td>
                            <td><?php echo e($batch->start_date); ?></td>
                            <td><?php echo e($batch->end_date); ?></td>
                            <td><?php echo e($batch->share_price); ?></td>
                            <td><?php echo e($batch->course_price); ?></td>
                            <td><a href="<?php echo e(route('batch.delete_batch',['id'=>$batch->id])); ?>" class="btn btn-danger">Delete</a> </td>
                            <td><a href="<?php echo e(route('batch.edit_batch',['id'=>$batch->id])); ?>" class="btn btn-primary">Edit</a> </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(url('public/vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/js/scripts/tables/datatables/datatable-styling.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/js/scripts/tables/datatables/datatable-basic.min.js')); ?>"></script>
    <script>
        $(document).ready(function(e) {
            $("#batchesData").DataTable();
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>