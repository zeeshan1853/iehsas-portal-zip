<?php $__env->startSection('header-styles'); ?>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('css/jquery.bootgrid.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('css/bootgridcustom.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('css/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css">
<style>
    .bor{
        border-right: 1px solid black;
    }
</style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
<div class="row">
    <div class="card col-md-12">
        <div class="card-header bg-info text-white text-center" style="padding:5px; font-size: 25px;">
             <b><i class="ft-zap"></i> Search Options</b>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-5">
                    <div class="form-group row">
                        <label for="form" class="col-md-2"><b><i class="ft-calendar"></i> From</b></label>
                        <input type="date" class="form-control date col-md-8" id="from">
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="form-group row">
                        <label for="form" class="col-md-2"><b><i class="ft-calendar"></i> To</b></label>
                        <input type="date" class="form-control date col-md-8" id="to">
                    </div>
                </div>
                <div class="col-md-2">
                    <label for="include">Include From To <input type="checkbox" id="fromto"></label>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="card col-md-12">
        <div class="card-body">
                <table class="table table-bordered text-center" id="complains">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="student">Student</td>
                        <td data-column-id="course">Course</td>
                        <td data-column-id="complain">Complain / Sugestion</td>
                        <td data-column-id="remarks">Remarks</td>
                        <td data-column-id="created_at">Complain Date</td>                   
                        <td data-column-id="updated_at">Updated At</td>     
                        <td data-column-id="status" data-sortable="false">Status</td>
                        <td data-column-id="actions" data-sortable="false">Actions</td>
                    </tr>
                    </thead>
                    <tbody>
                    
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Remarks Modal -->
    <div class="modal fade text-left" id="remarksModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header bg-cyan">
                <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Complain Remakrs</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="id" id="complainId">
                    <div class="form-group">
                        <label for="remarks">Remarks</label>
                        <textarea class="form-control" id="remarks" placeholder="Enter Complain Remakrs How you Solve Complain ?"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="save">Save</button>
                <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
            </div>
        </div>
    </div>

    <!-- view Modal -->
    <div class="modal fade text-left" id="viewModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-cyan">
                <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Complain Details</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-5">
                            <h3><i class="ft-user"></i> Student</h3>
                        </div>
                        <span>|</span>
                        <div class="col-md-6">
                            <h4 class="student"></h4>
                        </div>
                    </div>
                    <hr>
                    <div class="row mt-1">
                        <div class="col-md-5">
                            <h3><i class="ft-book"></i> Course</h3>
                        </div>
                        <span>|</span>
                        <div class="col-md-6">
                            <h4 class="course"></h4>
                        </div>
                    </div>
                    <hr>
                    <div class="row mt-1">
                        <div class="col-md-5 ">
                            <h3><i class="ft-compass"></i> Complain / Suggestion</h3>
                        </div>
                        <span>|</span>
                        <div class="col-md-6">
                            <h4 class="complain"></h4>
                        </div>
                    </div>
                    <hr>
                    <div class="row mt-1">
                        <div class="col-md-5 ">
                            <h3><i class="ft-check-circle"></i> Remarks</h3>
                        </div>
                        <span>|</span>
                        <div class="col-md-6">
                            <h4 class="remarks"></h4>
                        </div>
                    </div>
                    <hr>
                    <div class="row mt-1">
                        <div class="col-md-5 ">
                            <h3><i class="ft-calendar"></i> Complain Date</h3>
                        </div>
                        <span>|</span>
                        <div class="col-md-6">
                            <h4 class="created_at"></h4>
                        </div>
                    </div>
                    <hr>
                    <div class="row mt-1">
                        <div class="col-md-5 ">
                            <h3><i class="ft-calendar"></i> Update Date</h3>
                        </div>
                        <span>|</span>
                        <div class="col-md-6">
                            <h4 class="updated_at"></h4>
                        </div>
                    </div>
                    <hr>
                    <div class="row mt-1">
                        <div class="col-md-5 ">
                            <h3><i class="ft-info"></i> Complain Status</h3>
                        </div>
                        <span>|</span>
                        <div class="col-md-6">
                            <h4 class="status"></h4>
                        </div>
                    </div>
                    <hr>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
<script src="<?php echo e(asset('js/jquery.bootgrid.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.bootgrid.fa.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/sweetalert2.all.min.js')); ?>"></script>
    <script>
        var complains = "";
        $(document).ready(function(e) {
            var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month + 1;
            if(month < 10) {
                month =  "0" +month;
            }
            if(fullDate < 10)
                fullDate = '0' + fullDate;
            $(".date").val(date.getFullYear() + "-" + month + "-" + fullDate);
            setTimeout(()=>{
                var body = document.getElementsByTagName('body')[0];
                body.classList.remove('menu-expanded');
                body.classList.add("menu-collapsed");
            },1000);
            $("#complains").bootgrid({
                ajax:true,
                caseSensitive:false,
                searchSetting:{
                    delay:1000,
                },
                labels:{
                    loading:"Loading Please Wait "+ajaxLoader,
                },
                rowCount:[10,20,50,100,-1],
                post:function() {
                    var col_names = {};
                    if(document.getElementById("fromto").checked) {
                        col_names['from_to'] = "from_to";
                        col_names['from'] = document.getElementById("from").value;
                        col_names['to'] = document.getElementById("to").value;
                    }
                    return {
                        col_names:col_names,
                    }
                },
                responseHandler:function(response) {
                    complains = response.rows;
                    return response;
                },
                url:"<?php echo e(route('complain.list')); ?>",
            }).on("loaded.rs.jquery.bootgrid",function() {
                $(".in_progress").click(function(e) {
                    var id = $(this).data("id");
                    var route = "<?php echo e(route('complain.inProgress',':id')); ?>";
                    route = route.replace(":id",id);
                    $.ajax({
                        url:route,
                        dataType:'JSON',
                        type:'GET',
                        complete:function(jqXHR,textStatus) {
                            if(jqXHR.status == 200) {
                                var result = JSON.parse(jqXHR.responseText);
                                if(result.hasOwnProperty('success')) {
                                    toastr.success("Complain Status Change Successfully");
                                    $("#complains").bootgrid('reload');
                                }
                            }
                        }
                    });
                });
                $(".solved").click(function(e) {
                    var id = $(this).data("id");
                    document.getElementById("complainId").value = id;
                    $("#remarksModal").modal();
                    setTimeout(()=>{
                        $("#remarks").focus();
                    },800);
                });
                $(".view").on("click",function(e) {
                    var id = $(this).data("id");
                    //alert(id);
                    var index = complains.findIndex(x => x.id === id);
                    var complain = complains[index];
                    $(".student").html(complain.student);
                    $(".course").html(complain.course);
                    $(".complain").html(complain.complain);
                    $(".remarks").html(complain.remarks);
                    $(".created_at").html(complain.created_at);
                    $(".updated_at").html(complain.updated_at);
                    if(complain.complain_status == 0) {
                        $(".status").html("<span class='badge badge-danger'>New</span>");
                    } else if(complain.complain_status == 1) {
                        $(".status").html("<span class='badge badge-info'>In Progress</span>");
                    } else {
                        $(".status").html("<span class='badge badge-success'>Solved</span>");
                    }
                    $("#viewModal").modal();
                });
                $(".print").on("click",function(e) {
                    var id = $(this).data("id");
                    var index = complains.findIndex(x=>x.id === id);
                    var complain = complains[index];
                    localStorage.setItem("complain",JSON.stringify(complain));
                    window.open("<?php echo e(route('complain.print')); ?>");
                });
            });
            $("#complains-header").find('.actionBar').prepend('<button style="margin-left:10px;" id="btnPrint" class="btn btn-info pull-left btnPrint" type="button"> <span class="icon glyphicon glyphicon-print"></span> Print </button>');
            //update complains
            $("#save").click((e)=>{
                var id = document.getElementById("complainId").value;
                
                var remarks = document.getElementById("remarks");
                if(remarks.value == "" || remarks.value.length < 5 ) {
                    toastr.error("Missing Remarks");
                    remarks.classList.add("is-invalid");
                    return;
                } else {
                    remarks.classList.contains("is-invalid") ? remarks.classList.remove("is-invalid") : '';
                    remarks.classList.add("is-valid");
                }
                var data = {
                    id:id,
                    remarks:remarks.value,
                };
                $.ajax({
                    url:"<?php echo e(route('complain.solved')); ?>",
                    data:data,
                    dataType:'JSON',
                    type:'POST',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                toastr.success("Complain Status Changed Successfully");
                                $("#remarksModal").modal('hide');
                                $("#complains").bootgrid("reload");
                            }
                        } else {
                            toastr.error("Contact Admin"+jqXHR.status);
                        }
                    }
                }); 
            });
            $("#btnPrint").click(function(e) {
                localStorage.setItem('complains',JSON.stringify(complains));
                window.open("<?php echo e(route('complain.printList')); ?>");
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>