<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Enrolment Email</title>
    <style>
        table{
            width:100%;
            border-collapse: collapse;
            text-align: center;
        }
        table tr:first-of-type {
            background-color: #0275d8;
               
        }
        table tr td {
            padding:10px 
        }
    </style>
</head>
<body>
    <?php echo $content; ?>

    <center><h3>COurse Information</h3></center>
    <table border="1px">
        <tr>
            <td>Sr.No</td>
            <td>Course Name</td>
            <td>Batch Name</td>
            <td>Course Price</td>
            <td>Exam Dates</td>
        </tr>
        <tr>
            <td>1</td>
            <td><?php echo e($student_course->course->course_name); ?></td>
            <td><?php echo e($student_course->batch->batch_name); ?></td>
            <td><?php echo e($student_course->batch->course_price); ?></td>
            <td>
                <?php
                    $i=1;
                ?>
                <?php $__currentLoopData = $student_course->examDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    Exam Date <?php echo e($i++); ?> - <?php echo e($date->exam_date->toFormattedDateString()); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tr>
    </table>
</body>
</html>