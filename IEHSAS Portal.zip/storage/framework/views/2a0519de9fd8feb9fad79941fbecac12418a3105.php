<?php $__env->startSection('styles'); ?>
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.css" rel="stylesheet">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-content collpase show">
                    <div class="card-body">
                        <form class="form form-horizontal" method="POST" action="<?php echo e(route('batchDailyActivity.store')); ?>">

                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="batch_id" value="<?php echo e($id); ?>">
                            <div class="form-body">
                                <h4 class="form-section"><i class="fa fa-book"></i> <?php echo e($page_heading); ?></h4>
                                <div class="form-group">
                                    <label for="editor" class="text-bold-600">Today Topic Covered:</label> 
                                    <textarea id="editor" name="content" class="form-control"></textarea>
                                    <?php if($errors->has('content')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('content')); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="improvement" class="text-bold-600">Improvements: </label>
                                    <textarea class="form-control" name="improvement"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="improvement" class="text-bold-600">Suggestions: </label>
                                    <textarea class="form-control" name="suggestion"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="improvement" class="text-bold-600">Remakrs: </label>
                                    <textarea class="form-control" name="remarks"></textarea>
                                </div>
                            </div>
    
                            <div class="form-actions">
                                <center>
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </center>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.js"></script>
<script>
    $(document).ready(function(e) {
        $("#editor").summernote({
            height:300,
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>