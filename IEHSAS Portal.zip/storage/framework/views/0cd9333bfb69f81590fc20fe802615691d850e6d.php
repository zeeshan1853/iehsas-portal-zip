<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="dom">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped text-center">
                            <thead class="bg-primary text-white ">
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Student Name</th>
                                    <th>Total Marks</th>
                                    <th>Obtain marks</th>
                                    <th>Remarks</th>
                                </tr>
                            </thead>
                            <?php $i = 1; ?>
                            <form action="<?php echo e(route('batchAssessment.store',['id'=>$assessment_id])); ?>" method="post">
                                <input type="hidden" name="batch_id" value="<?php echo e(Route::input('batch_id')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <tbody>
                                    <?php $__currentLoopData = $student_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($course['student_name']); ?></td>
                                            <td><?php echo e($course['total_marks']); ?></td>
                                            <td>
                                                <input type="number" min="0" name="students[<?php echo e($course['student_id']); ?>]" class="form-control" placeholder="Enter Obtain Marks" autofocus value="0">
                                            </td>
                                            <td>
                                                <textarea name="remarks[<?php echo e($course['student_id']); ?>]"  class="form-control" placeholder="Enter Remarks / Improvement"></textarea>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="5" class="text-center"><input type="submit" class="btn btn-primary" value="Save"></td>
                                    </tr>
                                </tfoot>
                            </form>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>