

<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(asset('vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('hostelRecovery.store')); ?>" id="hosteRecoveryFrom">
                    <?php echo csrf_field(); ?>
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                        <div class="row">
                            <div class="col-md-12 offset-md-0">
                                <div class="form-group row">
                                    <label class="col-md-1 label-control" for="userinput1">Search Student</label>
                                    <div class="col-md-10">
                                        <select class="form-control select2" id="student_id" name="student_id">
                                            <option value="">--Select Student--</option>
                                        </select>
                                    </div>
                                    <span class="offset-md-4 text-danger student_id has-error">
                                        <?php if($errors->has('student_id')): ?>
                                            <?php echo e($errors->first('student_id')); ?>

                                        <?php endif; ?>
                                    </span>
                                </div>

                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Payment Type</label>
                                    <div class="col-md-9">
                                        <select class="form-control select2" id="payment_id" name="payment_id">
                                            <option value="">--Select Payment Type--</option>
                                            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($payment->id); ?>" <?php if($payment->id == 1): ?> selected <?php endif; ?>><?php echo e($payment->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <span class="offset-md-4 text-danger payment_id has-error">
                                        <?php if($errors->has('payment_id')): ?>
                                            <?php echo e($errors->first('payment_id')); ?>

                                        <?php endif; ?>
                                    </span>
                                </div>

                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Description</label>
                                    <div class="col-md-9">
                                        <textarea name="description" cols="10" class="form-control" placeholder="Enter Description"></textarea>
                                    </div>
                                </div>

                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Paid Amount</label>
                                    <div class="col-md-9">
                                        <div class="input-group">
                                            <input type="number" class="form-control <?php echo e($errors->has('paid_amount') ? 'is-invalid' : ''); ?>" placeholder="Paid Amount" aria-label="Amount (to the nearest dollar)" name="paid_amount" id="paidAmount">
                                            <div class="input-group-append">
                                                <span class="input-group-text due_amount">0</span>
                                            </div>
                                        </div>
                                    </div>
                                    <span class="offset-md-4 text-danger paid_amount has-error"></span>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="form-actions ">
                        <input type="submit" value="Add Hostel Fee" disabled="false" id="btnAdd" class="btn btn-primary offset-md-4">
                        <button type="button" name="print" disabled="true" value="print" class="btn btn-info print">Print</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script>
        $(document).ready(function(e) {
            var due_amount = 0;
            $("#student_id").select2({
                minimumInputLength:5,
                placeholder:'Search Student...',
                ajax:{
                    url:"<?php echo e(route('student.batch_student_ajax')); ?>",
                    dataType:'JSON',
                    type:'POST',
                    delay:1000,
                    data:function(term) {
                        return{
                            term:term,
                        }
                    },
                    processResults:function(data) {
                        return{
                            results: $.map(data, function(item) {
                                return {
                                    text:item.student_name+" "+item.father_name+" "+item.contact_no,
                                    id:item.id,
                                    slug:item.hostel_fee,
                                }
                            })
                        }
                    }
                }
            });
            $('#student_id').on('select2:select', function (e) {
                var data = e.params.data;
                due_amount = data.slug;
                $(".due_amount").html(data.slug);
            });
            $("#paidAmount").keyup(function(e) {
                var value = $(this).val();
                if(value > due_amount || value == 0) {
                    $("#btnAdd").attr("disabled",true);
                    $(".print").attr("disabled",true);
                } else {
                    $("#btnAdd").attr("disabled",false);
                    $(".print").attr("disabled",false);
                }
            });
            $(".print").click(function(e) {
                $(".has-error").html("");
                var data = $("#hosteRecoveryFrom").serializeArray();
                $.ajax({
                    url:"<?php echo e(route('hostelRecovery.storeAjax')); ?>",
                    data:data,
                    dataType:'JSON',
                    type:'POST',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            localStorage.hostelInstalment = JSON.stringify(result.data);
                            window.open("<?php echo e(route('hostelRecovery.print')); ?>");
                            toastr.success("Hostel Fee Added Successfully");
                            $("#student_id > option").remove();
                            $("#paidAmount").val("");
                            $(".due_amount").html("");
                        } else if(jqXHR.status == 422) {
                            var result = JSON.parse(jqXHR.responseText);
                            console.log(result);
                            for(error in result.errors) {
                                $("."+error).html(result.errors[error]);
                            }
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>