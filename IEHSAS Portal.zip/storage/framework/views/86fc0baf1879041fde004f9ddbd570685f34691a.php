<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(url('public/css/jasny-bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('setting.save')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Insitute Name:</label>
                                    <div class="col-md-9">
                                        <input type="text" id="name" autofocus value="<?php echo e(old('name')); ?>" class="form-control <?php echo e($errors->has('name') ? 'border-danger' : ''); ?>" placeholder="Insitute Name" name="name">
                                    </div>
                                    <?php if($errors->has('name')): ?>
                                        <span class="offset-md-4 text-danger"><?php echo e($errors->first('name')); ?></span>

                                    <?php endif; ?>

                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Phone No</label>
                                    <div class="col-md-9">
                                        <input type="text" id="phone_no" value="<?php echo e(old('phone_no')); ?>" class="form-control <?php echo e($errors->has('phone_no') ? 'border-danger' : ''); ?>" placeholder="Phone No" name="phone_no">
                                    </div>
                                    <?php if($errors->has('phone_no')): ?>
                                        <span class="offset-md-4 text-danger"><?php echo e($errors->first('phone_no')); ?></span>

                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Email:</label>
                                    <div class="col-md-9">
                                        <input type="email" id="email" autofocus value="<?php echo e(old('email')); ?>" class="form-control <?php echo e($errors->has('email') ? 'border-danger' : ''); ?>" placeholder="Insitute Email" name="email">
                                    </div>
                                    <?php if($errors->has('email')): ?>
                                        <span class="offset-md-4 text-danger"><?php echo e($errors->first('email')); ?></span>

                                    <?php endif; ?>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Mobile No</label>
                                    <div class="col-md-9">
                                        <input type="text" id="mobile_no" value="<?php echo e(old('mobile_no')); ?>" class="form-control <?php echo e($errors->has('mobile_no') ? 'border-danger' : ''); ?>" placeholder="Mobile No" name="mobile_no">
                                    </div>
                                    <?php if($errors->has('mobile_no')): ?>
                                        <span class="offset-md-4 text-danger"><?php echo e($errors->first('mobile_no')); ?></span>

                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Country:</label>
                                    <div class="col-md-9">
                                        <input type="text" id="email" autofocus value="<?php echo e(old('country')); ?>" class="form-control <?php echo e($errors->has('country') ? 'border-danger' : ''); ?>" placeholder="Country Name" name="country">
                                    </div>
                                    <?php if($errors->has('country')): ?>
                                        <span class="offset-md-4 text-danger"><?php echo e($errors->first('country')); ?></span>

                                    <?php endif; ?>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3"> Insitute Logo</label>
                                    <div class="col-md-9">
                                        <!-- Student Image-->
                                        <div class="form-group">
                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                <div class="fileinput-preview img-thumbnail" data-trigger="fileinput" style="width: 300px; height: 200px;">
                                                    <!-- Demo Image -->
                                                </div>
                                                <div>
                                            <span class="btn btn-outline-secondary btn-file">
                                              <span class="fileinput-new">Select image</span>
                                              <span class="fileinput-exists">Change</span>
                                              <input type="file" name="logo">
                                            </span>
                                                    <a href="#" class="btn btn-outline-secondary fileinput-exists" data-dismiss="fileinput">Remove</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if($errors->has('logo')): ?>
                                        <span class="text-danger offset-md-3"><?php echo e($errors->first('logo')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Address:</label>
                                    <div class="col-md-9">
                                        <textarea cols="10" rows="10" name="address" class="form-control" placeholder="Insitute Address ..."></textarea>
                                    </div>
                                    <?php if($errors->has('address')): ?>
                                        <span class="text-danger offset-md-4">
                                        <?php echo e($errors->first('address')); ?>

                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                    </div>


                    <div class="form-actions text-center">
                        <input type="submit" value="Edit" id="btnAdd" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(url('public/js/jasny-bootstrap.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>