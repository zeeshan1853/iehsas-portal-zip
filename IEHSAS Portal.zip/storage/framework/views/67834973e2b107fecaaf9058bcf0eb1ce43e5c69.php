

<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(asset('vendors/css/tables/datatable/datatables.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="mailsData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="course">Course</td>
                        <td data-column-id="name">Name</td>
                        <td data-column-id="document">Document</td>
                        <td data-column-id="edit" data-sortable="false">Action</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($document->documentType->course->course_name); ?></td>
                            <td><?php echo e($document->name); ?></td>
                            <td>
                                <?php
                                    $extension = File::extension($document->document);
                                ?>
                                <?php if($extension == "jpg" || $extension == "jpeg"): ?>
                                    <img src="<?php echo e(asset($document->document)); ?>" alt="file" style="width:100px;height:100px;">

                                <?php else: ?>
                                    <img src="<?php echo e(asset('images/icons/pdf.png')); ?>" alt="pdf file" style="width:100px;height:100px;">
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('document.edit',['id'=>$document->id])); ?>"><i class="ft-edit"></i></a>
                                <a href="<?php echo e(route('document.delete',['id'=>$document->id])); ?>"><i class="ft-trash" style="color:red;"></i></a>
                                <a href="" class="print" data-document="<?php echo e(asset($document->document)); ?>" <?php if($extension == "jpeg" || $extension == "jpg"): ?> data-type="image" <?php else: ?> data-type="pdf" <?php endif; ?>><i class="ft-printer" style="color:green;"></i></a>
                                <a href="<?php echo e(asset($document->document)); ?>" download class="download" data-document="<?php echo e(asset($document->document)); ?>"><i class="ft-download" style="color:purple;"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/tables/datatables/datatable-styling.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/tables/datatables/datatable-basic.min.js')); ?>"></script>
    <script>
        $(document).ready(function(e) {
            $("#mailsData").DataTable();
            $(".print").click(function(e) {
                e.preventDefault();
                var document = $(this).data("document");
                var type = $(this).data("type");
                if(type == "pdf") {
                    window.open(document);
                } else {
                    myWindow = window.open(document);
                    myWindow.print();
                }
            });
            
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>