<?php $__env->startSection('header-styles'); ?>
<link href="<?php echo e(url('public/vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-8 offset-md-2">
            <div class="card-body">
                <form method="post" action="<?php echo e(route('course.save_course')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label><h5 class="mt-2">Course Name:</h5></label>
                        <input name="course_name" autofocus class="form-control" <?php echo e($errors->has('course_name') ? 'is-invalid':''); ?> placeholder="Course Name"  value="<?php echo e(old('course_name')); ?>">
                        <span class="text-danger">
                            <?php if($errors->has('course_name')): ?>
                                <?php echo e($errors->first('course_name')); ?>

                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary offset-md-4 col-md-4" >
                            Add Course
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
<script src="<?php echo e(url('public/vendors/js/forms/select/select2.full.min.js')); ?>"></script>
<script>
    $(document).ready(function (e) {
        $("#teacher_id").select2();
    })
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>