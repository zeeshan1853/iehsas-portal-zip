

<?php $__env->startSection('header-styles'); ?>
<link href="<?php echo e(asset('css/jasny-bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('agent.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="branch_id" value="<?php echo e(Auth::user()->branch->id); ?>">
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Agent Name</label>
                                    <div class="col-md-9">
                                        <input type="text" id="agentName" autofocus value="<?php echo e(old('name')); ?>" class="form-control <?php echo e($errors->has('name') ? 'border-danger' : ''); ?>" placeholder="Enter Agent Name" name="name">
                                        <?php if($errors->has('name')): ?>
                                            <span class=" text-danger"><?php echo e($errors->first('name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Opening</label>
                                    <div class="col-md-9">
                                            <input type="number" placeholder="Enter Account Opening Balance" value="<?php echo e(old('opening')); ?>" class="form-control <?php echo e($errors->has('opening') ? 'is-invalid' : ''); ?>" name="opening">
                                        <?php if($errors->has('opening')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('opening')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Agent Image</label>
                                    <div class="col-md-9">
                                        <!-- Student Image-->
                                        <div class="form-group">
                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                <div class="fileinput-preview img-thumbnail" data-trigger="fileinput" style="width: 300px; height: 200px;">
                                                    <!-- Demo Image -->

                                                </div>
                                                <div>
                                            <span class="btn btn-outline-secondary btn-file">
                                                <span class="fileinput-new">Select image</span>
                                                <span class="fileinput-exists">Change</span>
                                                <input type="file" name="agent_image">
                                            </span>
                                                    <a href="#" class="btn btn-outline-secondary fileinput-exists" data-dismiss="fileinput">Remove</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if($errors->has('student_image')): ?>
                                        <span class="text-danger offset-md-3"><?php echo e($errors->first('student_image')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Contact No</label>
                                    <div class="col-md-9">
                                        <input type="text" id="contact_no" value="<?php echo e(old('contact_no')); ?>" placeholder="Enter Student Contact No" class="form-control <?php echo e($errors->has('contact_no') ? 'border-danger' : ''); ?>"  name="contact_no">
                                        <?php if($errors->has('contact_no')): ?>
                                            <span class="text-danger contact_no">
                                                <?php echo e($errors->first('contact_no')); ?>

                                            </span>
                                        <?php endif; ?>  
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Save" id="btnAdd" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<script src="<?php echo e(asset('js/jasny-bootstrap.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>