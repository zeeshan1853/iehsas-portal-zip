<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('student-portal/app/css/pages/users.min.css')); ?>">
<style>
    .bor{
        border-right:1px solid #CDCDCE;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-6 offset-md-3">
    <div class="card">
        <div class="text-center">
            <br>
            <img src="<?php echo e(asset($teacher->profile_image)); ?>" class="rounded-circle  height-150" alt="Card image">
            <br><br>
            <div id="rating">
                <?php for($i=0;$i<=4;$i++): ?>
                <?php if($teacher->rating < 3): ?>
                    <span class="ft-star <?php if($i < $teacher->rating): ?> text-danger  <?php endif; ?>"></span>
                <?php else: ?>
                    <span class="ft-star <?php if($i < $teacher->rating): ?> text-success  <?php endif; ?>"></span>
                <?php endif; ?>
                <?php endfor; ?>
                ( <?php echo e($teacher->rating); ?> )
            </div>
            
            <div class="card-body">
                <h2 class="text-bold-600"><?php echo e(ucfirst($teacher->name)); ?>  </h4>
            </div>
        </div>
        <div class="list-group list-group-flush text-bold-500 ">
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-user"></i> Teacher Name</span>
                <span class="col-md-6"><?php echo e(ucfirst($teacher->name)); ?></span>
            </li>
            
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-phone"></i> Contact No</span>
                <span class="col-md-6"><?php echo e($teacher->contact_no); ?></span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-mail"></i> Email</span>
                <span class="col-md-6"><?php echo e($teacher->email); ?></span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-briefcase"></i> Qualification</span>
                <span class="col-md-6">
                    <?php
                        if($teacher->profile->qualification != "")  {
                            
                            $qualifications = preg_split("/,/",$teacher->profile->qulification);
                            if(count($qualifications) == 1) {
                                echo("<span class='badge badge-primary'>".$teacher->profile->qualification."</span>");
                            }
                            else {
                                foreach($qualifications as $qualification) {
                                    echo("<span class='badge badge-primary'>".$qualification."</span> &nbsp;");
                                }
                            } 
                        } else {
                            echo("N/A");
                        }
                        
                    ?>
                </span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-clock"></i> Experience</span>
                <span class="col-md-6">
                    <?php if($teacher->profile->experience != ""): ?>
                        <?php echo e($teacher->profile->experience); ?> 
                    <?php else: ?>
                        N/A
                    <?php endif; ?>
                </span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-shield"></i> Skills</span>
                <span class="col-md-6">
                    <?php
                    if($teacher->profile->skills != "")  {
                        
                        $skills = preg_split("/,/",$teacher->profile->skills);
                        if(count($skills) == 1) {
                            echo("<span class='badge badge-primary'>".$teacher->profile->skills."</span>");
                        }
                        else {
                            foreach($skills as $skill) {
                                echo("<span class='badge badge-primary'>".$skill."</span> &nbsp;");
                            }
                        } 
                    } else {
                        echo("N/A");
                    }
                    
                ?>
                </span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-globe"></i> Professional Courses</span>
                <span class="col-md-6">
                    <?php
                    if($teacher->profile->professional_courses != "")  {
                        
                        $professional_courses = preg_split("/,/",$teacher->profile->professional_courses);
                        if(count($professional_courses) == 1) {
                            echo("<span class='badge badge-primary'>".$teacher->profile->professional_courses."</span>");
                        }
                        else {
                            foreach($professional_courses as $professional_course) {
                                echo("<span class='badge badge-primary'>".$professional_course."</span> &nbsp;");
                            }
                        } 
                    } else {
                        echo("N/A");
                    }
                    
                ?>
                </span>
            </li>
            <li class="list-group-item">
                <center>
                    <a href="<?php echo e(route('teacher.editProfile')); ?>" class="btn btn-primary">Edit Profile</a>
                    <a href="<?php echo e(route('teacher.changePassword')); ?>" class="btn btn-info">Change Password</a>
                </center>
            </li>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
    /*
    var rating = "<?php echo e($teacher->rating); ?>";
    var stars = document.getElementById("rating").children;
    if(rating < 3) {
        for(var i = 0;i<rating;i++) {
            stars[i].style = "color:red";
        }
    } else {
        for(var i = 0;i<rating;i++) {
            stars[i].style = "color:green";
        }
    }
    */
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>