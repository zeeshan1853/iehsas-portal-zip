<html>
    <head>
        <title>Batches List</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

        <script
        src="https://code.jquery.com/jquery-3.4.1.min.js"
        integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
        crossorigin="anonymous"></script>

        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <style>
                @page  { size: auto;  margin: 0mm; }
        </style>
    <body>


    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h2 class="page-header">
                    <?php echo e(Auth::user()->branch->name); ?>

                    <img src="<?php echo e(asset(Auth::user()->branch->setting->logo)); ?>" width="150px" alt="logo" style="margin-left:25%;">
                    <small class="pull-right">Date: <?php echo e(date("d-m-Y")); ?></small>
                </h2>
            </div>
            <center><h1>Batches List</h1></center>
            <!-- /.col -->
        </div>
    
            <table class="table table-responsive table-bordered">
                <thead>
                    <tr class="bg-primary">
                        <td>Sr.No</td>
                        <td>Batch Name</td>
                        <td>Course Name</td>
                        <td>Teacher Name</td>
                        <td>Start Date</td>
                        <td>End Date</td>
                        <td>Share</td>
                        <td>Course Price</td>
                    </tr>
                </thead>
                <tbody class="tbody">
    
                </tbody>
            </table>

    </div>
    </body>
</html>
<script>
    $(document).ready(function(e) {
        var batches = JSON.parse(localStorage.batches);
        var output = "";
        console.log(batches);
        batches.forEach(function(batch) {
            output += "<tr><td>"+batch.sr_no+"</td><td>"+batch.batch_name+"</td><td>"+batch.course_name+"</td><td>"+batch.teacher_name+"</td><td>"+batch.start_date+"</td><td>"+batch.end_date+"</td><td>"+batch.share+"</td><td>"+batch.course_price+"</td></tr>"
        });
        $(".tbody > tr").remove();
        $(".tbody").append(output);
        window.print();
        localStorage.batches = "";
    })
</script>
