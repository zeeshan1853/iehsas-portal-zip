<?php $__env->startSection('header-styles'); ?>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/jquery.bootgrid.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/bootgridcustom.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12 ">
            <div class="card-body">
                <table class="table table-bordered" id="batchesData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no" data-width="8%" title="Sr No">Sr.No</td>
                        <td data-column-id="batch_name" title="Batch Name" title="Batch Name">Batch Name</td>
                        <td data-column-id="course_name" title="Course Name">Course Name</td>
                        <td data-column-id="teacher_name" data-width="10%" title="Teacher Name">Teacher</td>
                        <td data-column-id="start_date" data-width="10%" title="Start Date">Start Date</td>
                        <td data-column-id="end_date" data-width="10%" title="End Date">End</td>
                        <td data-column-id="share" data-width="8%" title="Share Price">Share</td>
                        <td data-column-id="course_price" data-width="10%">Course Price</td>
                        <td data-column-id="actions" data-sortable="false" title="Actions">Actions</td>
                    </tr>
                    </thead>
                    <tfoot>

                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    <div class="modal fade text-left" id="reportModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header bg-cyan">
                <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Batch Assessment Report</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <table class="table table-striped table-bordered">
                        <thead class="thead bg-info text-white">
                            
                        </thead>
                        <tbody class="tbody">
    
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary print">Print</button>
                <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
            </div>
        </div>
    </div>
    <div class="modal fade text-left" id="quizModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header bg-cyan">
                <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Batch Quiz Report</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <table class="table table-striped table-bordered">
                        <thead class="quiz_thead bg-info text-white">
                            
                        </thead>
                        <tbody class="quiz_tbody">
    
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary print_quiz">Print</button>
                <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
            </div>
        </div>
    </div>

    <!-- Random feedback modal -->
    <div class="modal fade text-left" id="feedbackModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-cyan">
                <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Batch Quiz Report</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <table class="table table-striped table-bordered">
                        <thead class="bg-info text-white">
                            <tr>
                                <th>Feedback No</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody class="feedback_tbody">
    
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('js/jquery.bootgrid.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.bootgrid.fa.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sweetalert2.all.min.js')); ?>"></script>
    <script>
        $(document).ready(function(e) {
            var grid = "";
            setTimeout(()=>{
                var body = document.getElementsByTagName('body')[0];
                body.classList.remove('menu-expanded');
                body.classList.add("menu-collapsed");
            },1000);
            $("#batchesData").bootgrid({
                ajax:true,
                caseSensitive:false,
                searchSettings:{
                    delay:1000,
                },
                labels:{
                    loading:"Loading Please Wait   "+ajaxLoader,
                },
                rowCount:[10,20,50,100,-1],
                post:function() {

                },
                responseHandler:function(response) {
                    grid = response;
                    return response;
                },
                url:"<?php echo e(route('batch.batchList')); ?>",
            }).on("loaded.rs.jquery.bootgrid",function() {
                $(".view").on("click",function(e) {
                    var id = $(this).data("id");
                    var route = "<?php echo e(route('student.batch_students',':id')); ?>";
                    route = route.replace(":id",id);
                    window.open(route);
                });
                $(".delete").on("click",function(e) {
                    var id = $(this).data("id");
                    swal({
                        title: 'Are you sure?',
                        text: "It will permanently deleted !",
                        type: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result)=>{
                        if(result.value == true) {
                            var route = "<?php echo e(route('batch.deleteAjax',':id')); ?>";
                            route = route.replace(":id",id);
                            $.ajax({
                                url:route,
                                dataType:'JSON',
                                type:'GET',
                                complete:function(jqXHR,textStatus) {
                                    if(jqXHR.status == 200) {
                                        var result = JSON.parse(jqXHR.responseText);
                                        if(result.hasOwnProperty('success')) {
                                            $("#batchesData").bootgrid("reload");
                                            swal({
                                                type:'success',
                                                text:'Batch Delete Successfully',
                                                title:'Congratulation',
                                            });
                                        } else if(result.hasOwnProperty('error')) {
                                            swal({
                                                type:'error',
                                                text:result.msg,
                                                title:'Opps Something Went Wrong',
                                            });
                                        }
                                    } else {
                                        swal({
                                            type:'error',
                                            title:'Opps Something Went Wrong',
                                            text:'Contact Admin',
                                        });
                                    }
                                }
                            });
                        }
                    })
                });
                $(".edit").on("click",function(e) {
                    var id = $(this).data("id");
                    var route = "<?php echo e(route('batch.edit_batch',':id')); ?>";
                    route = route.replace(":id",id);
                    window.open(route);
                });
                $(".print").on("click",function(e) {
                    var id = $(this).data("id");
                    var route = "<?php echo e(route('batch.getBatchStudents',':id')); ?>";
                    route = route.replace(":id",id);
                    $.ajax({
                        url:route,
                        dataType:'JSON',
                        type:'GET',
                        complete:function(jqXHR,textStatus) {
                            if(jqXHR.status == 200) {
                                var result = JSON.parse(jqXHR.responseText);
                                if(result.hasOwnProperty('success')) {
                                    var students = result.rows;
                                    batchStudents = students;
                                    localStorage.students = JSON.stringify(students);
                                    window.open("<?php echo e(route('batch.printBatchStudents')); ?>");
                                }
                            }
                        }
                    });
                });
                $(".excel").on("click",function(e) {
                    var students = "";
                    var id = $(this).data("id");
                    var name = $(this).data("name");
                    name = name.toLowerCase();
                    name = name.split(" ");
                    var route = "<?php echo e(route('batch.getBatchStudents',':id')); ?>";
                    route = route.replace(":id",id);
                    $.ajax({
                        url:route,
                        dataType:'JSON',
                        type:'GET',
                        async:false,
                        complete:function(jqXHR,textStatus) {
                            if(jqXHR.status == 200) {
                                var result = JSON.parse(jqXHR.responseText);
                                if(result.hasOwnProperty('success')) {
                                    students = result.rows;
                                }
                            }
                        }
                    });
                    if(name.includes("nebosh")) {
                        var output = "<table border='2px'><tr><td>Sr.No</td><td>Nebosh Student ID</td><td>Fresh/Resit</td><td>Units</td><td>Center</td><td>Student Name</td><td>Father Name</td><td>Email</td><td>Student Type</td><td>Gender</td><td>Education</td><td>Contact No</td><td>How You Find Us ?</td><td>DOB</td><td>Address</td><td>Reference By</td><td>Batch Name</td><td>Total Fee</td><td>Received Amount</td><td>Discount</td><td>Remaining Amount</td><td>Enrolment Date</td>";
                            for(var i =0; i<students[0].examDates.length;i++) {
                                var count = i+1;
                                output += "<td>Exam Date "+count+"</td>";
                            }
                            output += "</tr>";
                            
                            students.forEach(function(student) {
                                output += "<tr><td>"+student.sr_no+"</td><td>"+student.nebosh_student_id+"</td><td>"+student.freshResit+"</td><td>"+student.units+"</td><td>"+student.center+"</td><td>"+student.student_name+"</td><td>"+student.father_name+"</td><td>"+student.email+"</td><td>"+student.type+"</td><td>"+student.gender+"</td><td>"+student.education+"</td><td>"+student.contact_no+"</td><td>"+student.find+"</td><td>"+student.dob+"</td><td>"+student.address+"</td><td>"+student.reference+"</td><td>"+student.batch_name+"</td><td>"+student.total_fee+"</td><td>"+student.paid_amount+"</td><td>"+student.discount+"</td><td>"+student.due_amount+"</td><td>"+student.enrolment_date+"</td>";
                                for(var i=0; i<student.examDates.length;i++) {
                                    output += "<td>"+student.examDates[i]+"</td>";
                                }
                                output += "</tr>";
                                
                            });
                            output += "</table>";
                            var postfix = "batch-student-sheet";
                            var a = document.createElement('a');
                            var dataType = "data:application/vnd.ms-excel";
                            a.href = dataType + ',' + encodeURIComponent(output);
                            a.download = postfix + '.xls';
                            a.click();
                    } else {
                        var output = "<table border='2px'><tr><td>Sr.No</td><td>Student Name</td><td>Father Name</td><td>Email</td><td>Student Type</td><td>Gender</td><td>Education</td><td>Contact No</td><td>How You Find Us ?</td><td>DOB</td><td>Address</td><td>Reference By</td><td>Batch Name</td><td>Total Fee</td><td>Received Amount</td><td>Discount</td><td>Remaining Amount</td><td>Enrolment Date</td>";
                            for(var i =0; i<students[0].examDates.length;i++) {
                                var count = i+1;
                                output += "<td>Exam Date "+count+"</td>";
                            }
                            output += "</tr>";

                            students.forEach(function(student) {
                                output += "<tr><td>"+student.sr_no+"</td><td>"+student.student_name+"</td><td>"+student.father_name+"</td><td>"+student.email+"</td><td>"+student.type+"</td><td>"+student.gender+"</td><td>"+student.education+"</td><td>"+student.contact_no+"</td><td>"+student.find+"</td><td>"+student.dob+"</td><td>"+student.address+"</td><td>"+student.reference+"</td><td>"+student.batch_name+"</td><td>"+student.total_fee+"</td><td>"+student.paid_amount+"</td><td>"+student.discount+"</td><td>"+student.due_amount+"</td><td>"+student.enrolment_date+"</td>";
                                for(var i=0; i<student.examDates.length;i++) {
                                    output += "<td>"+student.examDates[i]+"</td>";
                                }
                                output += "</tr>";
                            });
                            output += "</table>"
                            var postfix = "batch-student-sheet";
                            var a = document.createElement('a');
                            var dataType = "data:application/vnd.ms-excel";
                            a.href = dataType + ',' + encodeURIComponent(output);
                            a.download = postfix + '.xls';
                            a.click();
                    }
                    
                });
                $(".notify").on("click",function(e) {
                    var id = $(this).attr("data-id");
                    var route = "<?php echo e(route('batch.result',':id')); ?>";
                    route = route.replace(":id",id);
                    $.ajax({
                        url:route,
                        dataType:'JSON',
                        type:'GET',
                        complete:function(jqXHR,textStatus) {
                            if(jqXHR.status == 200) {
                                var result = JSON.parse(jqXHR.responseText);
                                if(result.hasOwnProperty('success')) {
                                    swal({
                                        type:'success',
                                        text:'Notifcation Send Successfully',
                                        title:'Congrass..',
                                    });
                                }
                            } else {
                                swal({
                                    type:'error',
                                    title:'Opps Something Went Wrong',
                                    text:'Contact Admin '+jqXHR.status,
                                })
                            }
                        }
                    });
                });
                $(".attendance").on("click",function(e) {
                    var batch_id = $(this).data("id");
                    var data = {
                        batch_id:batch_id
                    };
                    $.ajax({
                        url:"<?php echo e(route('attendance.showBatchAttendance')); ?>",
                        data:data,
                        dataType:'JSON',
                        type:'POST',
                        async:false,
                        complete:function(jqXHR,textStatus) {
                            if(jqXHR.status == 200) {
                                var result = JSON.parse(jqXHR.responseText);
                                var days = result.days;
                                var student_attendences = result.results;
                                var table = "<table border='2px'><tr><th>Sr.No</th><th>Student Name</th>";
                                days.forEach(function(day) {
                                    table += "<th>"+day.day_date+"</th>";
                                });
                                table+= "</tr>"
                                var i = 0;
                                student_attendences.forEach(function(attendance) {
                                    i++;
                                    table += "<tr><td>"+i+"</td><td>"+attendance.student_name+"</td>";
                                    delete attendance.student_name;
                                    for(var att in attendance) {
                                        table += "<td>"+attendance[att].status+"</td>";
                                    }
                                    table += "</tr>";
                                });
                                table += "</table>";
                                var postfix = "Btach-Attendence-sheet";
                                var a = document.createElement('a');
                                var dataType = "data:application/vnd.ms-excel";
                                a.href = dataType + ',' + encodeURIComponent(table);
                                a.download = postfix + '.xls';
                                a.click();
                                
                            }
                        }
                    })
                });
                $(".activity").on("click",function(e) {
                    var id = $(this).data("id");
                    var route = "<?php echo e(route('activity.showBatchActivity',':id')); ?>";
                    route = route.replace(":id",id);
                    $.ajax({
                        url:route,
                        dataType:'JSON',
                        type:'GET',
                        async:false,
                        complete:function(jqXHR,textStatus) {
                            if(jqXHR.status == 200) {
                                var result = JSON.parse(jqXHR.responseText);
                                if(result.hasOwnProperty('success')) {
                                    var activities =  result.activities;
                                    var i =0;
                                    var output = "<table border='2px'><tr><th>Date</th><th>Day</th><th>Taught Elements </th><th>Improvement</th><th>Suggestion</th><th>Remarks</th></tr>";
                                    
                                    activities.forEach(function(activity) {
                                        i++;
                                        output += "<tr><td>"+activity.day_date+"</td><td>Day "+i+"</td><td>"+activity.content+"</td><td>"+activity.improvement+"</td><td>"+activity.suggestion+"</td><td>"+activity.remarks+"</td></tr>"
                                    });
                                    output += "</table>";
                                    var postfix = "Btach-Attendence-sheet";
                                    var a = document.createElement('a');
                                    var dataType = "data:application/vnd.ms-excel";
                                    a.href = dataType + ',' + encodeURIComponent(output);
                                    a.download = postfix + '.xls';
                                    a.click();
                                }
                            }
                        }
                    });
                });
                $(".assessment").on("click",function(e) {
                    var id = $(this).attr('data-id');
                    var route = "<?php echo e(route('assessment.showBatchAssessments',':id')); ?>";
                    route = route.replace(":id",id);
                    $.ajax({
                        url:route,
                        dataType:'JSON',
                        type:'GET',
                        complete:function(jqXHR,textStatus) {
                            if(jqXHR.status == 200) {
                                var result = JSON.parse(jqXHR.responseText);
                                if(result.hasOwnProperty('success')) {
                                    var reports = result.reports;
                                    console.log(reports);
                                    localStorage.reports = JSON.stringify(reports);
                                    var thead,tbody = "";
                                    var i = 0;
                                    var obtain_marks = 0;
                                    var percentage = 0;
                                    var total_marks = 0;
                                    var j = 0;
                                    var k = 0;
                                    thead += "<tr><th>Sr. No</th><th>Sudent Name</th>";
                                    var test = reports[0].length;
                                    while(k < test ) {
                                        k++
                                        thead += "<th>Test # "+k+"</th>";
                                    }
                                    reports.forEach((report)=>{
                                        var total = 0;
                                        i++;
                                        tbody += "<tr>";
                                        report.forEach(function(rep){
                                            if(j == 0) {
                                                tbody += "<td>"+i+"</td><td>"+rep.student_name+"</td><td>"+rep.obtain_marks+"</td>";
                                                rep.obtain_marks != "N/A" ? obtain_marks += rep.obtain_marks : obtain_marks += 0;
                                                total_marks += rep.total_marks;
                                                j++;
                                            } else {
                                                tbody += "<td>"+rep.obtain_marks+"</td>";
                                                rep.obtain_marks != "N/A" ? obtain_marks += rep.obtain_marks : obtain_marks += 0;
                                                total_marks += rep.total_marks;
                                            }
                                        });
                                        percentage = ((obtain_marks / total_marks) * 100).toFixed(3);
                                        tbody += "<td>"+obtain_marks+"</td>";
                                        tbody += "<td>"+percentage+"</td>";
                                        tbody += "</tr>";
                                        obtain_marks = 0;
                                        j = 0;
                                        

                                    });
                                    thead += "<th>Total Marks</th>";
                                    thead += "<th>Total (%)</th>";
                                    thead += "</tr>";
                                    $(".thead > tr").remove();
                                    $(".tbody > tr").remove();
                                    $(".thead").append(thead);
                                    $(".tbody").append(tbody);
                                    $("#reportModal").modal();
                                } else if(result.hasOwnProperty('error') ) {
                                    output = "<tr><td colspan='4' class='text-center'>No Assessment Found</td></tr>";
                                    $(".thead > option ").remove();
                                    $(".thead").append(output);
                                    $("#reportModal").modal();
                                }
                                
                            }
                        }
                    });
                });
                $(".quiz").on("click",function(e) {
                    var id = $(this).data("id");
                    var route = "<?php echo e(route('quiz.showBatchQuizzes',':id')); ?>";
                    route = route.replace(":id",id);
                    $.ajax({
                        url:route,
                        dataType:'JSON',
                        type:'GET',
                        complete:function(jqXHR,textStatus) {
                            if(jqXHR.status == 200) {
                                var result = JSON.parse(jqXHR.responseText);
                                if(result.hasOwnProperty('success')) {
                                    localStorage.quizzes = JSON.stringify(result.results);
                                    var totalQuiz = result.results.total_quiz;
                                    var tbody = "";
                                    var totalObtain = 0;
                                    var total = 0;
                                    var thead = "<tr><th>Sr.No</th><th>Student Name</th>";
                                    for(var i = 1;i<=2;i++) {
                                        thead += "<th>Test # "+i+"</th>";
                                    }
                                    thead += "<th>Total</th>"
                                    thead += "<th>Total (%)</th>";
                                    thead += "</tr>";
                                    delete result.results.total_quiz;
                                    var results = result.results;
                                    var i = 0;
                                    for(var res in results) {
                                        i++;
                                        tbody += "<tr><td>"+i+"</td><td>"+results[res].student_name+"</td>";
                                        delete results[res].student_name;
                                        
                                        var quizResult = results[res];
                                        for(var r in quizResult) {
                                            tbody += "<td>"+quizResult[r].obtain_marks+"</td>";
                                            totalObtain += quizResult[r].obtain_marks == "N/A" ? 0 : parseInt(quizResult[r].obtain_marks);
                                            total += quizResult[r].total_marks == "N/A" ? 0 : parseInt(quizResult[r].total_marks);
                                        }
                                        tbody += "<td>"+totalObtain+"</td>";
                                        var percentage = ((parseInt(totalObtain) / parseInt(total)) * 100).toFixed(2);
                                        tbody += "<td>"+percentage+"</td>";
                                        tbody += "</tr>";
                                    }
                                    $(".quiz_thead > tr").remove();
                                    $(".quiz_tbody > tr").remove();
                                    $(".quiz_thead").append(thead);
                                    $(".quiz_tbody").append(tbody);
                                    $("#quizModal").modal();
                                } else if(result.hasOwnProperty('error')) {
                                    console.log(result.msg);
                                }
                            }
                        }
                    });
                });
                $(".random").on("click",function(e) {
                    e.preventDefault();
                    var id = $(this).data("id");
                    var data = {
                        id:id,
                    };
                    $.ajax({
                        url:"<?php echo e(route('batchRandomFeedback.store')); ?>",
                        data:data,
                        dataType:'JSON',
                        type:'POST',
                        complete:function(jqXHR,textStatus) {
                            if(jqXHR.status == 200) {
                                var result = JSON.parse(jqXHR.responseText);
                                if(result.hasOwnProperty('success')) {
                                    toastr.success(result.success);
                                }   
                            } else {
                                toastr.error("Contact Admin"+jqXHR.status);
                            }
                        }
                    });
                });
                $(".feedback_list").on("click",function(e) {
                    e.preventDefault();
                    var id = $(this).data("id");
                    var route = "<?php echo e(route('batchRandomFeedback.show',':id')); ?>";
                    route = route.replace(":id",id);
                    $.ajax({
                        url:route,
                        dataType:'JSON',
                        type:'GET',
                        complete:function(jqXHR,textStatus) {
                            if(jqXHR.status == 200) {
                                var result = JSON.parse(jqXHR.responseText);
                                if(result.hasOwnProperty('success')) {
                                    var feedbacks = result.feedbacks;
                                    var output = "";
                                    var i=0;
                                    feedbacks.forEach(function(feedback) {
                                        i++;
                                        var route = "<?php echo e(route('studentRandomFeedback.index',':id')); ?>";
                                        route = route.replace(":id",feedback.id);
                                        output += "<tr><td>"+i+"</td><td><a href='"+route+"' title='Check Feedback List'><i class='ft-eye'></i></a></td></tr>";
                                    });
                                    $(".feedback_tbody > tr").remove();
                                    $(".feedback_tbody").append(output);
                                    $("#feedbackModal").modal();
                                }
                            }
                        }
                    }); 
                });
            });
            $("#batchesData-header").find('.actionBar').prepend('<button style="margin-left:10px;" id="btnExcel" class="btn btn-primary pull-left btnExcel" type="button"> <span class="icon glyphicon glyphicon-export"></span> Excel </button>');
            $("#batchesData-header").find('.actionBar').prepend('<button id="btnPrint" class="btn btn-info pull-left btnPrint" type="button"> <span class="icon glyphicon glyphicon-print"></span> Print </button>');
            $("#btnExcel").click(function(e) {
                if(grid.rows.length == 0) {
                    toastr.error("No Batch Found");
                    return;
                }
                var batches = grid.rows;
                var table = "<table border='2px'><tr><td>Sr.No</td><td>Batch Name</td><td>Course Name</td><td>Teacher Name</td><td>Start Date</td><td>End Date</td><td>Share Price</td><td>Course Price</td></tr>"; 
                batches.forEach(function(batch) {
                    table += "<tr><td>"+batch.sr_no+"</td><td>"+batch.batch_name+"</td><td>"+batch.course_name+"</td><td>"+batch.teacher_name+"</td><td>"+batch.start_date+"</td><td>"+batch.end_date+"</td><td>"+batch.share+"</td><td>"+batch.course_price+"</td></tr>";
                });
                table += "</table>";
                var postfix = "batches-sheet";
                var a = document.createElement('a');
                var dataType = "data:application/vnd.ms-excel";
                a.href = dataType + ',' + encodeURIComponent(table);
                a.download = postfix + '.xls';
                a.click();
            });
            $("#btnPrint").click(function(e) {
                if(grid.rows.length == 0) {
                    toastr.error("No Batch Found");
                    return;
                }
                localStorage.batches = JSON.stringify(grid.rows);
                window.open("<?php echo e(route('batch.print')); ?>");
            });
            $(".print").on("click",function(e) {
                window.open("<?php echo e(route('studentAssessment.print',"_blank")); ?>");
            });
            $(".print_quiz").on("click",(e) =>{
                window.open("<?php echo e(route('quizResult.print')); ?>","_blank");
            });
        });
        
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>