<!DOCTYPE html>
<!--
This Code is written 
and Copyright by TechCodex
www.techcodex.net
-->
<html class="loading" lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="keywords" content="techcodex, college mangement system, cms, school mangement system,">
    <meta name="description" content="College Mangement System by TechCodex">
    <title><?php echo e($page_title); ?> | <?php echo e(config('app.name')); ?></title>
    <link rel="icon" href="<?php echo e(asset('images/ico/favicon.png')); ?>">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('student-portal/app/css/vendors.min.css')); ?>">
    <!-- END VENDOR CSS-->
    <!-- BEGIN ROBUST CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('student-portal/app/css/app.min.css')); ?>">
    <!-- END ROBUST CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('student-portal/app/css/core/menu/menu-types/vertical-menu.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('student-portal/app/fonts/meteocons/style.min.css')); ?>">
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('student-portal/app/custom-css/style.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/toastr.min.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
    <style>
        @media (min-width: 1025px) {
            .brand-logo{
                width:120px !important;
                margin-left:30%;
            }
        }
        @media (min-width: 320px) {
            .brand-logo{
                width:120px !important;
            }
        }
        body{
            font-size: 15px !important;
            font-family: 'Poppins', sans-serif;
        }
    </style>
    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body class="vertical-layout vertical-menu 2-columns   menu-expanded fixed-navbar" data-open="click" data-menu="vertical-menu" data-col="2-columns">

    <?php echo $__env->make('teacher_partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('teacher_partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="app-content content">
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="content-header-title mb-0 d-inline-block">Teacher Dashboard | <?php echo e($page_heading); ?></h3>
                    </div>
                </div>
                <hr>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
    <?php echo $__env->make('teacher_partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- BEGIN VENDOR JS-->
    <script src="<?php echo e(asset('student-portal/app/vendors/js/vendors.min.js')); ?>"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN ROBUST JS-->
    <script src="<?php echo e(asset('student-portal/app/js/core/app-menu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('student-portal/app/js/core/app.min.js')); ?>"></script>
    <!-- END ROBUST JS-->

    <script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        var loader = "<img src='<?php echo e(asset('app/images/loading.gif')); ?>' alt='loading' width='200'>";
    </script>
    <script>
        toastr.options.closeButton = true;
        toastr.options.preventDuplicates = true;
        toastr.options.progressBar = true;
        
        <?php if(Session::has('success')): ?>
        toastr.success("<?php echo e(Session::get('success')); ?>");
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
        toastr.error("<?php echo e(Session::get('error')); ?>");
        <?php endif; ?>

        <?php if(Session::has('info')): ?>
        toastr.info("<?php echo e(Session::get('info')); ?>");
        <?php endif; ?>
        <?php if($errors->any()): ?>
            toastr.error("Check Errors");
        <?php endif; ?>

        <?php if(Session::has('info')): ?>
        toastr.info("<?php echo e(Session::get('info')); ?>");
        <?php endif; ?>

        var navLink = document.getElementById('autoCol');
        navLink.addEventListener("click",function(e) {
            if(navLink.classList.contains("is-active")) {
                document.getElementsByClassName("brand-logo")[0].style="width:40px !important;margin-left:0px !important;";
            } else {
                document.getElementsByClassName("brand-logo")[0].style="width:120px !important;margin-left:30% !important;";
            }
        });
     </script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>