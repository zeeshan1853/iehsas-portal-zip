<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(url('public/vendors/css/tables/datatable/datatables.min.css')); ?>" rel="stylesheet" type="text/css">
    <style>

    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="studentsData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Name</td>
                        <td data-column-id="father_name">Father Name</td>
                        <td data-column-id="contact_no">Contact No</td>
                        <td data-column-id="admission_date">Admission Date</td>
                        <td data-column-id="paid_amount">Paid</td>
                        <td data-column-id="due_amount">Due</td>
                        <td data-column-id="course">Course</td>
                        <td data-column-id="delete" data-sortable="false">Detail</td>
                        <td data-column-id="edit" data-sortable="false">Edit</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><a href="<?php echo e(route('student.student_instalments',['id'=>$student->id])); ?>"><?php echo e($student->student_name); ?></a> </td>
                            <td><?php echo e($student->father_name); ?></td>
                            <td><?php echo e($student->contact_no); ?></td>
                            <td><?php echo e($student->admission_date); ?></td>
                            <td><?php echo e($student->paid_amount); ?></td>
                            <td><?php echo e($student->due_amount); ?></td>
                            <td><?php echo e($student->course->course_name); ?></td>
                            <td><a href="#" class="view" style="color:green;" data-id="<?php echo e($student->id); ?>"><i class="ft-eye"></i></a> </td>
                            <td><a href="" class=""><i class="ft-file"></i></a> </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal for student Data--->
    <div class="modal" tabindex="-1" role="dialog" id="myModal">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content ">
                <div class="modal-header">
                    <center><h3 class="modal-title">Student Details</h3></center>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <a href="" class="linkStudentImage"><img src="" class="rounded-circle offset-md-4 studentImage" width="100" height="200"></a>
                    <hr>
                    <div>
                        <h4 class="pull-left offset-md-2">Email</h4>
                        <p class="offset-md-6"><b class="email"></b></p>
                    </div>
                    <div class="clearfix"></div>
                    <hr>
                    <div>
                        <h4 class="pull-left offset-md-2">Date Of Birth</h4>
                        <p class="offset-md-6"><b class="dateOfBirth"></b> </p>
                    </div>
                    <div class="clearfix"></div>
                    <hr>
                    <div>
                        <h4 class="pull-left offset-md-2">Education</h4>
                        <p class="offset-md-6"><b class="education"></b> </p>
                    </div>
                    <div class="clearfix"></div>
                    <hr>
                    <div>
                        <h4 class="pull-left offset-md-2">How he find Us ?</h4>
                        <p class="offset-md-6"><b class="find"></b> </p>
                    </div>
                    <div class="clearfix"></div>
                    <hr>

                    <div>
                        <hr>
                        <h4 class="pull-left offset-md-2">ID Card</h4>
                        <img src="" alt="idCard" class="idCard1 pull-left offset-md-1 img-thumbnail">
                        <img src="" alt="idCard" class="idCard2 pull-left offset-md-1 img-thumbnail">
                    </div>
                    <div class="clearfix"></div>
                    <hr>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(url('public/vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/js/scripts/tables/datatables/datatable-styling.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/js/scripts/tables/datatables/datatable-basic.min.js')); ?>"></script>
    <script>
        $(document).ready(function(e) {
            $("#studentsData").DataTable();
            $(".view").click(function (e) {
                e.preventDefault();
                var id = $(this).attr('data-id');
                var data = {
                    id:id,
                };
                $.ajax({
                    url:"<?php echo e(route('student.show')); ?>",
                    data:data,
                    dataType:'JSON',
                    type:'POST',
                    complete:function (jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var student = result.student;

                                var src = '<?php echo e(asset("/")); ?>'+student.student_image;
                                var idCardSrc = "<?php echo e(asset('/')); ?>"+student.id_card_front;
                                var idCardSrc2 = "<?php echo e(asset('/')); ?>"+student.id_card_back;
                                $(".studentImage").attr('src',src);
                                $(".linkStudentImage").attr('href',src);

                                $(".idCard1").attr('src',idCardSrc);
                                $(".idCard2").attr('src',idCardSrc2);

                                $(".email").html(student.email);
                                $(".dateOfBirth").html(student.date_of_birth);
                                $(".education").html(result.education);
                                $(".find").html(student.find);
                            }
                        }
                    }
                });
                $("#myModal").modal();
            })
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>