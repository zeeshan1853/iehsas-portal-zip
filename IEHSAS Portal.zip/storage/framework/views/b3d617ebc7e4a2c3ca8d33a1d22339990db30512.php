

<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(asset('vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">
    <style>
        table{
            font-size: 15px;
            font-weight: bold;
        }
        #studentInstalmentModal .modal-body{
            height: 600px;
            overflow-y: auto;
        }
        table::-webkit-scrollbar{
            width:0.7em;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('challan.instalment')); ?>" id="instalmentChallanForm">
                    <?php echo csrf_field(); ?>
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                        <div class="row">
                            <div class="col-md-12 offset-md-0">
                                <div class="form-group row">
                                    <label class="col-md-1 label-control" for="userinput1">Search Student</label>
                                    <div class="col-md-10">
                                        <div class="input-group">
                                            <select class="form-control <?php echo e($errors->has('student_id') ? 'is-invalid' : ''); ?> select2" id="student_id" name="student_id">
                                                <option value="">--Select Student--</option>
                                            </select>
                                            <span class="input-group-append">
                                                <a href="" title="Check Student History" id="history">
                                                    <span class="input-group-text">
                                                        <i class="ft-file" style="color:blue;"></i>
                                                    </span>
                                                </a>
                                            </span>
                                        </div>
                                    </div>
                                    <span class="offset-md-2 text-danger student_id has-error">
                                    </span>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Amount</label>
                                    <div class="col-md-9">
                                        <div class="input-group">
                                            <input type="number" min="0" class="form-control <?php echo e($errors->has('amount') ? 'is-invalid' : ''); ?>" placeholder="Enter Amount" name="amount" id="amount">
                                        </div>
                                    </div>
                                    <span class="offset-md-4 text-danger amount has-error">
                                        <?php echo e($errors->first('amount')); ?>

                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Particular</label>
                                    <div class="col-md-9">
                                        <div class="input-group">
                                            <textarea id="particular" class="form-control <?php echo e($errors->has('particular') ? 'is-invalid' : ''); ?>" name="particular" rows="5" ></textarea>
                                        </div>
                                    </div>
                                    <span class="offset-md-4 text-danger particular has-error">
                                        <?php echo e($errors->first('particular')); ?>

                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-actions ">
                        <input type="submit" value="Print Challan Form" id="btnAdd" class="btn btn-primary offset-md-4">
                        <a href="<?php echo e(route('challan.empty')); ?>" class="btn btn-info" target="_blank">Print Empty Challan</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Student Instalment Modal --->
    <div class="modal" tabindex="-1" role="dialog" id="studentInstalmentModal">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content ">
                    <div class="modal-header">
                        <center><h3 class="modal-title">Student History</h3></center>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <h3><b>Student Instalment History</b></h3>
                        <table class="table table-bordered text-center">
                            <tr class="bg-info text-white">
                                <th>Course / Batch</th>
                                <th>Sr.No</th>
                                <th>Paid Amount</th>
                                <th>Payment Type</th>
                                <th>Date</th>
                                <th>Total Fee / Discount / Paid Amount / Due Amount</th>
                            </tr>
                            <tbody class="tbody">
                            </tbody>
                            <tfoot class="bg-cyan text-white text-bold-700">
                                <td colspan="2" class="text-center">Total</td>
                                <td class="total"></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tfoot>
                        </table>
                        <hr style="border:1px solid grey; width:70%;">
                        <h3><b>Hostel Fee Histroy</b></h3>
                        <table class="table table-bordered text-center">
                            <thead class="bg-info text-white">
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Paid Amount</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody class="hotel_body">
                            </tbody>
                            <tfoot class="bg-cyan text-white">
                                <tr>
                                    <td><b>Total:</b></td>
                                    <td class="hostel_total"></td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script>
        $(document).ready(function(e) {
            setTimeout(()=>{
                var body = document.getElementsByTagName('body')[0];
                body.classList.remove('menu-expanded');
                body.classList.add("menu-collapsed");
            },1000);
            $("#student_id").select2({
                minimumInputLength:5,
                placeholder:'Search Student...',
                ajax:{
                    url:'<?php echo e(route("student.batch_student_ajax")); ?>',
                    dataType:'JSON',
                    type:'POST',
                    delay:1000,
                    data:function(term) {
                        return{
                            term:term,
                        }
                    },
                    processResults:function(data) {
                        return{
                            results: $.map(data, function(item) {
                                return {
                                    text:item.student_name+" "+item.father_name+" "+item.contact_no,
                                    id:item.id,
                                    slug:item.hostel_fee,
                                }
                            })
                        }
                    }
                }
            });
            $("#history").click(function(e) {
                e.preventDefault();
                var id = $("#student_id").val();
                if(id == "") {
                    toastr.error("Please Select Student First");
                    return;
                }
                var route = '<?php echo e(route("instalment.studentHistory",":id")); ?>';
                route = route.replace(":id",id);
                $.ajax({
                    url:route,
                    dataType:'JSON',
                    type:'GET',
                    async:false,
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var batches = result.batches;
                                var total_paid = 0;
                                var output = "";
                                var batch_name = "";
                                var hostelOuput = "";
                                var hostel_total = 0;
                                //student batches
                                if(batches == "") {
                                    output += "<tr><td colspan='6'>No Result Found</td></tr>";
                                } else {
                                    batches.forEach(function(batch_instalments) {
                                        var i = 0;
                                        var batch_name = batch_instalments[0].batch_name;
                                        var total_batch_paid = getDueAmount(batch_instalments);
                                        //student batch instalments
                                        batch_instalments.forEach(function(instalment) {
                                            if(instalment.fresh_resit == 0 || instalment.fresh_resit == '' || instalment.fresh_resit == null) {
                                                i++;
                                                var due = parseInt(instalment.total_fee) - parseInt(instalment.discount) - parseInt(total_batch_paid);
                                                if(due == 0) {
                                                    output += "<tr class='text-white' style='background-color:green;'>";
                                                } else {
                                                    output += "<tr class='text-white' style='background-color:red;'>";
                                                }
                                                if(i == 1) {
                                                    output += "<td rowspan='"+batch_instalments.length+"' class='text-center ' style='vertical-align: middle;'> "+instalment.course_name+" / "+instalment.batch_name+"</td>";
                                                }
                                                output += "<td>"+i+"</td><td>"+instalment.paid_amount+"</td><td>"+instalment.payment+"</td><td>"+instalment.date+"</td>";
                                                if(i  == 1) {
                                                    output += "<td rowspan='"+batch_instalments.length+"' class='text-center ' style='vertical-align: middle;'> "+instalment.total_fee+" / "+instalment.discount+" / "+total_batch_paid+" / "+due+"</td>";
                                                }
                                                output += "</tr>";
                                            } else {
                                                i++;
                                                output += "<tr class='text-white' style='background-color:#9073DB;'>";

                                                if(i == 1) {
                                                    output += "<td rowspan='"+batch_instalments.length+"' class='text-center ' style='vertical-align: middle;'> "+instalment.course_name+" / "+instalment.batch_name+"</td>";
                                                }
                                                output += "<td>"+i+"</td><td>"+instalment.paid_amount+"</td><td>"+instalment.payment+"</td><td>"+instalment.date+"</td>";
                                                if(i  == 1) {
                                                    output += "<td rowspan='"+batch_instalments.length+"' class='text-center ' style='vertical-align: middle;'>"+instalment.discount+" / "+total_batch_paid+"</td>";
                                                }
                                                output += "</tr>";
                                                
                                            }
                                            
                                            total_paid += instalment.paid_amount;
                                        });
                                        output+= "<tr><td colspan='6'></td></tr>";
                                    });
                                }
                                var hostelRecoveries = result.hostel_recoveries;
                                i = 0;
                                if(hostelRecoveries.length == 0) {
                                    hostelOuput += "<tr><td colspan='3'>No Result Found</td></tr>";
                                } else {
                                    hostelRecoveries.forEach(function(recovery) {
                                        i++;
                                        hostel_total += parseInt(recovery.amount);
                                        hostelOuput += "<tr><td>"+i+"</td><td>"+recovery.amount+"</td><td>"+recovery.date+"</td></tr>"
                                    });
                                }
                                $(".hotel_body > tr").remove();
                                $(".hotel_body").append(hostelOuput);
                                $(".hostel_total").html(hostel_total);

                                $(".tbody > tr").remove();
                                $(".tbody").append(output);
                                $(".total").html(total_paid);

                                $("#studentInstalmentModal").modal();
                                
                            }
                        }
                    } 
                });
            });
            $("#btnAdd").click(function(e) {
                e.preventDefault();
                $(".has-error").html("");
                var data = $("#instalmentChallanForm").serializeArray();
                $.ajax({
                    url:"<?php echo e(route('challan.instalment')); ?>",
                    dataType:'JSON',
                    type:'POST',
                    data:data,
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result  = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                localStorage.challanFormData = JSON.stringify(result);
                                window.open("<?php echo e(route('challan.print')); ?>");
                                $("#student_id").select2("val"," ");
                                $("#amount").val("");
                                $("#particular").val("");
                            }
                        } else if(jqXHR.status == 422) {
                            var result = JSON.parse(jqXHR.responseText);
                            var errors = result.errors;
                            for(error in errors){
                                $("."+error).html(errors[error]);
                            }
                        }
                    }
                });
            });
        });
        function getDueAmount(batch_instalments) {
            var total_paid = 0;
            batch_instalments.forEach(function(instalment) {
                total_paid += parseInt(instalment.paid_amount);
            }); 
            return total_paid;
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>