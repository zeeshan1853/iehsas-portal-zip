<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="card col-md-12">
        <div class="card-body">
            <table class="table table-striped text-center">
                <thead>
                    <tr class="bg-primary text-white" >
                        <th>Sr.No</th>
                        <th>Assessment No</th>
                        <th>Total marks</th>
                        <th>Obatain Marks</th>
                        <th>Remarks / Improvements</th>
                        <th>Percentage</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $i = 1; 
                    $percentage = 0; 
                    $total_marks = 0;
                    $total_obtain = 0;
                    ?>
                    <?php if(count($reports) == 0): ?>
                        <tr>
                            <td colspan="5">No Result Found</td>
                        </tr>
                    <?php else: ?>
                        <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td>Test <?php echo e($i++); ?></td>
                            <?php if($report != null): ?> 
                                <td> <?php echo e($report->batchAssessment->total_marks); ?> </td>
                            <?php else: ?>
                                <td>N/A</td>
                            <?php endif; ?>
                            <td><?php echo e($report != null ? $report->obtain_marks : "N/A"); ?></td>
                            <td><?php echo e($report->remarks == "" ? "N/A" : $report->remarks); ?></td>
                            <?php if($report != null): ?>
                                <td>
                                    <?php echo e(( $report->obtain_marks / $report->batchAssessment->total_marks) * 100); ?> 
                                </td>
                            <?php else: ?>
                                <td>N/A</td>
                            <?php endif; ?>
                            </tr>
                            <?php
                                $report != null ? $total_marks += $report->batchAssessment->total_marks : 0;
                                $report != null ? $total_obtain += $report->obtain_marks : 0;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                </tbody>
                <tfoot >
                    <tr class="bg-info text-white">
                        <td class="text-bold-600">Total</td>
                        <td></td>
                        <td class="text-bold-600"><?php echo e($total_marks); ?></td>
                        <td class="text-bold-600"><?php echo e($total_obtain); ?></td>
                        <td></td>
                        <?php if($total_marks != 0  && $total_obtain != 0): ?>
                        <td class="text-bold-600"><?php echo e(round((($total_obtain / $total_marks) * 100),2)); ?></td>
                        <?php else: ?>
                        <td>0</td>
                        <?php endif; ?>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_student', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>