<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(asset('vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/jasny-bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <style>
        .idCard img {
            margin-top:10px;
            margin-left: 5px;
            border:1px solid #9ea5b0;
            animation: fadein 3;
            -moz-animation: fadein 2s; /* Firefox */
            -webkit-animation: fadein 2s; /* Safari and Chrome */
            -o-animation: fadein 2s; /* Opera */
        }
        .idCard img:first-of-type {
            margin-left: 0px;
        }
        @keyframes  fadein {
            from {
                opacity:0;
            }
            to {
                opacity:1;
            }
        }
        @-moz-keyframes fadein { /* Firefox */
            from {
                opacity:0;
            }
            to {
                opacity:1;
            }
        }
        @-webkit-keyframes fadein { /* Safari and Chrome */
            from {
                opacity:0;
            }
            to {
                opacity:1;
            }
        }
        @-o-keyframes fadein { /* Opera */
            from {
                opacity:0;
            }
            to {
                opacity: 1;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('student.update',['id'=>$student->id])); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Student Name</label>
                                    <div class="col-md-9">
                                    <input type="text" id="student_name" autofocus <?php if(old('student_name')): ?> value="<?php echo e(old('student_name')); ?>" <?php else: ?> value="<?php echo e($student->student_name); ?>" <?php endif; ?> class="form-control <?php echo e($errors->has('student_name') ? 'border-danger' : ''); ?>" placeholder="Student Name" name="student_name">
                                    </div>
                                    <span class="offset-md-4 text-danger"></span>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Father Name</label>
                                    <div class="col-md-9">
                                    <input type="text" id="father_name" <?php if(old('father_name')): ?> value="<?php echo e(old('father_name')); ?>" <?php else: ?> value="<?php echo e($student->father_name); ?>" <?php endif; ?> class="form-control <?php echo e($errors->has('father_name') ? 'border-danger' : ''); ?>" placeholder="Father Name" name="father_name">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Contact No</label>
                                    <div class="col-md-9">
                                        <input type="text" id="contact_no" <?php if(old('contact_no')): ?> value="<?php echo e(old('contact_no')); ?>" <?php else: ?> value="<?php echo e($student->contact_no); ?>" <?php endif; ?> class="form-control  <?php echo e($errors->has('contact_no') ? 'border-danger' : ''); ?>" placeholder="Contact No" name="contact_no">
                                        <?php if($errors->has('contact_no')): ?>
                                            <span class="text-danger "><?php echo e($errors->first('contact_no')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Emergency Contact</label>
                                    <div class="col-md-9">
                                    <input type="text" name="emergency" <?php if(old('emergency')): ?> value="<?php echo e(old('emergency')); ?>" <?php else: ?> value="<?php echo e($student->emergency); ?>" <?php endif; ?> placeholder="Emergency Contact No" class="form-control">
                                        <?php if($errors->has('emergency')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('emergency')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Paid Amount</label>
                                    <div class="col-md-9">
                                    <input type="number" id="paid_amount" placeholder="Paid Amount" <?php if(old('paid_amount')): ?> value="<?php echo e(old('paid_amount')); ?>" <?php else: ?> value="<?php echo e($student->paid_amount); ?>" <?php endif; ?> class="form-control <?php echo e($errors->has('paid_amount') ? 'border-danger' : ''); ?>"  name="paid_amount">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Due Amount</label>
                                    <div class="col-md-9">
                                        <input type="number" id="dueAmount" <?php if(old('due_amount')): ?> value="<?php echo e(old('due_amount')); ?>" <?php else: ?> value="<?php echo e($student->due_amount); ?>" <?php endif; ?> class="form-control date <?php echo e($errors->has('due_amount') ? 'border-danger' : ''); ?>"  name="due_amount">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Email</label>
                                    <div class="col-md-9">
                                        <input type="email" id="email" placeholder="Enter Student Email" <?php if(old('email')): ?> value="<?php echo e(old('email')); ?>" <?php else: ?> value="<?php echo e($student->email); ?>" <?php endif; ?> class="form-control <?php echo e($errors->has('email') ? 'border-danger' : ''); ?>"  name="email">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Date Of Birth</label>
                                    <div class="col-md-9">
                                        <input type="date" id="dateOfBirth" <?php if(old('date_of_birth')): ?> value="<?php echo e(old('date_of_birth')); ?>" <?php else: ?> value="<?php echo e($student->date_of_birth); ?>" <?php endif; ?> class="form-control date <?php echo e($errors->has('date_of_birth') ? 'border-danger' : ''); ?>"  name="date_of_birth">
                                    </div>
                                    <span class="text-danger offset-md-4"></span>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Education</label>
                                    <div class="col-md-9">
                                        <select class="form-control select2" name="education_id">
                                            <option value="">--Select Education--</option>
                                            <?php $__currentLoopData = $degress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($student->education_id == $degree->id): ?>
                                                <option value="<?php echo e($degree->id); ?>" selected><?php echo e($degree->name); ?></option>
                                                <?php else: ?> 
                                                <option value="<?php echo e($degree->id); ?>"><?php echo e($degree->name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('education_id')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('education_id')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">How you Find Us. ?</label>
                                    <div class="col-md-9">
                                    <textarea class="form-control" name="find" cols="10" placeholder="How Student Find Us"><?php echo e($student->find); ?></textarea>
                                        <?php if($errors->has('find')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('find')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Address</label>
                                    <div class="col-md-9">
                                    <textarea class="form-control" name="address" cols="10" placeholder="Student Address"><?php echo e($student->address); ?></textarea>
                                    </div>
                                    <?php if($errors->has('address')): ?>
                                        <span class="text-danger offset-md-4"><?php echo e($errors->first('address')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">ID Card No</label>
                                    <div class="col-md-9">
                                        <input type="number" name="id_card"  <?php if(old('id_card')): ?> value="<?php echo e(old('id_card')); ?>" <?php else: ?> value="<?php echo e($student->id_card); ?>" <?php endif; ?> placeholder="ID Card No" class="form-control">
                                        <?php if($errors->has('id_card')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('id_card')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            

                        </div>
                        <div class="row">
                            
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Gender</label>
                                    <div class="col-md-9">
                                        
                                        <label>Male &nbsp;&nbsp;<input type="radio" name="gender[]" value="male" <?php if($student->gender == "male"): ?> checked <?php endif; ?>></label>&nbsp;&nbsp;
                                        
                                        <label>Female &nbsp;&nbsp;<input type="radio" name="gender[]" value="female"<?php if($student->gender == "female"): ?> checked <?php endif; ?>> </label>
                                        <?php if($errors->has('gender')): ?>
                                            <div class="text-danger"><?php echo e($errors->first('gender')); ?></div>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Student Image</label>
                                    <div class="col-md-9">
                                        <!-- Student Image-->
                                        <div class="form-group">
                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                <div class="fileinput-preview img-thumbnail" data-trigger="fileinput" style="width: 300px; height: 200px;">
                                                    <!-- Demo Image -->
                                                    <img src="<?php echo e(asset($student->student_image)); ?>" alt="img">
                                                </div>
                                                <div>
                                            <span class="btn btn-outline-secondary btn-file">
                                              <span class="fileinput-new">Select image</span>
                                              <span class="fileinput-exists">Change</span>
                                              <input type="file" name="student_image">
                                            </span>
                                                    <a href="#" class="btn btn-outline-secondary fileinput-exists" data-dismiss="fileinput">Remove</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if($errors->has('student_image')): ?>
                                        <span class="text-danger offset-md-3"><?php echo e($errors->first('student_image')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row idCard">
                                    <label class="col-md-3 label-control" for="userinput3">ID Card Image:</label>
                                    <div class="col-md-9">
                                        <input type="file" multiple id="images" class="form-control idCardImage <?php echo e($errors->has('idCardImage') ? 'border-danger' : ''); ?>"  name="idCardImage[]">
                                        <div class="images">
                                            <img src="<?php echo e(asset($student->id_card_front)); ?>" style="heigth:100px; width:190px;" alt="id card front">
                                            <img src="<?php echo e(asset($student->id_card_back)); ?>" style="heigth:100px; width:190px;" alt="id card back">
                                        </div>
                                    </div>
                                    <?php if($errors->has('idCardImage')): ?>
                                    <span class="text-danger offset-md-4">
                                        <?php echo e($errors->first('idCardImage')); ?>

                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Update Student" id="btnAdd" class="btn btn-primary">
                        
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('js/jasny-bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script>
        var dueAmount = 0;
        $(document).ready(function (e) {
            $('.select2').select2();
            /*
            var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month + 1;
            if(month < 10) {
                month =  "0" +month;
            }
            if(fullDate < 10)
                fullDate = '0' + fullDate;


            $(".date").val(date.getFullYear() + "-" + month + "-" + fullDate);
            */
        });
        $("#batch_id").change(function (e) {
            dueAmount = $('option:selected',this).data('amount');
            $("#dueAmount").val(dueAmount);
        });
        function previewImages() {

            var $preview = $('.images').empty();
            if (this.files) $.each(this.files, readAndPreview);

            function readAndPreview(i, file) {

                if (!/\.(jpe?g|png|gif)$/i.test(file.name)){
                    return alert(file.name +" is not an image");
                } // else...

                var reader = new FileReader();

                $(reader).on("load", function() {
                    $preview.append($("<img/>", {src:this.result, height:100}));
                });

                reader.readAsDataURL(file);

            }

        }
        $('#images').on("change", previewImages);
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>