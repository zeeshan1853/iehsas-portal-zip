<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6 offset-md-3">
        <div class="card">
            <div class="card-header text-center text-white text-bold-700 bg-primary">
               <?php echo e(ucfirst($exam_result->courseExamDate->studentCourse->course->course_name)); ?> Exam Result
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered <?php echo e($exam_result->result == '1' ? 'text-success' : 'text-danger'); ?>">
                        <tr>
                            <td>Status</td>
                            <td><?php echo e($exam_result->result == "1" ? "Pass" : "Fail"); ?></td>
                        </tr>
                        <tr>
                            <td>Total Marks</td>
                            <td><?php echo e($exam_result->total_marks); ?></td>
                        </tr>
                        <tr>
                            <td>Obtain Marks</td>
                            <td><?php echo e($exam_result->obtain_marks); ?></td>
                        </tr>
                        <tr>
                            <td>Certificate</td>
                            <?php if($exam_result->certificate == ""): ?>
                                <td>N/A</td>
                            <?php else: ?>
                                <td><i class="ft-printer"></i></td>
                            <?php endif; ?>
                        </tr>
                        
                        <tr>
                            <td>Result Attachment</td>
                            <?php if($exam_result->certificate == ""): ?>
                                <td>N/A</td>
                            <?php else: ?>
                                <td><i class="ft-printer"></i></td>
                            <?php endif; ?>
                        </tr>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app_student', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>