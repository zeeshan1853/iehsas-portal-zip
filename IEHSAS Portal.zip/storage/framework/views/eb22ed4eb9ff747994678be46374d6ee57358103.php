<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="dom">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr class="bg-amber text-center">
                                    <th>Sr. No</td>
                                    <th>Name</th>
                                    <th>Quiz</th>
                                    <th>Total Marks</th>
                                    <th>Obtain Marks</th>
                                    <th>Remarks</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo e($result['student_name']); ?></td>
                                        <td>
                                            <?php if($result['quiz'] == ""): ?>
                                            
                                            <?php else: ?>
                                            <a href="<?php echo e(asset($result['quiz'])); ?>" target="_blank">
                                                <span class="ft-download"></span>
                                            </a>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($result['total_marks']); ?></td>
                                        <td><?php echo e($result['obtain_marks']); ?></td>
                                        <td><?php echo e($result['remarks']); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('quizResult.edit',['id'=>$result['quiz_id']])); ?>" title="Edit Student Quiz Details">
                                                <span class="ft-edit"></span>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>