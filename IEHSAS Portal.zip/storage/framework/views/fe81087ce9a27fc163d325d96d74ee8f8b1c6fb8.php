<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="dom">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table class="table table-striped mt-5 text-center">
                        <thead class="bg-success bg-lighten-2 white">
                            <tr>
                                <th>Sr.No</td>
                                <th>Student Name</th>
                                <th>Total Marks</th>
                                <th>Obtain Marks</th>
                                <th>Remarks</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php if($reports->count() == 0): ?>
                                <tr>
                                    <td colspan="3">No Result Found</td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo e($report->student->student_name); ?> <?php echo e($report->student->father_name); ?></td>
                                        <td><?php echo e($report->batchAssessment->total_marks); ?></td>
                                        <td><?php echo e($report->obtain_marks); ?></td>
                                        <td><?php echo e($report->remarks == "" ? "N/A" : $report->remarks); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('batchAssessment.edit',['id'=>$report->id])); ?>">
                                                <i class="ft-edit"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>