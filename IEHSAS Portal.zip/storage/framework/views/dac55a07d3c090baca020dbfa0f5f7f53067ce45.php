<?php $__env->startSection('header-styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<h1>Admin DashBoard</h1><small></small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>