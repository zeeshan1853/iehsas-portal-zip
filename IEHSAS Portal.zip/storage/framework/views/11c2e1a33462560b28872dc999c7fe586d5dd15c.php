<nav class="header-navbar navbar-expand-md navbar navbar-with-menu navbar-without-dd-arrow fixed-top navbar-semi-light">
    <div class="navbar-wrapper">
        <div class="navbar-container content">
            <div class="collapse navbar-collapse show" id="navbar-mobile">
                <ul class="nav navbar-nav mr-auto float-left">
                    <li class="nav-item mobile-menu d-md-none mr-auto"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu font-large-1"></i></a></li>
                    <li class="nav-item d-none d-md-block"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu"></i></a></li>
                    <li class="nav-item d-none d-md-block"><a class="nav-link nav-link-expand" href="#"><i class="ficon ft-maximize"></i></a></li>
                    <li class="dropdown nav-item mega-dropdown d-none d-md-block"><a class="dropdown-toggle nav-link" href="#" data-toggle="dropdown">Mega</a>
                        <ul class="mega-dropdown-menu dropdown-menu row">
                            <li class="col-md-2">
                                <h6 class="dropdown-menu-header text-uppercase mb-1"><i class="ft-link"></i> Quick Links</h6>
                                <ul>
                                    <li><a class="my-1" href="index-2.html"><i class="ft-home mr-1"></i> Dashboard</a></li>
                                    <li><a class="my-1" href="email-application.html"><i class="ft-layers mr-1"></i> Email Application</a></li>
                                    <li><a class="my-1" href="chat-application.html"><i class="ft-message-square mr-1"></i> Chat Application</a></li>
                                    <li><a class="my-1" href="form-wizard.html"><i class="ft-edit mr-1"></i> Form Wizard</a></li>
                                    <li><a class="my-1" href="table-bootstrap.html"><i class="ft-grid mr-1"></i> Tables</a></li>
                                    <li><a class="my-1" href="chartist-charts.html"><i class="ft-bar-chart mr-1"></i> Chartist</a></li>
                                    <li><a class="my-1" href="gallery-grid.html"><i class="ft-sidebar mr-1"></i> Gallery Page</a></li>
                                </ul>
                            </li>
                            <li class="col-md-3">
                                <h6 class="dropdown-menu-header text-uppercase mb-1"><i class="ft-star"></i> My Bookmarks</h6>
                                <ul class="ml-2">
                                    <li class="list-style-circle"><a class="my-1" href="card-advanced.html">
                                            Advanced Cards</a></li>
                                    <li class="list-style-circle"><a class="my-1" href="layout-content-detached-left-sidebar.html">
                                            Left sidebar</a></li>
                                    <li class="list-style-circle"><a class="my-1" href="layout-content-detached-left-sticky-sidebar.html">
                                            Sticky left sidebar</a></li>
                                    <li class="list-style-circle"><a class="my-1" href="layout-content-detached-right-sidebar.html">
                                            Right sidebar</a></li>
                                    <li class="list-style-circle"><a class="my-1" href="layout-content-detached-right-sticky-sidebar.html">
                                            Sticky right sidebar</a></li>
                                    <li class="list-style-circle"><a class="my-1" href="layout-fixed-navbar-navigation.html">
                                            Fixed Navbar & Navigation</a></li>
                                    <li class="list-style-circle"><a class="my-1" href="layout-fixed-navbar-footer.html">
                                            Fixed Navbar & Footer                  </a></li>
                                </ul>
                            </li>
                            <li class="col-md-3">
                                <h6 class="dropdown-menu-header text-uppercase"><i class="ft-layers"></i> Recent Products</h6>
                                <div class="carousel slide pt-1" id="carousel-example" data-ride="carousel">
                                    <div class="carousel-inner" role="listbox">
                                        <div class="carousel-item active"><img class="d-block w-100" src="<?php echo e(url('public/images/carousel/08.jpg')); ?>" alt="First slide"></div>
                                        <div class="carousel-item"><img class="d-block w-100" src="<?php echo e(url('public/images/carousel/03.jpg')); ?>" alt="Second slide"></div>
                                        <div class="carousel-item"><img class="d-block w-100" src="<?php echo e(url('public/images/carousel/01.jpg')); ?>" alt="Third slide"></div>
                                    </div><a class="carousel-control-prev" href="#carousel-example" role="button" data-slide="prev"><span class="la la-angle-left" aria-hidden="true"></span><span class="sr-only">Previous</span></a><a class="carousel-control-next" href="#carousel-example" role="button" data-slide="next"><span class="la la-angle-right icon-next" aria-hidden="true"></span><span class="sr-only">Next</span></a>
                                    <h5 class="pt-1">Special title treatment</h5>
                                    <p>Jelly beans sugar plum.</p>
                                </div>
                            </li>
                            <li class="col-md-4">
                                <h6 class="dropdown-menu-header text-uppercase mb-1"><i class="ft-thumbs-up"></i> Get in touch</h6>
                                <form class="form form-horizontal pt-1">
                                    <div class="form-body">
                                        <div class="form-group row">
                                            <label class="col-sm-3 form-control-label" for="inputName1">Name</label>
                                            <div class="col-sm-9">
                                                <div class="position-relative has-icon-left">
                                                    <input class="form-control" id="inputName1" type="text" placeholder="John Doe">
                                                    <div class="form-control-position pl-1"><i class="ft-user"></i></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-3 form-control-label" for="inputContact1">Contact</label>
                                            <div class="col-sm-9">
                                                <div class="position-relative has-icon-left">
                                                    <input class="form-control" id="inputContact1" type="text" placeholder="(123)-456-7890">
                                                    <div class="form-control-position pl-1"><i class="ft-smartphone"></i></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-3 form-control-label" for="inputEmail1">Email</label>
                                            <div class="col-sm-9">
                                                <div class="position-relative has-icon-left">
                                                    <input class="form-control" id="inputEmail1" type="email" placeholder="john@example.com">
                                                    <div class="form-control-position pl-1"><i class="ft-mail"></i></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-3 form-control-label" for="inputMessage1">Message</label>
                                            <div class="col-sm-9">
                                                <div class="position-relative has-icon-left">
                                                    <textarea class="form-control" id="inputMessage1" rows="2" placeholder="Simple Textarea"></textarea>
                                                    <div class="form-control-position pl-1"><i class="ft-message-circle"></i></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12 mb-1">
                                                <button class="btn btn-danger float-right" type="button"><i class="ft-arrow-right"></i> Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown d-none d-md-block mr-1"><a class="dropdown-toggle nav-link" id="apps-navbar-links" href="#" data-toggle="dropdown">
                            Apps</a>
                        <div class="dropdown-menu">
                            <div class="arrow_box"><a class="dropdown-item" href="email-application.html"><i class="ft-user"></i> Email</a><a class="dropdown-item" href="chat-application.html"><i class="ft-mail"></i> Chat</a><a class="dropdown-item" href="project-summary.html"><i class="ft-briefcase"></i> Project Summary            </a><a class="dropdown-item" href="full-calender.html"><i class="ft-calendar"></i> Calendar            </a></div>
                        </div>
                    </li>
                </ul>
                <ul class="nav navbar-nav float-right">
                    <li class="dropdown dropdown-user nav-item"><a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown">             <span class="avatar avatar-online"><img src="<?php echo e(url('public/images/portrait/small/avatar-s-19.png')); ?>" alt="avatar"></span></a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <div class="arrow_box_right"><a class="dropdown-item" href="<?php echo e(url('/home')); ?>"><span class="avatar avatar-online"><img src="<?php echo e(url('public/images/portrait/small/avatar-s-19.png')); ?>" alt="avatar"><span class="user-name text-bold-700 ml-1"><?php echo e(ucwords(Auth::user()->Name)); ?></span></span></a>
                                <div class="dropdown-divider"></div><a class="dropdown-item" href="<?php echo e(route('user.edit_profile',['id'=>Auth::id()])); ?>"><i class="ft-user"></i> Edit Profile</a>
                                <div class="dropdown-divider"></div><a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick=
                                    "event.preventDefault();
                                        document.getElementById('logout-form').submit();
                                    ">
                                    <i class="ft-power"></i> Logout</a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>