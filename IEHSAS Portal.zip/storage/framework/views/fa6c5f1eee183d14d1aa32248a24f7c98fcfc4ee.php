<?php $__env->startSection('header-styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('outgoingMail.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="branch_id" value="<?php echo e(Auth::user()->branch->id); ?>">
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">To</label>
                                    <div class="col-md-9">
                                        <input type="text" id="=to" autofocus value="<?php echo e(old('to')); ?>" class="form-control <?php echo e($errors->has('to') ? 'border-danger' : ''); ?>" placeholder="Mail Send To ?" name="to">
                                        <?php if($errors->has('to')): ?>
                                            <span class=" text-danger"><?php echo e($errors->first('to')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Address</label>
                                    <div class="col-md-9">
                                        <textarea class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" placeholder="Enter Mail Address" name="address" rows="8"><?php echo e(old('address')); ?></textarea>
                                        <?php if($errors->has('address')): ?>
                                            <span class="text-danger "><?php echo e($errors->first('address')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Date</label>
                                    <div class="col-md-9">
                                        <input type="date" id="date" class="form-control date <?php echo e($errors->has('date') ? 'border-danger' : ''); ?>"  name="date">
                                    </div>
                                    <?php if($errors->has('date')): ?>
                                        <span class="text-danger offset-md-4"><?php echo e($errors->first('date')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Courier Name</label>
                                    <div class="col-md-9">
                                        <input type="text" id="courierName" placeholder="Enter Courier Name" value="<?php echo e(old('courier_name')); ?>" class="form-control <?php echo e($errors->has('courier_name') ? 'border-danger' : ''); ?>"  name="courier_name">
                                        <?php if($errors->has('courier_name')): ?>
                                            <span class="text-danger courier_name">
                                                <?php echo e($errors->first('courier_name')); ?>

                                            </span>
                                        <?php endif; ?>  
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Tracking No</label>
                                    <div class="col-md-9">
                                        <input type="text" value="<?php echo e(old('tracking_no')); ?>" name="tracking_no" id="tracking_no" placeholder="Enter Mail Tracking No" class="form-control <?php echo e($errors->has('tracking_no') ? 'is-invalid' : ''); ?>">
                                        <?php if($errors->has('tracking_no')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('tracking_no')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Dispatcher Name:</label>
                                    <div class="col-md-9">
                                        <input type="text" value="<?php echo e(old('dispatcher')); ?>" class="form-control <?php echo e($errors->has('dispatcher') ? 'is-invalid' : ''); ?>" name="dispatcher" id="dispatcher" placeholder="Enter Dispatcher Name">
                                        <?php if($errors->has('dispatcher')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('dispatcher')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>

                        </div>

                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Dispatch" id="btnAdd" class="btn btn-primary">
                        
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script>
        var dueAmount = 0;
        $(document).ready(function (e) {
            var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month + 1;
            if(month < 10) {
                month =  "0" +month;
            }
            if(fullDate < 10)
                fullDate = '0' + fullDate;


            $(".date").val(date.getFullYear() + "-" + month + "-" + fullDate);
        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>