<div class="main-menu menu-fixed menu-dark menu-accordion menu-shadow " data-scroll-to-active="true">
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <li class=" nav-item"><a href="<?php echo e(route('teacher.dashboard')); ?>"><i class="icon-home"></i><span class="menu-title" data-i18n="nav.dash.main">Dashboard</span> </a>
            </li>
            <li class="nav-item"><a href=""><i class="ft-alert-octagon"></i><span class="menu-title" data-i18n="nav.changelog.main">Notifications</span>
                <span class="badge badge badge-pill badge-danger float-right">12</span>
            </a>
            </li>
            <li class="nav-item"><a href="#"><i class="fa fa-book"></i><span class="menu-title" data-i18n="nav.menu_levels.main">Batches</span></a>
                <ul class="menu-content">
                    <li><a class="menu-item" href="<?php echo e(route('teacher.activeBatch')); ?>" data-i18n="nav.menu_levels.second_level">Active Batches</a></li>
                    <li><a class="menu-item" href="<?php echo e(route('teacher.oldBatches')); ?>" data-i18n="nav.menu_levels.second_level">Old Bathces</a></li>
                </ul>
            </li>
            <li class="nav-item"><a href="#"><i class="fa fa-sticky-note-o"></i><span class="menu-title" data-i18n="nav.menu_levels.main">Forms</span></a>
                <ul class="menu-content">
                    <li><a class="menu-item" href="" data-i18n="nav.menu_levels.second_level">Complain Form</a></li>
                    <li><a class="menu-item" href="" data-i18n="nav.menu_levels.second_level">Refund Form</a></li>
                </ul>
            </li>
            <li class="nav-item"><a href="#"><i class="icon-support"></i><span class="menu-title" data-i18n="nav.dash.main">Support</span> </a>
            </li>
            <li class="nav-item"><a href="<?php echo e(route('teacher.logout')); ?>"><i class="fa fa-sign-out"></i><span class="menu-title" data-i18n="nav.logout.main">Logout</span></a></li>
        </ul>
    </div>
</div>