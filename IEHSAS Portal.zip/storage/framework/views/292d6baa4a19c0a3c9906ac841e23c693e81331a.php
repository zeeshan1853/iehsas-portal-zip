<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(asset('vendors/css/tables/datatable/datatables.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="coursesData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="certificate_no">Certificarte No</td>
                        <td data-column-id="student_name">Student</td>
                        <td data-column-id="certificate_type">Type</td>
                        <td data-column-id="exam_date">Exam Date</td>
                        <td data-column-id="declared_date">Declared Date</td>
                        <td data-column-id="issued_date">Issued Date</td>
                        <td data-column-id="received_date">Received Date</td>
                        <td data-column-id="delete" data-sortable="false">Acions</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    <?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($certificate->certificate_no); ?></td>
                            <td><?php echo e($certificate->student->student_name); ?> <?php echo e($certificate->student->father_name); ?></td>
                            <td><?php echo e($certificate->certificateType->name); ?></td>
                            <td><?php echo e($certificate->exam_date->toFormattedDateString()); ?></td>
                            <td><?php echo e($certificate->declared_date->toFormattedDateString()); ?></td>
                            <td><?php echo e($certificate->issued_date->toFormattedDateString()); ?></td>
                            <td><?php echo e($certificate->created_at->toFormattedDateString()); ?></td>
                            <td>
                                <a href="<?php echo e(route('certificate.delete',['id'=>$certificate->id])); ?>" style="color:red" title="Delete Certificate"><i class="ft-trash"></i></a>
                                <a href="<?php echo e(route('certificate.edit',['id'=>$certificate->id])); ?>" style="color:blue" title="Edit Certificate Deatils"><i class="ft-edit"></i></a>
                                <a href="#" data-id="<?php echo e($certificate->id); ?>" class="dispatch" style="color:green" title="Dispatch Certificate"><i class="ft-check-square"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="modal fade text-left" id="dispatchModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-cyan">
                <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Disptach Mail</h4> &nbsp;&nbsp; <span> Required *</span>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <form id="dispatchForm">
                        <input type="hidden" name="certificate_id" value="" id="certificateId">
                        <input type="hidden" name="branch_id" value="<?php echo e(Auth::user()->branch->id); ?>" id="branch_id">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Courier Name <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control " id="courierName" name="courier_name" placeholder="Enter Courier Name">
                                    </div>
                                    <span class="text-danger courier_name offset-md-4 has-error"></span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Tracking No <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" name="tracking_no" id="trackingNo" class="form-control" placeholder="Enter Courier Tracking No">
                                    </div>
                                    <span class="offset-md-4 tracking_no text-danger has-error"></span>
                                </div>
    
                            </div>
                        </div>
                        <div class="row">
                            
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Dispatcher Name <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" placeholder="Enter Dispatcher name" name="dispatcher" id="dispatcher">
                                    </div>
                                    <span class="text-danger dispatcher offset-md-4 has-error"></span>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" id="btnSave" class="btn btn-danger">Dispatch</button>
                </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/tables/datatables/datatable-styling.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/tables/datatables/datatable-basic.min.js')); ?>"></script>
    <script>
        $(document).ready(function(e) {
            $("#coursesData").DataTable();
            $(".dispatch").click(function(e) {
                var id = $(this).attr("data-id");
                $("#dispatchModal").modal();
                $("#certificateId").val(id);
            });
            $("#btnSave").click(function(e) {
                var data = $("#dispatchForm").serializeArray();
                var i= 0;
                data.forEach(function(d) {
                    if(d.value == "") {
                        i++;
                        $("."+d.name).html("This Field is Required");
                    }
                });
                if(i > 0) {
                    return;
                }
                $.ajax({
                    url:"<?php echo e(route('outgoingCertificate.storeAjax')); ?>",
                    data:data,
                    dataType:'JSON',
                    type:'POST',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                $("#trackingNo").val(" ");
                                $("#dispatcher").val(" ");
                                $("#courierName").val(" ");
                                $("#dispatchModal").modal('hide');
                                toastr.success("Certificate Dispatch Successfully");
                                setTimeout(()=>{
                                    window.location.reload();
                                },1000)
                            } else {
                                toastr.error("Opss Something Went Wrong");
                            }
                        } else {
                            toastr.error("Contact Admin "+jqXHR.status);
                        }
                    }
                })
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>