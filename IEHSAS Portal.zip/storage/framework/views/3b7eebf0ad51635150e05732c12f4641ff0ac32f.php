<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(asset('vendors/css/tables/datatable/datatables.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="incomingMailsData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="to">To</td>
                        <td data-column-id="contact_no">Address</td>
                        <td data-column-id="to">Date</td>
                        <td data-column-id="courier_name">Courier</td>
                        <td data-column-id="tracking_no">Tracking No</td>
                        <td data-column-id="dispatcher">Dispatcher</td>
                        <td data-column-id="actions" data-sortable="false">Actions</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    <?php $__currentLoopData = $mails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($mail->to); ?></td>
                            <td><?php echo e($mail->address); ?></td>
                            <td><?php echo e($mail->date->toFormattedDateString()); ?></td>
                            <td><?php echo e($mail->courier_name); ?></td>
                            <td><?php echo e($mail->tracking_no); ?></td>
                            <td><?php echo e($mail->dispatcher); ?></td>
                            <td>
                                <a href="<?php echo e(route('outgoingMail.edit',['id'=>$mail->id])); ?>"><i class="ft-edit"></i></a>
                                <a href="<?php echo e(route('outgoingMail.delete',['id'=>$mail->id])); ?>"><i class="ft-trash" style="color:red;"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Dispatch Mail --->
    <div class="modal fade text-left" id="dispatchModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-cyan">
                <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Disptach Mail</h4> &nbsp;&nbsp; <span> Required *</span>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">
                    <form id="dispatchForm">
                        <input type="hidden" name="incoming_mail_id" value="" id="incomingId">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">To <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" autofocus id="to" value="" class="form-control"  placeholder="Send Mail To ?" name="to">
                                    </div>
                                    <span class="offset-md-4 to text-danger has-error"></span>
                                </div>
    
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Address <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <textarea class="form-control" rows="6" id="address" name="address" placeholder="Enter Address"></textarea>
                                    </div>
                                    <span class="text-danger address offset-md-4 has-error"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Date <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="date" id="date" class="form-control date" name="date">
                                    </div>
                                    <span class="offset-md-4 date text-danger has-error"></span>
                                </div>
    
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Courier Name <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control " id="courierName" name="courier_name" placeholder="Enter Courier Name">
                                    </div>
                                    <span class="text-danger courier_name offset-md-4 has-error"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Tracking No <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" name="tracking_no" id="trackingNo" class="form-control" placeholder="Enter Courier Tracking No">
                                    </div>
                                    <span class="offset-md-4 tracking_no text-danger has-error"></span>
                                </div>
    
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Dispatcher Name <span class="text-danger">*</span></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" placeholder="Enter Dispatcher name" name="dispatcher" id="dispatcher">
                                    </div>
                                    <span class="text-danger dispatcher offset-md-4 has-error"></span>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn grey btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" id="btnSave" class="btn btn-danger">Save</button>
                </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/tables/datatables/datatable-styling.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/tables/datatables/datatable-basic.min.js')); ?>"></script>
    <script>
        $(document).ready(function(e) {
            var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month + 1;
            if(month < 10) {
                month =  "0" +month;
            }
            if(fullDate < 10)
                fullDate = '0' + fullDate;


            $(".date").val(date.getFullYear() + "-" + month + "-" + fullDate);
            $("#incomingMailsData").DataTable();
            $("#dispatch").click(function(e) {
                e.preventDefault();
                $("#dispatchModal").modal();
                var id = $(this).attr("data-id");
                $("#incomingId").val(id);
            });
            $("#btnSave").click(function(e) {
                
                $(".has-error").html(" ");
                var data = $("#dispatchForm").serializeArray();
                var i = 0;
                //validating data
                data.forEach(function(d,index) {
                    if(d.value == "") {
                        $("."+d.name).html("This Field is Required");
                        i++;
                    }
                });     
                if(i > 0) {
                    return;
                }
                $.ajax({
                    url:"<?php echo e(route('outgoingMail.storeAjax')); ?>",
                    data:data,
                    dataType:'JSON',
                    type:'POST',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                toastr.success("Mail Dispatch Successfully");
                                setTimeout(()=>{
                                    window.location.reload();
                                },1000)
                                
                            }
                        }
                    }
                });
            }); 
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>