<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(asset('vendors/css/tables/datatable/datatables.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="cashAccount">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="date">Date</td>
                        <td data-column-id="name">Narration</td>
                        <td data-column-id="debit" class="debit">Debit</td>
                        <td data-column-id="credit" class="credit">Credit</td>
                        <td data-column-id="opening">Opening</td>
                    </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td><?php echo e($bank_account->opening); ?></td>
                        </tr>
                        <?php
                            $i = 1;
                            $total = $bank_account->opening;
                        ?>
                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($book->created_at->toFormattedDateString()); ?></td>
                                <td><?php echo e($book->narration); ?></td>
                                <td><?php echo e($book->debit); ?></td>
                                <td><?php echo e($book->credit); ?></td>
                                <?php
                                    
                                    $balance = 0;
                                    $balance = $book->debit - $book->credit;
                                    $total = $balance + $total;
                                    echo("<td>".$total."</td>");
                                ?>
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot class="bg-info text-white">
                        <tr>
                            <td colspan="3">Total</td>
                            <td class="total_debit"></td>
                            <td class="total_credit"></td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/tables/datatables/datatable-styling.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/tables/datatables/datatable-basic.min.js')); ?>"></script>
    <script>
        $(document).ready(function(e) {
            $("#cashAccount").dataTable({
            "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            "footerCallback": function(row, data, start, end, display) {
                var api = this.api();

                api.columns('.credit', {
                    page: 'current'
                }).every(function() {
                    var sum = this
                        .data()
                        .reduce(function(a, b) {
                            var x = parseFloat(a) || 0;
                            var y = parseFloat(b) || 0;
                            return x + y;
                        }, 0);

                    console.log(sum); //alert(sum);
                    $(this.footer()).html(sum);
                })

                api.columns('.debit', {
                    page: 'current'
                }).every(function() {
                    var sum = this
                        .data()
                        .reduce(function(a, b) {
                            var x = parseFloat(a) || 0;
                            var y = parseFloat(b) || 0;
                            return x + y;
                        }, 0);

                    console.log(sum); //alert(sum);
                    $(this.footer()).html(sum);
                });
            }
        });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>