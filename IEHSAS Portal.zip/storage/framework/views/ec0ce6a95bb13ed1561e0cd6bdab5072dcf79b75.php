

<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(asset('vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('css/jasny-bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
    <div id="app">
        <enrolment></enrolment>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>

    <script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jasny-bootstrap.min.js')); ?>"></script>
    <script> window.Laravel = { csrfToken : '<?php echo e(csrf_token()); ?> ',asset:'<?php echo e(asset('/')); ?>',path:'<?php echo e(url('admin/')); ?>'}</script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            setTimeout(()=>{
                var body = document.getElementsByTagName('body')[0];
                body.classList.remove('menu-expanded');
                body.classList.add("menu-collapsed");
            },1000)
            
        });

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>