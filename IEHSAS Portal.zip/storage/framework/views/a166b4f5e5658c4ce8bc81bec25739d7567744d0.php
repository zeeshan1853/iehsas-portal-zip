<?php $__env->startSection('header-styles'); ?>
<link href="<?php echo e(asset('css/jasny-bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="row">
    <div class="card col-md-8 offset-md-2">
        <div class="card-body">
            <form method="post" action="<?php echo e(route('user.updatePassword')); ?>">
                <?php echo csrf_field(); ?>
                <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                <div class="form-group">
                    <label>
                        <h5 class="mt-2">Old Password:</h5>
                    </label>
                    <input type="password" name="old_password" class="form-control <?php echo e($errors->has('old_password') ? 'is-invalid' : ''); ?>"
                        id="basicInput" placeholder="Enter Old Password">
                    <span class="text-danger">
                        <?php if($errors->has('old_password')): ?>
                        <?php echo e($errors->first('old_password')); ?>

                        <?php endif; ?>
                    </span>
                </div>
                <div class="form-group">
                    <label><h5 class="mt-2">New Password:</h5></label>
                    <input type="password" name="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>"
                        id="basicInput" placeholder="Enter New Password">
                    <span class="text-danger">
                        <?php if($errors->has('password')): ?>
                        <?php echo e($errors->first('password')); ?>

                        <?php endif; ?>
                    </span>
                </div>
                <div class="form-group">
                    <label><h5 class="mt-2">Confirm Password:</h5></label>
                    <input type="password" name="password_confirmation" class="form-control <?php echo e($errors->has('password_confirmation') ? 'is-invalid' : ''); ?>"
                        id="basicInput" placeholder="Confirm Password">
                    <span class="text-danger">
                        <?php if($errors->has('password_confirmation')): ?>
                        <?php echo e($errors->first('password_confirmation')); ?>

                        <?php endif; ?>
                    </span>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary offset-md-4 col-md-4">
                        Edit Profile
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<script src="<?php echo e(asset('js/jasny-bootstrap.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>