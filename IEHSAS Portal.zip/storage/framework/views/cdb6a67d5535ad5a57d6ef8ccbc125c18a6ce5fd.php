<?php $__env->startSection('header-styles'); ?>
<link href="<?php echo e(asset('vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="row">
    <div class="card col-md-12">
        <div class="card-body">
            <form class="form form-horizontal" method="post" action="<?php echo e(route('documentType.store')); ?>"
                id="documentTypeForm" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-body">
                    <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                    <div class="row">
                        <div class="col-md-6 offset-md-2">
                            <div class="form-group row">
                                <label class="col-md-4 label-control" for="userinput1">Docoument Type Name</label>
                                <div class="col-md-8">
                                    <input type="text" value="<?php echo e(old('name')); ?>" autofocus
                                        placeholder="Enter Document Name"
                                        class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" name="name">
                                    <?php if($errors->has('name')): ?>
                                    <span class="text-danger">
                                        <?php echo e($errors->first('name')); ?>

                                    </span>
                                    <?php endif; ?>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 offset-md-2">
                            <div class="form-group row">
                                <label class="col-md-4 label-control" for="userinput1">Document Type:</label>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <select class="form-control" name="course_id" id="courseId">
                                            <option value="">--Select Document Type--</option>
                                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="input-group-append">
                                            <span class="input-group-text">
                                                <a href="#" id="addDocumentType"><i class="ft-plus-circle"></i></a>
                                            </span>
                                        </div>
                                    </div>
                                    <?php if($errors->has('course_id')): ?>
                                    <span class="text-danger">
                                        <?php echo e($errors->first('course_id')); ?>

                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="form-actions ">
                    <input type="submit" value="Add" id="btnAdd" class="btn btn-primary offset-md-5">
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
<script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
<script>
    $(document).ready(function(e) {
        $("#courseId").select2();
        
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>