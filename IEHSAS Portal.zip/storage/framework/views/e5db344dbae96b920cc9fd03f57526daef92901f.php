<?php $__env->startSection('header-styles'); ?>
<link href="<?php echo e(asset('vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('enquiry.update',['id'=>$enquiry->id])); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="branch_id" value="<?php echo e(Auth::user()->branch->id); ?>">
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Student Name</label>
                                    <div class="col-md-9">
                                        <input type="text" id="studentName" autofocus <?php if(old('student_name') == ''): ?> value="<?php echo e($enquiry->student_name); ?>" <?php else: ?> value="<?php echo e(old('student_name')); ?>" <?php endif; ?> class="form-control <?php echo e($errors->has('student_name') ? 'border-danger' : ''); ?>" placeholder="Enter Student Name" name="student_name">
                                        <?php if($errors->has('student_name')): ?>
                                            <span class=" text-danger"><?php echo e($errors->first('student_name')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Course</label>
                                    <div class="col-md-9">
                                        <select class="form-control" name="course_id" id="course_id">
                                            <option> -- Select Course -- </option>
                                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($course->id == $enquiry->course_id): ?>
                                                <option value="<?php echo e($course->id); ?>" selected><?php echo e($course->course_name); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_name); ?></option>
                                            <?php endif; ?>
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('course_id')): ?>
                                            <span class=" text-danger"><?php echo e($errors->first('course_id')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Education</label>
                                    <div class="col-md-9">
                                        <select name="education_id" id="education_id" class="form-control select2"> 
                                            <option value="">-- Select Education --</option>
                                            <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($education->id == $enquiry->education_id): ?>
                                                <option value="<?php echo e($education->id); ?>" selected><?php echo e($education->name); ?></option>
                                            <?php else: ?>
                                            <option value="<?php echo e($education->id); ?>"><?php echo e($education->name); ?></option>
                                            <?php endif; ?>
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('education_id')): ?>
                                            <span class="text-danger "><?php echo e($errors->first('education_id')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput4">Email</label>
                                        <div class="col-md-9">
                                                <input type="email"  <?php if(old('email') == ''): ?> value="<?php echo e($enquiry->email); ?>" <?php else: ?> value="<?php echo e(old('email')); ?>" <?php endif; ?> placeholder="Enter Student Email" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" name="email">
                                            <?php if($errors->has('email')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                            <?php endif; ?>
                                        </div>
    
                                    </div>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Contact No</label>
                                    <div class="col-md-9">
                                        <input type="text" id="contact_no" <?php if(old('contact_no') == ''): ?> value="<?php echo e($enquiry->contact_no); ?>" <?php else: ?> value="<?php echo e(old('contact_no')); ?>" <?php endif; ?> placeholder="Enter Student Contact No" class="form-control <?php echo e($errors->has('contact_no') ? 'border-danger' : ''); ?>"  name="contact_no">
                                        <?php if($errors->has('contact_no')): ?>
                                            <span class="text-danger contact_no">
                                                <?php echo e($errors->first('contact_no')); ?>

                                            </span>
                                        <?php endif; ?>  
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Update" id="btnAdd" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script>
        
        var dueAmount = 0;
        $(document).ready(function (e) {
            $("#certificate_type_id").select2();
            $("#course_id").select2();
            $("#education_id").select2();
        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>