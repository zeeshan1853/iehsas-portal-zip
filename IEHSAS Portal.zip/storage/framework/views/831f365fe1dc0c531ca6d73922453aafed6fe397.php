<div class="main-menu menu-fixed menu-light menu-accordion    menu-shadow " data-scroll-to-active="true" data-img="<?php echo e(asset('images/backgrounds/02.jpg')); ?>">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item mr-auto"><a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img class="brand-logo" alt="Company Logo" src="<?php echo e(asset(Auth::user()->branch->setting->logo)); ?>"/>
            <li class="nav-item d-md-none"><a class="nav-link close-navbar"><i class="ft-x"></i></a></li>
        </ul>
    </div>
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            
        </ul>
    </div>
    <div class="navigation-background"></div>
</div>