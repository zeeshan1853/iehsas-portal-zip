<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <title>Teacher Registration</title>
    <style>
        .link {
            width:180px;
            height: 30px;
            background-color: #6967ce;
            padding: 20px;
            border-radius: 5px;
        }
        .link a {
            color:white;
            text-decoration: none;
            font-size: 20px;
        }
    </style>
</head>
<body>
    <h1>Greetings From <?php echo e(config('app.name')); ?></h1>
    <h2>Mr / Miss  <?php echo e(ucfirst($teacher->name)); ?> congratulation to be part of our organization.</h2>
    <p>Click Button to Login into your Dashboard</p>
    <center>
        <div class="link">
            <a href="<?php echo e(route('teacher.login')); ?>">Login / Dashboard</a>
        </div>
    </center>
    <p>Do not share your password with anyone else  <?php echo e($password); ?></p>
</body>
</html>