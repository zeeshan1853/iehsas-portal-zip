<?php $__env->startSection('header-styles'); ?>
<link href="<?php echo e(asset('vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">
<style>
        input[type="date"]::-webkit-calendar-picker-indicator {
            background: transparent;
            bottom: 0;
            color: transparent;
            cursor: pointer;
            height: auto;
            left: 0;
            position: absolute;
            right: 0;
            top: 0;
            width: auto;
        }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('certificate.update',['id'=>$certificate->id])); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="branch_id" value="<?php echo e($certificate->branch_id); ?>">
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Certificate No</label>
                                    <div class="col-md-9">
                                        <input type="text" id="certificate_no" autofocus <?php if(old('certificate_no') == ''): ?> value="<?php echo e($certificate->certificate_no); ?>" <?php else: ?> value="<?php echo e(old('certificate_no')); ?>" <?php endif; ?> class="form-control <?php echo e($errors->has('certificate_no') ? 'border-danger' : ''); ?>" placeholder="Enter Certificate No" name="certificate_no">
                                        <?php if($errors->has('certificate_no')): ?>
                                            <span class=" text-danger"><?php echo e($errors->first('certificate_no')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Student</label>
                                    <div class="col-md-9">
                                        <select class="form-control" name="student_id" id="student_id">
                                            <option value="<?php echo e($certificate->student_id); ?>"><?php echo e($certificate->student->student_name); ?> <?php echo e($certificate->student->father_name); ?> <?php echo e($certificate->student->contact_no); ?></option>
                                        </select>
                                        <?php if($errors->has('student_id')): ?>
                                            <span class=" text-danger"><?php echo e($errors->first('student_id')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput2">Certificate Type</label>
                                    <div class="col-md-9">
                                        <select name="certificate_type_id" id="certificate_type_id" class="form-control"> 
                                            <option value="">-- Select Certificate Type --</option>
                                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($type->id == $certificate->certificate_type_id): ?>
                                                <option value="<?php echo e($type->id); ?>" selected><?php echo e($type->name); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('certificate_type_id')): ?>
                                            <span class="text-danger "><?php echo e($errors->first('certificate_type_id')); ?></span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-3 label-control" for="userinput4">Exam Date</label>
                                        <div class="col-md-9">
                                                <input type="date" class="form-control date <?php echo e($errors->has('exam_date') ? 'is-invalid' : ''); ?>" name="exam_date" value="<?php echo e($certificate->exam_date->format('Y-m-d')); ?>">
                                            <?php if($errors->has('exam_date')): ?>
                                                <span class="text-danger"><?php echo e($errors->first('exam_date')); ?></span>
                                            <?php endif; ?>
                                        </div>
    
                                    </div>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Declared Date</label>
                                    <div class="col-md-9">
                                        <input type="date" id="declaredDate" class="form-control date <?php echo e($errors->has('declared_date') ? 'border-danger' : ''); ?>"  name="declared_date" value="<?php echo e($certificate->declared_date->format('Y-m-d')); ?>">
                                        <?php if($errors->has('declared_date')): ?>
                                            <span class="text-danger courier_name">
                                                <?php echo e($errors->first('declared_date')); ?>

                                            </span>
                                        <?php endif; ?>  
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput3">Issused Date</label>
                                    <div class="col-md-9">
                                        <input type="date" id="issusedDate" class="form-control date <?php echo e($errors->has('issuesed_date') ? 'border-danger' : ''); ?>"  name="issued_date" value="<?php echo e($certificate->issued_date->format('Y-m-d')); ?>">
                                    </div>
                                    <?php if($errors->has('issued_date')): ?>
                                        <span class="text-danger offset-md-4"><?php echo e($errors->first('issued_date')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                        </div>

                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Update" id="btnAdd" class="btn btn-primary">
                        
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script>
        
        var dueAmount = 0;
        $(document).ready(function (e) {
            var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month + 1;
            if(month < 10) {
                month =  "0" +month;
            }
            if(fullDate < 10)
                fullDate = '0' + fullDate;
            $("#certificate_type_id").select2();
            var dates = document.getElementsByClassName('date');
            for(d in dates){
                if(dates[d].value == "") {
                    dates[d].value = date.getFullYear() + "-" + month + "-" + fullDate;
                }
            }
            $("#student_id").select2({
                minimumInputLength:5,
                placeholder:'Search Student...',
                ajax:{
                    url:'/api/students',
                    dataType:'JSON',
                    type:'POST',
                    delay:1000,
                    data:function(term) {
                        return{
                            term:term,
                        }
                    },
                    processResults:function(data) {
                        return{
                            results: $.map(data, function(item) {
                                return {
                                    text:item.student_name+" "+item.father_name+" "+item.contact_no,
                                    id:item.id,
                                    slug:item.hostel_fee,
                                }
                            })
                        }
                    }
                }
            });
        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>