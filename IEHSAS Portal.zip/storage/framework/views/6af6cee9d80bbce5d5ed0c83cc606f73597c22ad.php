<?php $__env->startSection('header-styles'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-8 offset-md-2">
            <div class="card-body">
                <form method="post" action="<?php echo e(route('branch.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label><h5 class="mt-2">Branch Name:</h5></label>
                        <input type="text" name="name" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" id="branchName" placeholder="Branch Name" value="<?php echo e(old('name')); ?>">
                        <span class="text-danger">
                            <?php if($errors->has('name')): ?>
                                <?php echo e($errors->first('name')); ?>

                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="form-group">
                        <label><h5 class="mt-2">Branch Opening Balance:</h5></label>
                        <input type="text" name="opening" class="form-control <?php echo e($errors->has('opening') ? 'is-invalid' : ''); ?>" id="opening" placeholder="Branch Opening Balance" value="<?php echo e(old('opening')); ?>">
                        <span class="text-danger">
                            <?php if($errors->has('opening')): ?>
                                <?php echo e($errors->first('opening')); ?>

                            <?php endif; ?>
                        </span>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary offset-md-4 col-md-4" >
                            Add Branch
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>