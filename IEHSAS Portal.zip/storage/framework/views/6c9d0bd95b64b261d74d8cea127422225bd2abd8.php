<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css"
    href="<?php echo e(asset('student-portal/app/vendors/css/tables/datatable/datatables.min.css')); ?>">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<section id="dom">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table class="table table-bordered" id="batches">
                        <thead class="bg-info text-white text-center">
                            <tr>
                                <th>Sr.No</th>
                                <th>Student Name</th>
                                <th>Admission Date</th>
                                <th>Contact No</th>
                                <th>Student</th>
                                <th>Rating</th>
                                <td>Exam Dates</td>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($student['student_name']); ?></td>
                                <td><?php echo e($student['admission_date']); ?></td>
                                <td><?php echo e($student['contact_no']); ?></td>
                                <td><?php echo e($student['type']); ?></td>
                                <td>
                                    <span class="badge badge-primary"><?php echo e($student['rating']); ?></span>
                                </td>
                                <td>
                                    <a href="#" data-id="<?php echo e($student['student_course_id']); ?>"
                                        class="btn btn-sm btn-info exams">Exams</a>
                                </td>
                                <td>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Exam Dates Modal -->
<div class="modal fade text-left" id="examModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-cyan">
                <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Course Exam Dates</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table class="table table-striped table-bordered">
                    <tr class="bg-info text-white">
                        <th>Sr.No</th>
                        <th>Exam Date</th>
                        <th>Willingness ?</th>
                        <th>Result Status</th>
                    </tr>
                    <tbody class="tbody">

                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<!-- Result Modal -->
<div class="modal fade text-left" id="resultModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel18" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-cyan">
            <h4 class="modal-title" id="myModalLabel18"><i class="la la-tree"></i> Student Exam Result</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered">
                        <tr>
                            <td>Status</td>
                            <td class="status"></td>
                        </tr>
                        <tr>
                            <td>Total Marks</td>
                            <td class="total_marks"></td>
                        </tr>
                        <tr>
                            <td>Obtain Marks</td>
                            <td class="obtain_marks"></td>
                        </tr>
                        <tr>
                           <td>Certificate</td> 
                           <td class="certificate"></td>
                        </tr>
                        <tr>
                            <td>Result Attachments</td>
                            <td class="result_attachment"></td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('student-portal/app/vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
<script>
    $(document).ready(function(e) {
        $("#batches").dataTable();
        $(".exams").on("click",function(e) {
            $("#examModal").modal();
            var id = $(this).data("id");
            var route = "<?php echo e(route('ExamDate.courseExamDate',':id')); ?>";
                route = route.replace(":id",id);
                $.ajax({
                    url:route,
                    dataType:'JSON',
                    type:'GET',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                var output = "";
                                var i = 0;
                                result.exam_dates.forEach(function(exam_date) {
                                    i++;
                                    output += "<tr><td>"+i+"</td><td>"+exam_date.exam_date+"</td>";
                                    if(exam_date.willing == 1) {
                                        output += "<td>Yes</td>"
                                    } else {
                                        output += "<td>No</td>"
                                    }
                                    if(exam_date.result_status == "0" ) {
                                        output +="<td><i class='badge badge-primary'>Pending</i> "  
                                                    +"</td>";
                                    } else {
                                        output += "<td><a href='#' class='view-result' data-id='"+exam_date.result_id+"'><i class='badge badge-primary'>Announced &nbsp;&nbsp;<i class='ft-eye'></i> </i> </a></td>";
                                    }
                                    output += "</tr>";
                                    $(".tbody > tr").remove();
                                    $(".tbody").append(output);
                                    $("#examModal").modal();
                                })
                            }
                        }
                    }
                });
        });
        //view result 
        $(document).on("click",".view-result",function(e) {
            var id = $(this).data("id");
            var route = "<?php echo e(route('studentResult.show',':id')); ?>";
            route = route.replace(":id",id);
            $.ajax({
                url:route,
                dataType:'JSON',
                type:'GET',
                complete:function(jqXHR,textStatus) {
                    if(jqXHR.status == 200) {
                        var result = JSON.parse(jqXHR.responseText);
                        if(result.hasOwnProperty('success')) {
                            var data = result.course_result;
                            if(data.result == "1") {
                                $(".status").html("Pass");
                                var status = document.getElementsByClassName("status")[0];
                                status.parentNode.parentNode.classList += " text-success";
                            } else {
                                $(".status").html("Fail");   
                                var status = document.getElementsByClassName("status")[0];
                                status.parentNode.parentNode.classList += " text-danger";
                            }
                            $(".total_marks").html(data.total_marks);
                            $(".obtain_marks").html(data.obtain_marks);
                            if(data.certificate == "") {
                                $(".certificate").html("N/A");
                            } else {
                                $(".certificate").html("<i class='ft-eye'></i>");
                            }
                            if(data.result_attachment == "") {
                                $(".result_attachment").html("N/A");
                            } else {
                                $(".result_attachment").html("<i class='ft-eye'></i>");
                            }
                            $("#resultModal").modal();
                        }
                    }
                }
            });
        });
        
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>