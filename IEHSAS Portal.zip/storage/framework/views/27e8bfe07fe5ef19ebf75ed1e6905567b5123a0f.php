

<?php $__env->startSection('header-styles'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-8 offset-md-2">
            <div class="card-body">
                <form method="post" action="<?php echo e(route('payment.update',['id'=>$payment->id])); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label><h5 class="mt-2">Payment Name:</h5></label>
                        <input type="text" name="name" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" id="name" placeholder="Payment" value="<?php if(old('name') != null): ?> <?php echo e(old('name')); ?> <?php else: ?> <?php echo e($payment->name); ?> <?php endif; ?>">
                        <span class="text-danger">
                            <?php if($errors->has('name')): ?>
                                <?php echo e($errors->first('name')); ?>

                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary offset-md-4 col-md-4" >
                            Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>