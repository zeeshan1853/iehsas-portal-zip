<?php $__env->startSection('header-styles'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-6 offset-md-3">
            <div class="card-body">
                <form method="post" action="<?php echo e(route('user.update_profile',['id'=>$user['id']])); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label><h5 class="mt-2">User Name:</h5></label>
                        <input type="text" name="name" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" id="basicInput" placeholder="User Name" value="<?php echo e($user['name']); ?>">
                        <span class="text-danger">
                            <?php if($errors->has('name')): ?>
                                <?php echo e($errors->first('name')); ?>

                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="form-group">
                        <label><h5 class="mt-2">Email:</h5></label>
                        <input type="text" name="email" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" id="basicInput" placeholder="Email" value="<?php echo e($user['email']); ?>">
                        <span class="text-danger">
                            <?php if($errors->has('email')): ?>
                                <?php echo e($errors->first('email')); ?>

                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary offset-md-4 col-md-4" >
                            Edit Profile
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>