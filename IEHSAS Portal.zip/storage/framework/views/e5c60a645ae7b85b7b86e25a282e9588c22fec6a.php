<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('student-portal/app/css/pages/chat-application.css')); ?>">
<style>
    .card-body {
        padding: 1.0rem;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="app">
    <teacher-chat-app :asset="'<?php echo e(asset('/')); ?>'" :batch_id="'<?php echo e(Route::input('id')); ?>'" :path="'<?php echo e(url('/teacher')); ?>'" :teacher="<?php echo e($teacher); ?>">
    </teacher-chat-app>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.teacher_chat', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>