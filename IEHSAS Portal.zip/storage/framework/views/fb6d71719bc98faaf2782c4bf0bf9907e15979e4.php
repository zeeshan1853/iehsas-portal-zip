<?php $__env->startSection('header-styles'); ?>

<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('css/jquery.bootgrid.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('css/bootgridcustom.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('css/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="row">
    <div class="card col-md-12">
        <div class="card-header text-center bg-primary text-white">
            Search Option
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group row">
                        <div class="col-md-9 offset-md-3">
                            <div class="input-group">
                                <div class="input-group-prepend" style="height:34px;">
                                    <span class="input-group-text">From</span>
                                </div>
                                <input type="date" id="fromDate" class="form-control date">
                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-md-6">
                    <div class="form-group row">
                        <div class="col-md-9">
                            <div class="input-group">
                                <div class="input-group-prepend" style="height:34px;">
                                    <span class="input-group-text">To</span>
                                </div>
                                <input type="date" id="toDate" class="form-control date">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-5">
                    <div class="form-group row">
                        <div class="col-md-9 offset-md-3">
                            <div class="input-group">
                                <select class="form-control select2" id="expenseNameId">
                                    <option value="">--Select Expense Name--</option>
                                    <?php $__currentLoopData = $names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($name->id); ?>"><?php echo e($name->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-md-5">
                    <div class="form-group row">
                        <div class="col-md-9">
                            <div class="input-group">
                                <select class="form-control select2" id="expenseTypeId">
                                    <option value="">--Select Expense Type--</option>
                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group row">
                        <div class="col-md-12">
                            <label class="label-control">Include From to <input type="checkbox" id="fromTo"></label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered" id="expenses">
                    <thead >
                        <tr class="bg-info text-white">
                            <td data-column-id="sr_no">Sr.No</td>
                            <td data-column-id="date">Date</td>
                            <td data-column-id="name">Name</td>
                            <td data-column-id="amount">Amount</td>
                            <td data-column-id="type">Type</td>
                            <td data-column-id="description">Description</td>
                            <td data-column-id="payment">Payment</td>
                            <td data-column-id="actions">Actions</td>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr class="bg-info text-white text-center">
                            <td colspan="3"><b>Total</b></td>
                            <td class="total"></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<script src="<?php echo e(asset('js/jquery.bootgrid.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.bootgrid.fa.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/sweetalert2.all.min.js')); ?>"></script>
<script>
    $(document).ready(function(e) {
        setTimeout(()=>{
            var body = document.getElementsByTagName('body')[0];
            body.classList.remove('menu-expanded');
            body.classList.add("menu-collapsed");
        },1000)
        var expense_response = "";
        var date = new Date();
            var month = date.getMonth();
            var fullDate = date.getDate();
            if(month < 13)
                month = month + 1;
            if(month < 10) {
                month =  "0" +month;
            }
            if(fullDate < 10)
                fullDate = '0' + fullDate;
            $(".date").val(date.getFullYear() + "-" + month + "-" + fullDate);

            $(".select2").select2();
        var expenses =  $("#expenses").bootgrid({
            ajax:true,
            caseSensitive:false,
            searchSettings:{
                delay:1000,
            },
            labels:{
                loading:"Loading Please Wait "+ajaxLoader,
            },
            rowCount:[10,20,50,100,-1],
            post:function() {
                //extra search options
                var col_names = {};
                var i =0;
                var expenseNameId = document.getElementById("expenseNameId").value;
                var expenseTypeId = document.getElementById("expenseTypeId").value;

                if(document.getElementById("fromTo").checked) {
                    col_names[i++] = "from_to",
                    col_names['from_date'] = document.getElementById("fromDate").value;
                    col_names['to_date'] = document.getElementById("toDate").value;
                }
                if(expenseNameId != 0 && expenseNameId != "") {
                    col_names['expense_name_id'] = expenseNameId 
                }
                if(expenseTypeId != 0 || expenseTypeId != "") {
                    col_names['expense_type_id'] = expenseTypeId;
                }
                return {
                    'col_names':col_names
                }
            },
            responseHandler:function(response) {
                expense_response = response;
                return response;
            },
            url:"<?php echo e(route('expense.getExpenseList')); ?>",
        }).on('loaded.rs.jquery.bootgrid',function() {
            var total = document.getElementsByClassName("total")[0];
            total.textContent = expense_response.total_amount;
            expenses.find('.btn_delete').on("click",function(e) {
                swal({
                    title: 'Are you sure?',
                    text: "It will permanently deleted !",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result)=>{
                    if(result.value == true) {
                        var id = $(this).data("id");
                        var route = "<?php echo e(route('expense.deleteAjax',':id')); ?>";
                        route = route.replace(":id",id);
                        $.ajax({
                            url:route,
                            type:'GET',
                            dataType:'JSON',
                            complete:function(jqXHR,textStatus) {
                                if(jqXHR.status == 200) {
                                    var result = JSON.parse(jqXHR.responseText);
                                    if(result.hasOwnProperty('success')) {
                                        swal({
                                            type:'success',
                                            title:'Congratulation',
                                            text:'Expense Delete Successfully',
                                        });
                                        $("#expenses").bootgrid('reload');
                                    }
                                } else {
                                    swal({
                                        type:'error',
                                        title:'Opps Something Went Worng',
                                        text:'Contact Admin ',
                                    })
                                }
                            }
                        });
                    }
                })
                
            });
        });
        $("#expenses-header").find('.actionBar').prepend('<button style="margin-left:10px;" id="btnExcel" class="btn btn-primary pull-left btnExcel" type="button"> <span class="icon glyphicon glyphicon-export"></span> Excel </button>');
        $("#expenses-header").find('.actionBar').prepend('<button style="margin-left:10px;" id="btnPrint" class="btn btn-info pull-left btnPrint" type="button"> <span class="icon glyphicon glyphicon-print"></span> Print </button>');
        $("#expenses-header").find('.actionBar').prepend('<button style="margin-left:10px;" id="btnGraph" class="btn btn-success pull-left btnGraph" type="button"> <span class="icon fa fa-bar-chart"></span> Graph </button>');
        $(".btnExcel").on("click",function(e) {
            var table = "<table border='2px'><tr><td>Sr.No</td><td>Date</td><td>Name</td><td>Amount</td><td>Type</td><td>Description</td></tr>";
            expense_response.rows.forEach(function(expense) {
                table += "<tr><td>"+expense.sr_no+"</td><td>"+expense.date+"</td><td>"+expense.name+"</td><td>"+expense.amount+"</td><td>"+expense.type+"</td><td>"+expense.description+"</td></tr>";
            });
            table += "</table>";
            //giving file defualt name
            var postfix = "expensesheet";
            var a = document.createElement('a');
            var dataType = "data:application/vnd.ms-excel";
            a.href = dataType + ',' + encodeURIComponent(table);
            a.download = postfix + '.xls';
            a.click();

            
        });
        $(".btnPrint").on("click",function(e) {
            var result = expense_response.rows;
            localStorage.expense_list = JSON.stringify(result);
            window.open("<?php echo e(route('expense.print')); ?>","_blank");
        });
    });
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>