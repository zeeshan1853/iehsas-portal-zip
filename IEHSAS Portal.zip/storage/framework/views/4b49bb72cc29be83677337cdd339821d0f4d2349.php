<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-content collpase show">
                    <div class="card-body">
                        <form class="form form-horizontal" method="POST" action="<?php echo e(route('teacher.updatePassword')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-body">
                                <h4 class="form-section"><i class="ft-user"></i> Update Password</h4>
                                <div class="form-group row">
                                    <label class="col-md-2 label-control" for="first_name">Old Password :</label>
                                    <div class="col-md-8">
                                        <div class="position-relative has-icon-left">
                                            <input type="password" id="old_password" class="form-control <?php echo e($errors->has('old_password') ? 'is-invalid' : ''); ?>" placeholder="Enter Old Password" name="old_password">
                                            <div class="form-control-position">
                                                <i class="ft-lock"></i>
                                            </div>
                                        </div>
                                        <?php if($errors->has('old_password')): ?>
                                        <span class="text-danger">
                                            <?php echo e($errors->first('old_password')); ?>

                                        </span>
                                        <?php endif; ?>
                                        
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-2 label-control" for="new_password">New Password :</label>
                                    <div class="col-md-8">
                                        <div class="position-relative has-icon-left">
                                            <input type="password" id="new_password" class="form-control  <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" placeholder="Enter New Password" name="password">
                                            <div class="form-control-position">
                                                <i class="ft-lock"></i>
                                            </div>
                                        </div>
                                        <?php if($errors->has('password')): ?>
                                        <span class="text-danger">
                                            <?php echo e($errors->first('password')); ?>

                                        </span>
                                        <?php endif; ?>
                                        

                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-2 label-control" for="new_password">Confirm Password :</label>
                                    <div class="col-md-8">
                                        <div class="position-relative has-icon-left">
                                            <input type="password" id="confirm_password" class="form-control  <?php echo e($errors->has('password_confirmation') ? 'is-invalid' : ''); ?>" placeholder="Retype Password" name="password_confirmation">
                                            <div class="form-control-position">
                                                <i class="ft-lock"></i>
                                            </div>
                                        </div>
                                        

                                    </div>
                                </div>
                            </div>
    
                            <div class="form-actions">
                                <center>
                                    <button type="submit" class="btn btn-primary">Update Password</button>
                                </center>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>