<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('student-portal/app/css/pages/users.min.css')); ?>">
<style>
    .bor{
        border-right:1px solid #CDCDCE;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-6 offset-md-3">
    <div class="card card">
        <div class="text-center">
            <div class="card-body">
                <img src="<?php echo e(asset($student->student_image)); ?>" class="rounded-circle  height-150" alt="Card image">
            </div>
            <div class="card-body">
                <h2 class="text-bold-600"><?php echo e(ucfirst($student->student_name)); ?> <?php echo e(ucfirst($student->father_name)); ?></h4>
            </div>
        </div>
        <div class="list-group list-group-flush text-bold-500 ">
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-user"></i> Student Name</span>
                <span class="col-md-6 offset-md-0"><?php echo e(ucfirst($student->student_name)); ?></span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-user-plus"></i> Father Name</span>
                <span class="col-md-6 offset-md-0"><?php echo e(ucfirst($student->father_name)); ?></span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-phone"></i> Contact No</span>
                <span class="col-md-6 offset-md-0"><?php echo e($student->contact_no); ?></span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-mail"></i> Email</span>
                <span class="col-md-6 offset-md-0"><?php echo e($student->email); ?></span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-calendar"></i> Date Of Brith</span>
                <span class="col-md-6 offset-md-0"><?php echo e($student->date_of_birth->toFormattedDateString()); ?></span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-info"></i> Education</span>
                <span class="col-md-6 offset-md-0"><?php echo e($student->education->name); ?></span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-mail"></i> Gender</span>
                <span class="col-md-6 offset-md-0"><?php echo e(ucfirst($student->gender)); ?></span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor"><i class="ft-smartphone"></i> Emergency Contact No</span>
                <span class="col-md-6 offset-md-0"><?php echo e(ucfirst($student->emergency)); ?></span>
            </li>
            <li class="list-group-item">
                <span class="pull-left col-md-6 col-sm-6 bor">
                    <?php if($student->id_card_front != ""): ?>
                    <a href="<?php echo e(url($student->id_card_front)); ?>" target="_blank"><img src="<?php echo e(asset($student->id_card_front)); ?>" style="width:150px;"></a>
                    <?php endif; ?>
                </span>
                <span class="col-md-6 offset-md-0 col-sm-6">
                    <?php if($student->id_card_back): ?>
                    <a href="<?php echo e(url($student->id_card_back)); ?>" target="_blank"><img src="<?php echo e(asset($student->id_card_back)); ?>" style="width:150px;"></a>
                    <?php endif; ?>
                </span>
            </li>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app_student', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>