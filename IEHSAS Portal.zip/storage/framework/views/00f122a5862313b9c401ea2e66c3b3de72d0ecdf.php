<!DOCTYPE html>
<!--
This Code is Written 
and copyright by TechCodeX
www.techcodex.net
-->
<html class="loading" lang="en" data-textdirection="ltr">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="keywords" content="techcodex, college mangement system, cms, school mangement system,">
    <meta name="description" content="College Mangement System by TechCodex">
    <title><?php echo e($page_title); ?> | <?php echo e(config('app.name')); ?></title>
    <link rel="icon" href="<?php echo e(asset('images/ico/favicon.png')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Muli:300,300i,400,400i,600,600i,700,700i%7CComfortaa:300,400,700" rel="stylesheet">

    <!-- BEGIN VENDOR CSS-->

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/vendors.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/css/forms/toggle/switchery.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/plugins/forms/switch.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/core/colors/palette-switch.min.css')); ?>">
    <!-- END VENDOR CSS-->
    <!-- BEGIN CHAMELEON  CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/app.min.css')); ?>">
    <!-- END CHAMELEON  CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/core/menu/menu-types/vertical-menu.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/core/colors/palette-gradient.min.css')); ?>">
    
    
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/toastr.min.css')); ?>">
    <!-- END Page Level CSS-->
    
    <!-- BEGIN Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
    <!-- END Custom CSS-->
    <!-- Font Awesome -->
    

    <?php echo $__env->yieldContent('header-styles'); ?>
</head>
<body class="vertical-layout vertical-menu 2-columns   menu-expanded fixed-navbar" data-open="click" data-menu="vertical-menu" data-color="bg-gradient-x-purple-blue" data-col="2-columns">

<?php echo $__env->make('common.top_nav_bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- ////////////////////////////////////////////////////////////////////////////-->


<?php echo $__env->make('common.side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-wrapper-before"></div>
        <div class="content-header row">
            <div class="content-header-left col-md-8 col-12 mb-2">
                <h3 class="content-header-title"><?php echo e($page_heading); ?></h3>
            </div>
        </div>
        <div class="content-body"><!-- Revenue, Hit Rate & Deals -->
            <?php echo $__env->yieldContent('main'); ?>
        </div>
    </div>
</div>
<!-- ////////////////////////////////////////////////////////////////////////////-->

<div class="customizer border-left-blue-grey border-left-lighten-4 d-none d-xl-block"><a class="customizer-close" href="#"><i class="ft-x font-medium-3"></i></a><a class="customizer-toggle bg-primary box-shadow-3" href="#" id="customizer-toggle-setting"><i class="ft-settings font-medium-3 spinner white"></i></a><div class="customizer-content p-2">
        <h5 class="mt-1 mb-1 text-bold-500">Navbar Color Options</h5>
        <div class="navbar-color-options clearfix">
            <div class="gradient-colors mb-1 clearfix">
                <div class="bg-gradient-x-purple-blue navbar-color-option" data-bg="bg-gradient-x-purple-blue" title="bg-gradient-x-purple-blue"></div>
                <div class="bg-gradient-x-purple-red navbar-color-option" data-bg="bg-gradient-x-purple-red" title="bg-gradient-x-purple-red"></div>
                <div class="bg-gradient-x-blue-green navbar-color-option" data-bg="bg-gradient-x-blue-green" title="bg-gradient-x-blue-green"></div>
                <div class="bg-gradient-x-orange-yellow navbar-color-option" data-bg="bg-gradient-x-orange-yellow" title="bg-gradient-x-orange-yellow"></div>
                <div class="bg-gradient-x-blue-cyan navbar-color-option" data-bg="bg-gradient-x-blue-cyan" title="bg-gradient-x-blue-cyan"></div>
                <div class="bg-gradient-x-red-pink navbar-color-option" data-bg="bg-gradient-x-red-pink" title="bg-gradient-x-red-pink"></div>
            </div>
            <div class="solid-colors clearfix">
                <div class="bg-primary navbar-color-option" data-bg="bg-primary" title="primary"></div>
                <div class="bg-success navbar-color-option" data-bg="bg-success" title="success"></div>
                <div class="bg-info navbar-color-option" data-bg="bg-info" title="info"></div>
                <div class="bg-warning navbar-color-option" data-bg="bg-warning" title="warning"></div>
                <div class="bg-danger navbar-color-option" data-bg="bg-danger" title="danger"></div>
                <div class="bg-blue navbar-color-option" data-bg="bg-blue" title="blue"></div>
            </div>
        </div>

        <hr>

        <h5 class="my-1 text-bold-500">Layout Options</h5>
        <div class="row">
            <div class="col-12">
                <div class="d-inline-block custom-control custom-radio mb-1 col-4">
                    <input type="radio" class="custom-control-input bg-primary" name="layouts" id="fixed-layout">
                    <label class="custom-control-label" for="fixed-layout">Fixed</label>
                </div>
                <div class="d-inline-block custom-control custom-radio mb-1 col-4">
                    <input type="radio" class="custom-control-input bg-primary" name="layouts" id="static-layout">
                    <label class="custom-control-label" for="static-layout">Static</label>
                </div>
                <div class="d-inline-block custom-control custom-radio mb-1">
                    <input type="radio" class="custom-control-input bg-primary" name="layouts" id="boxed-layout">
                    <label class="custom-control-label" for="boxed-layout">Boxed</label>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="d-inline-block custom-control custom-checkbox mb-1">
                    <input type="checkbox" class="custom-control-input bg-primary" name="right-side-icons" id="right-side-icons">
                    <label class="custom-control-label" for="right-side-icons">Right Side Icons</label>
                </div>
            </div>
        </div>

        <hr>

        <h5 class="mt-1 mb-1 text-bold-500">Sidebar menu Background</h5>
        <!-- <div class="sidebar-color-options clearfix">
            <div class="bg-black sidebar-color-option" data-sidebar="menu-dark" title="black"></div>
            <div class="bg-white sidebar-color-option" data-sidebar="menu-light" title="white"></div>
        </div> -->
        <div class="row sidebar-color-options ml-1">
            <label for="sidebar-color-option" class="card-title font-medium-2 mr-2">White Mode</label>
            <div class="text-center mb-1">
                <input type="checkbox" id="sidebar-color-option" class="switchery" data-size="xs"/>
            </div>
            <label for="sidebar-color-option" class="card-title font-medium-2 ml-2">Dark Mode</label>
        </div>

        <hr>

        <label for="collapsed-sidebar" class="font-medium-2">Menu Collapse</label>
        <div class="float-right">
            <input type="checkbox" id="collapsed-sidebar" class="switchery" data-size="xs"/>
        </div>

        <hr>

        <!--Sidebar Background Image Starts-->
        <h5 class="mt-1 mb-1 text-bold-500">Sidebar Background Image</h5>
        <div class="cz-bg-image row">
            <div class="col mb-3">
                <img src="<?php echo e(asset('images/backgrounds/04.jpg')); ?>" class="rounded sidiebar-bg-img" width="50" height="100" alt="background image">
            </div>
            <div class="col mb-3">
                <img src="<?php echo e(asset('images/backgrounds/01.jpg')); ?>" class="rounded sidiebar-bg-img" width="50" height="100" alt="background image">
            </div>
            <div class="col mb-3">
                <img src="<?php echo e(asset('images/backgrounds/02.jpg')); ?>" class="rounded sidiebar-bg-img" width="50" height="100" alt="background image">
            </div>
            <div class="col mb-3">
                <img src="<?php echo e(asset('images/backgrounds/05.jpg')); ?>" class="rounded sidiebar-bg-img" width="50" height="100" alt="background image">
            </div>
        </div>
        <!--Sidebar Background Image Ends-->

        <!--Sidebar BG Image Toggle Starts-->
        <div class="sidebar-image-visibility">
            <div class="row ml-1">
                <label for="toggle-sidebar-bg-img" class="card-title font-medium-2 mr-2">Hide Image</label>
                <div class="text-center mb-1">
                    <input type="checkbox" id="toggle-sidebar-bg-img" class="switchery" data-size="xs" checked/>
                </div>
                <label for="toggle-sidebar-bg-img" class="card-title font-medium-2 ml-2">Show Image</label>
            </div>
        </div>
        <!--Sidebar BG Image Toggle Ends-->

        <div class="text-center">
            <button id="twitter" class="btn btn-social-icon btn-twitter sharrre mr-1"><i class="la la-twitter"></i></button>
            <button id="facebook" class="btn btn-social-icon btn-facebook sharrre mr-1"><i class="la la-facebook"></i></button>
            <button id="google" class="btn btn-social-icon btn-google sharrre"><i class="la la-google"></i></button>
        </div>
    </div>
</div>

<footer class="footer footer-static footer-light navbar-border navbar-shadow">
    <div class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2">
        <span class="float-md-left d-block d-md-inline-block">2020  &copy; Copyright <a class="text-bold-800 grey darken-2" href="https://www.iehsas.com" target="_blank">IEHSAS</a></span>
        <ul class="list-inline float-md-right d-block d-md-inline-blockd-none d-lg-block mb-0">
                &nbsp;&nbsp;
                <li class="list-inline-item"><a class="my-1" href="http://www.techcodex.net" target="_blank"> Develope By TechCodeX</a></li>
                <li class="list-inline-item"><a class="my-1" href="http://www.iehsas.com" target="_blank"> Version 1.0</a></li>

        </ul>
    </div>
</footer>

<!-- BEGIN VENDOR JS-->
<script src="<?php echo e(asset('vendors/js/vendors.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendors/js/forms/toggle/switchery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/scripts/forms/switch.min.js')); ?>" type="text/javascript"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<!-- END PAGE VENDOR JS-->
<!-- BEGIN CHAMELEON  JS-->
<script src="<?php echo e(asset('js/core/app-menu.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/core/app.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/scripts/customizer.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('vendors/js/jquery.sharrre.js')); ?>" type="text/javascript"></script>
<!-- END CHAMELEON  JS-->
<!-- BEGIN PAGE LEVEL JS-->
<script src="<?php echo e(asset('js/scripts/pages/dashboard-analytics.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/toastr.min.js')); ?>" type="text/javascript"></script>

<script> var ajaxLoader = "<img src='<?php echo e(asset('loader.gif')); ?>' style='width:25px !important;'>"; </script>
<!-- END PAGE LEVEL JS-->
<?php echo $__env->yieldContent('footer-scripts'); ?>;
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    toastr.options.closeButton = true;
    toastr.options.closeMethod = 'fadeOut';
    toastr.options.closeDuration = 300;
    toastr.options.closeEasing = 'swing';
    toastr.options.preventDuplicates = true;
    toastr.options.progressBar = true;
    $(document).ready(function (e) {
        <?php if(Auth::user()->admin != 1): ?>
            if(localStorage.getItem("permissions") == null) {
                console.log("request");
                var route = "<?php echo e(route('permissionRole.getUserPermissions')); ?>";
                $.ajax({
                    url:route,
                    dataType:'JSON',
                    type:'GET',
                    beforeSend(xhr) {
                        $(".sidebar-loader").html("<img src='<?php echo e(asset('loader.gif')); ?>' style='width:50px;'>");
                    },
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            var permissions = result.permissions;
                            localStorage.setItem('permissions',JSON.stringify(permissions));
                            $("#main-menu-navigation").append(permissions);
                            $(".sidebar-loader").html("");
                        }
                    }
                });
            } else {
                console.log("Not request");
                $(".sidebar-loader").html("<img src='<?php echo e(asset('loader.gif')); ?>' style='width:50px;'>");
                var permissions = JSON.parse(localStorage.getItem("permissions"));
                $("#main-menu-navigation").append(permissions);
                $(".sidebar-loader").html("");
                
            }

        <?php endif; ?>
        <?php if(Session::has('success')): ?>
            toastr.success("<?php echo e(Session::pull('success')); ?>");
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
        toastr.error("<?php echo e(Session::pull('error')); ?>");
        <?php endif; ?>
        <?php if($errors->any()): ?>
        toastr.error("Check Your Errors");
        <?php endif; ?>
    })
</script>
</body>

</html>