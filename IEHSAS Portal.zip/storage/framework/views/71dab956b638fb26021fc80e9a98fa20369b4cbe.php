<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(asset('vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('courseDocument.store')); ?>">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                            <div class="form-group row">
                                <label class="col-md-2 label-control">Course:</label>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <select class="form-control select2" tabindex="01" autofocus name="course_id" id="courseId">
                                            <option value="">--Select Course--</option>
                                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <?php if($errors->has('course_id')): ?>
                                        <span  class="text-danger"><?php echo e($errors->first('course_id')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-2 label-control">Document:</label>
                                <div class="col-md-8">
                                    <div class="input-group">
                                        <select class="form-control select2" tabindex="02" name="document_id" id="documentId">
                                            <option value="">--Select Document--</option>
                                            <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($document->id); ?>" data-img="<?php echo e(asset($document->document)); ?>"><?php echo e($document->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="input-group-append">
                                            <span class="input-group-text">
                                                <a href="#" id="view"><span class="ft-eye" style="color:green;"></span></a>
                                            </span>
                                        </div>
                                    </div>
                                    <?php if($errors->has('document_id')): ?>
                                        <span  class="text-danger"><?php echo e($errors->first('document_id')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Add Course Document" class="btn btn-primary" tabindex="06">
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script>
        $(document).ready(function(e) {
            $("#courseId").select2();
            $("#documentId").select2();
            $("#view").click(function(e) {
                var img = $("#documentId").select2().find(":selected").data("img");
                if(img == "" || img == undefined) {
                    return;
                }
                myWindow = window.open(img);
                
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>