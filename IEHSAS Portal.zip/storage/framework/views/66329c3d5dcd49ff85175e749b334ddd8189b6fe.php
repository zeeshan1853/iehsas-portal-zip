<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-content collpase show">
                <div class="card-body">
                    <form class="form form-horizontal" method="POST" action="<?php echo e(route('complain.store')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-body">
                            <h4 class="form-section"><i class="fa fa-envelope"></i> Complain / Suggestion Form</h4>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="document">Course Name :</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <select class="form-control" name="course_id">
                                            <option value=""> --Select Course --</option>
                                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="form-control-position">
                                            <i class="fa fa-list"></i>
                                        </div>
                                    </div>
                                    <?php if($errors->has('course_id')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('course_id')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-2 label-control" for="document">Complain / Suggestion :</label>
                                <div class="col-md-8">
                                    <div class="position-relative has-icon-left">
                                        <textarea class="form-control" name="complain" placeholder="Enter Complain / Suggestion" rows="10"></textarea>
                                        <div class="form-control-position">
                                            <i class="fa fa-exclamation-circle"></i>
                                        </div>
                                    </div>
                                    <?php if($errors->has('complain')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('complain')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-actions">
                            <center>
                                <button type="submit" class="btn btn-primary" id="upload">Submit</button>
                            </center>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_student', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>