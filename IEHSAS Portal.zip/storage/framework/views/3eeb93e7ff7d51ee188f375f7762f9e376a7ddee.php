<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="dom">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('quizResult.store')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="quiz_id" value="<?php echo e($quiz->id); ?>">
                            <table class="table table-striped">
                                <thead class="bg-info text-white text-white">
                                    <tr>
                                        <td>Sr.No</td>
                                        <td>Name</td>
                                        <td>Obtain Marks</td>
                                        <td>Remakrs</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $student_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($student->student->student_name); ?> <?php echo e($student->student->father_name); ?></td>
                                            <td>
                                                <input type="integer" name="marks[<?php echo e($student->id); ?>]" class="form-control" min="0" placeholder="Enter Obtain Marks" value="0">
                                            </td>
                                            <td>
                                                <textarea name="remarks[<?php echo e($student->id); ?>]" class="form-control" cols="15" rows="5" placeholder="Enter Remakrs"></textarea>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="4" class="text-center">
                                            <input type="submit" class="btn btn-primary" value="Store">
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </form>
                    </div>
                </div>
            </div>
        </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>