

<?php $__env->startSection('header-styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('bank.store')); ?>" id="instalmentForm">
                    <?php echo csrf_field(); ?>
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Bank Name</label>
                                    <div class="col-md-9">
                                        <input type="text" autofocus placeholder="Enter Bank Name" class="form-control" name="name">
                                    </div>
                                    <?php if($errors->has('name')): ?>
                                    <span class="offset-md-4 text-danger">
                                        <?php echo e($errors->first('name')); ?>

                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Account No</label>
                                    <div class="col-md-9">
                                        <input type="text" placeholder="Enter Account No" class="form-control" name="account_no">
                                    </div>
                                    <?php if($errors->has('account_no')): ?>
                                    <span class="offset-md-4 text-danger">
                                        <?php echo e($errors->first('account_no')); ?>

                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Bank Branch Name</label>
                                    <div class="col-md-9">
                                        <input type="text" placeholder="Enter Bank Branch Name" class="form-control" name="bank_branch">
                                    </div>
                                    <?php if($errors->has('bank_branch')): ?>
                                    <span class="offset-md-4 text-danger">
                                        <?php echo e($errors->first('bank_branch')); ?>

                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Opening</label>
                                    <div class="col-md-9">
                                        <input type="number" min="0" value="0" placeholder="Enter Opening Amont" class="form-control" name="opening">
                                    </div>
                                    <?php if($errors->has('opening')): ?>
                                    <span class="offset-md-4 text-danger">
                                        <?php echo e($errors->first('opening')); ?>

                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                    </div>

                    <div class="form-actions ">
                        <input type="submit" value="Add" id="btnAdd" class="btn btn-primary offset-md-5">
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>