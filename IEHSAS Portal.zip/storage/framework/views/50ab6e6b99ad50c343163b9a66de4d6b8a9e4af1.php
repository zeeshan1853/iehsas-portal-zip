<?php $__env->startSection('header-styles'); ?>
    <link href="<?php echo e(asset('vendors/css/tables/datatable/datatables.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <table class="table table-bordered text-center" id="studentsData">
                    <thead>
                    <tr class="bg-blue " style="color:white;">
                        <td data-column-id="sr_no">Sr.No</td>
                        <td data-column-id="name">Name</td>
                        <td data-column-id="paid">Paid Amount</td>
                        <td data-column-id="Payment_type">Payment Type</td>
                        <td data-column-id="created_at">Date</td>
                        <td data-column-id="actions" data-sortable="false">Actions</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $i = 1;
                    ?>
                    <?php $__currentLoopData = $instalments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instalment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($instalment->student->student_name); ?></td>
                            <td><?php echo e($instalment->paid_amount); ?></td>
                            <td><?php echo e($instalment->payment->name); ?></td>
                            <td><?php echo e($instalment->created_at->toFormattedDateString()); ?></td>
                            <td><a href="<?php echo e(route('instalment.edit',['id'=>$instalment->id])); ?>" class="ft-edit"></a><a href="<?php echo e(route('instalment.destroy',['id'=>$instalment->id])); ?>" class="ft-trash" style="color:red; margin-left:10px;"></a><a href="#" class="ft-printer print" style="color:green;margin-left: 10px;" data-id="<?php echo e($instalment->id); ?>"></a> </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
    <script src="<?php echo e(asset('vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/tables/datatables/datatable-styling.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/tables/datatables/datatable-basic.min.js')); ?>"></script>
    <script>
        $(document).ready(function(e) {
            $("#studentsData").DataTable();
            $(".print").click(function(e) {
                var id = $(this).attr("data-id");
                var route = "<?php echo e(route('instalment.printInstalment','id')); ?>";
                route = route.replace('id',id);
                $.ajax({
                    url:route,
                    dataType:'JSON',
                    type:'GET',
                    complete:function(jqXHR,textStatus) {
                        if(jqXHR.status == 200) {
                            var result = JSON.parse(jqXHR.responseText);
                            if(result.hasOwnProperty('success')) {
                                localStorage.instalments = JSON.stringify(result.instalments);
                                window.open("<?php echo e(route('instalment.print')); ?>","_blank");
                            } else {
                                toastr.error("Opps Something Went Wrong");
                            }
                        }
                    }
                })
                   
            })
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>