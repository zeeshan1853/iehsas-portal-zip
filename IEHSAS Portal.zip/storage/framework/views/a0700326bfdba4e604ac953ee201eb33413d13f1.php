

<?php $__env->startSection('header-styles'); ?>
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('email.store')); ?>" id="instalmentForm">
                    <?php echo csrf_field(); ?>
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                        <div class="row">
                            <div class="col-md-6 offset-md-2">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">This Mail For ?</label>
                                    <div class="col-md-9">
                                        <input type="text" autofocus placeholder="Enter What this Mail is For ?" class="form-control" name="for">
                                    </div>
                                    <?php if($errors->has('for')): ?>
                                    <span class="offset-md-4 text-danger">
                                        <?php echo e($errors->first('for')); ?>

                                    </span>
                                    <?php endif; ?>
                                    
                                </div>

                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group row">
                                    <label class="col-md-1 label-control" for="mail_draft">Mail Draft</label>
                                    <div class="col-md-11">
                                        <textarea id="editor" name="content"></textarea>
                                    </div>
                                    <span class="text-danger offset-md-4">
                                        <?php if($errors->has('content')): ?>
                                            <?php echo e($errors->first('content')); ?>

                                        <?php endif; ?>
                                    </span>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="form-actions ">
                        <input type="submit" value="Add" id="btnAdd" class="btn btn-primary offset-md-5">
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-scripts'); ?>
<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.js"></script>
<script>
    $(document).ready(function(e) {
        $("#editor").summernote({
            height:300,
        });
    })
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>