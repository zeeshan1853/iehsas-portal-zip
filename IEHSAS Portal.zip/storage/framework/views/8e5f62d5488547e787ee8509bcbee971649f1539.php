<?php $__env->startSection('header-styles'); ?>
<link href="<?php echo e(asset('vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="row">
        <div class="card col-md-12">
            <div class="card-body">
                <form class="form form-horizontal" method="post" action="<?php echo e(route('agentPayment.store')); ?>" enctype="multipart/form-data" data-tabgroup>
                    <?php echo csrf_field(); ?>
                    <div class="form-body">
                        <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                        <div class="row">
                            <div class="col-md-10">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput1">Agent</label>
                                    <div class="col-md-9">
                                        <div class="input-group col-md-12">
                                            <select id="agent_id" name="agent_id" class="form-control select2" tabindex="01">
                                                <option value="">--Select Agent--</option>
                                                <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                                                    <option data-dueAmount="<?php echo e($agent->credit - $agent->debit); ?>" value="<?php echo e($agent->id); ?>" <?php echo e(old('agent_id') == $agent->id ? 'selected' : ''); ?>><?php echo e($agent->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <div class="input-group-append">
                                                <span class="input-group-text due_amount">000000</span>
                                            </div>
                                        </div>
                                        <?php if($errors->has('agent_id')): ?>
                                            <span class=" text-danger"><?php echo e($errors->first('agent_id')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-10">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Narration</label>
                                    <div class="col-md-9">
                                        <textarea class="form-control" rows="5" placeholder="Enter Narration" name="narration" tabindex="02"><?php echo e(old('narration')); ?></textarea>
                                        <?php if($errors->has('narration')): ?>
                                            <span class="text-danger contact_no">
                                                <?php echo e($errors->first('narration')); ?>

                                            </span>
                                        <?php endif; ?>  
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-10">
                                <div class="form-group row">
                                    <label class="col-md-3 label-control" for="userinput4">Paid Amount</label>
                                    <div class="col-md-9">
                                        <input type="number" min="0" id="amount" class="form-control <?php echo e($errors->has('amount') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('amount')); ?>" name="amount" tabindex="03" placeholder="Enter Paid Amount">
                                        <?php if($errors->has('amount')): ?>
                                            <span class="text-danger contact_no">
                                                <?php echo e($errors->first('amount')); ?>

                                            </span>
                                        <?php endif; ?>  
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="form-actions text-center">
                        <input type="submit" value="Save" id="btnAdd" class="btn btn-primary" tabindex="04">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
<script>
    var dueAmount = 0;
    $(document).on('focus','.select2',function (e) {
        $(this).siblings('select').select2('open');
    });
    $(document).ready((e)=>{
        $("#agent_id").select2();
        $("#agent_id").focus();
        $("#agent_id").change((e) => {
            dueAmount = $("#agent_id > option:selected").attr("data-dueAmount");
            $(".due_amount").text(dueAmount);
        });
        $("#amount").keydown((e) =>{
            if($("#agent_id").val() == 0 || $("#agent_id").val() == "") {
                toastr.error("Missing Agent");
                return ;
            }
            var amount = $("#amount").val();
            if(parseInt(amount) > parseInt(dueAmount)) {
                $("#btnAdd").attr("disabled",true);
                toastr.error("Paid Amount Must be Less then Due Amount");
            } else {
                $("#btnAdd").attr("disabled",false);
            }
        });

    });
    var tabgroups = document.querySelectorAll("[data-tabgroup]");
    //        console.log(tabgroups);
    // Loop through each to attach thse listeners we need
    for (var i = 0; i < tabgroups.length; i++) {
        var inputs = tabgroups[i].querySelectorAll("[tabindex]");
//            alert(inputs);
        // Loop through all of the elements we want the tab to be changed for
        for (var j = 0; j < inputs.length; j++) {

            // Listen for the tab pressed on these elements
            inputs[j].addEventListener("keydown", function(myIndex, inputs, e) {
                if (e.key === "Tab") {
                    // Prevent the default tab behavior
                    e.preventDefault();

                    // Focus the next one in the group
                    if (inputs[myIndex + 1]) {
                        inputs[myIndex + 1].focus();
                    } else { // Or focus the first one again
                        inputs[0].focus();
                    }
                }
            }.bind(null, j, inputs)) // Make a copy of the variables to use in the addEventListener
        }
    }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>