

<?php $__env->startSection('header-styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="row">
    <div class="card col-md-12">
        <div class="card-body">
            <section id="minimal-statistics-bg">
                
                <div class="row">
                    <div class="col-xl-3 col-lg-6 col-12">
                        <div class="card bg-gradient-directional-warning">
                            <div class="card-content">
                                <div class="card-body">
                                    <div class="media d-flex">
                                        <div class="media-body text-white text-left align-self-bottom mt-3">
                                            <span class="d-block mb-1 font-medium-1">Total Students</span>
                                            <h1 class="text-white mb-0"><?php echo e($students); ?></h1>
                                        </div>
                                        <div class="align-self-top">
                                            <i class="ft-life-buoy icon-opacity text-white font-large-4 float-right"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-12">
                        <div class="card bg-gradient-directional-success">
                            <div class="card-content">
                                <div class="card-body">
                                    <div class="media d-flex">
                                        <div class="media-body text-white text-left align-self-bottom mt-3">
                                            <span class="d-block mb-1 font-medium-1">Due Amount</span>
                                            <h1 class="text-white mb-0"><?php echo e($due_amount); ?></h1>
                                        </div>
                                        <div class="align-self-top">
                                            <i class="ft-arrow-down-left icon-opacity text-white font-large-4 float-right"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            
                    <div class="col-xl-3 col-lg-6 col-12">
                        <div class="card bg-gradient-directional-danger">
                            <div class="card-content">
                                <div class="card-body">
                                    <div class="media d-flex">
                                        <div class="media-body text-white text-left align-self-bottom mt-3">
                                            <span class="d-block mb-1 font-medium-1">Received Amount</span>
                                            <h1 class="text-white mb-0"><?php echo e($paid_amount); ?></h1>
                                        </div>
                                        <div class="align-self-top">
                                            <i class="ft-arrow-up-right icon-opacity text-white font-large-4 float-right"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-6 col-12">
                        <div class="card bg-gradient-directional-info">
                            <div class="card-content">
                                <div class="card-body">
                                    <div class="media d-flex">
                                        <div class="media-body text-white text-left align-self-bottom mt-3">
                                            <span class="d-block mb-1 font-medium-1">New Enrolments</span>
                                            <h1 class="text-white mb-0"><?php echo e($new); ?></h1>
                                        </div>
                                        <div class="align-self-top">
                                            <i class="ft-airplay icon-opacity text-white font-large-4 float-right"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                        <?php if(Auth::user()->branch->branch == 1): ?>
                            <div class="col-xl-3 col-lg-6 col-12">
                                <div class="card bg-gradient-x-purple-blue">
                                    <div class="card-content">
                                        <div class="card-body">
                                            <div class="media d-flex">
                                                <div class="align-self-top">
                                                    <i class="ft-monitor icon-opacity text-white font-large-4 float-left"></i>
                                                </div>
                                                <div class="media-body text-white text-right align-self-bottom mt-3">
                                                    <span class="d-block mb-1 font-medium-1">Total Branches</span>
                                                    <h1 class="text-white mb-0"><?php echo e($branches); ?></h1>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if(Auth::user()->branch->branch == 1): ?>
                        <div class="col-xl-3 col-lg-6 col-12">
                            <div class="card bg-gradient-x-purple-red">
                                <div class="card-content">
                                    <div class="card-body">
                                        <div class="media d-flex">
                                            <div class="align-self-top">
                                                <i class="ft-user-check icon-opacity text-white font-large-4 float-left"></i>
                                            </div>
                                            <div class="media-body text-white text-right align-self-bottom mt-3">
                                                <span class="d-block mb-1 font-medium-1">Total Teachers</span>
                                                <h1 class="text-white mb-0"><?php echo e($teachers); ?></h1>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="col-xl-3 col-lg-6 col-12">
                            <div class="card bg-gradient-x-blue-green">
                                <div class="card-content">
                                    <div class="card-body">
                                        <div class="media d-flex">
                                            <div class="align-self-top">
                                                <i class="ft-book icon-opacity text-white font-large-4 float-left"></i>
                                            </div>
                                            <div class="media-body text-white text-right align-self-bottom mt-3">
                                                <span class="d-block mb-1 font-medium-1">Total Courses</span>
                                                <h1 class="text-white mb-0"><?php echo e($courses); ?></h1>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-6 col-12">
                            <div class="card bg-gradient-x-orange-yellow">
                                <div class="card-content">
                                    <div class="card-body">
                                        <div class="media d-flex">
                                            <div class="align-self-top">
                                                <i class="ft-clipboard icon-opacity text-white font-large-4 float-left"></i>
                                            </div>
                                            <div class="media-body text-white text-right align-self-bottom mt-3">
                                                <span class="d-block mb-1 font-medium-1">Total Batches</span>
                                                <h1 class="text-white mb-0"><?php echo e($batches); ?></h1>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </section>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>