


<?php $__env->startSection('styles'); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-3 col-lg-6 col-12">
        <a href="<?php echo e(route('teacher.activeBatch')); ?>">
            <div class="card bg-info">
                <div class="card-content">
                    <div class="card-body">
                        <div class="media d-flex">
                            <div class="align-self-center">
                                <i class="fa fa-bar-chart text-white font-large-2 float-left"></i>
                            </div>
                            <div class="media-body text-white text-right">
                                <h3 class="text-white"><?php echo e($active); ?></h3>
                                <span>Active Batches</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-xl-3 col-lg-6 col-12">
        <a href="<?php echo e(route('teacher.oldBatches')); ?>">
            <div class="card bg-danger">
                <div class="card-content">
                    <div class="card-body">
                        <div class="media d-flex">
                            <div class="align-self-center">
                                <i class="fa fa-chain text-white font-large-2 float-left"></i>
                            </div>
                            <div class="media-body text-white text-right">
                                <h3 class="text-white"><?php echo e($old); ?></h3>
                                <span>Old Batches</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-xl-3 col-lg-6 col-12">
        <div class="card bg-success">
            <div class="card-content">
                <div class="card-body">
                    <div class="media d-flex">
                        <div class="align-self-center">
                            <i class="fa fa-graduation-cap text-white font-large-2 float-left"></i>
                        </div>
                        <div class="media-body text-white text-right">
                            <h3 class="text-white"><?php echo e($students); ?></h3>
                            <span>Students Teached</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-12">
        <a href="<?php echo e(route('teacher.profile')); ?>">
            <div class="card bg-warning">
                <div class="card-content">
                    <div class="card-body">
                        <div class="media d-flex">
                            <div class="align-self-center">
                                <i class="fa fa-certificate text-white font-large-2 float-left"></i>
                            </div>
                            <div class="media-body text-white text-right">
                                <h3 class="text-white"><?php echo e($rating); ?></h3>
                                <span>Rating</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>