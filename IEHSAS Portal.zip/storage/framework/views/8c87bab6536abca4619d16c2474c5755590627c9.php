<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('student-portal/app/css/core/colors/palette-callout.min.css')); ?>">
<style>
    .form-section {
        color: #1D2B36;
        line-height: 3rem;
        margin-bottom: 20px;
        border-bottom: 1px solid #1D2B36;
    }
</style>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                    <h4 class="form-section"><i class="ft-alert-circle"></i> New Notifications</h4>
                    <?php if($notifications->count() == 0): ?>
                    <div class="bs-callout-danger callout-transparent callout-bordered mt-1">
                        <div class="media align-items-stretch">
                            <div class="media-left media-middle bg-danger position-relative callout-arrow-left p-2">
                                <i class="icon-close white font-medium-5"></i>
                            </div>
                            <div class="media-body p-1">
                                <strong>No New Notification To Read!</strong>
                            </div>
                        </div>
                    </div>
                    <?php else: ?> 
                        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($notification['data']['url']); ?>">
                            <div class="bs-callout-success callout-transparent callout-bordered mt-1">
                                <div class="media align-items-stretch">
                                    <div class="media-left d-flex align-items-center bg-success position-relative callout-arrow-left p-2">
                                        <i class="<?php echo e($notification['data']['icon']); ?> white font-medium-5"></i>
                                    </div>
                                    <div class="media-body p-1">
                                        <strong><?php echo e($notification['data']['heading']); ?>!</strong>
                                        <div class="row">
                                            <p class="col-md-10"><?php echo e($notification['data']['message']); ?></p>
                                            <p class="col-md-2 text-right ">
                                                <span class="ft-clock text-bold-600"> <?php echo e($notification->created_at->diffForHumans()); ?></span>
                                            </p>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>

                        </a>
                            <?php echo e($notification->markAsRead()); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                    <h4 class="form-section "><i class="ft-check-circle"></i> Read Notifications</h4>
                    <?php if($read_notifications->count() == 0): ?>
                    <div class="bs-callout-danger callout-transparent callout-bordered mt-1">
                        <div class="media align-items-stretch">
                            <div class="media-left media-middle bg-danger position-relative callout-arrow-left p-2">
                                <i class="icon-close white font-medium-5"></i>
                            </div>
                            <div class="media-body p-1">
                                <strong>No Read Notification To Show!</strong>
                            </div>
                        </div>
                    </div>
                    <?php else: ?> 
                        <?php $__currentLoopData = $read_notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($notification['data']['url']); ?>">
                            <div class="bs-callout-success callout-transparent callout-bordered mt-1">
                                <div class="media align-items-stretch">
                                    <div class="media-left d-flex align-items-center bg-success position-relative callout-arrow-left p-2">
                                        <i class="<?php echo e($notification['data']['icon']); ?> white font-medium-5"></i>
                                    </div>
                                    <div class="media-body p-1">
                                        <strong><?php echo e($notification['data']['heading']); ?>!</strong>
                                        <p><?php echo e($notification['data']['message']); ?></p>
                                        <hr>
                                        <p>
                                            <span class="read_at pull-left">
                                                <i class="ft-check-circle text-bold-600"> <?php echo e($notification->read_at->diffForHumans()); ?></i>
                                            </span>
                                            <span class="read_at pull-right">
                                                <i class="ft-clock text-bold-600"> <?php echo e($notification->created_at->diffForHumans()); ?></i>
                                            </span>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app_student', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>