<?php $__env->startSection('header-styles'); ?>
<link href="<?php echo e(asset('vendors/css/forms/selects/select2.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="row">
    <div class="card col-md-12">
        <div class="card-body">
            <form class="form form-horizontal" method="post" action="<?php echo e(route('document.store')); ?>" id="instalmentForm"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-body">
                    <h4 class="form-section"><i class="ft-info"></i> <?php echo e($page_heading); ?></h4>
                    <div class="row">
                        <div class="col-md-6 offset-md-2">
                            <div class="form-group row">
                                <label class="col-md-3 label-control" for="userinput1">Course:</label>
                                <div class="col-md-9">
                                    <div class="input-group">
                                        <select class="form-control" name="course_id" id="course_id">
                                            <option value="">--Select Course --</option>
                                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="input-group-append">
                                            <span class="input-group-text">
                                                <a href="#" id="addDocumentType"><i class="ft-plus-circle"></i></a>
                                            </span>
                                        </div>
                                    </div>
                                    <?php if($errors->has('document_type_id')): ?>
                                    <span class="text-danger">
                                        <?php echo e($errors->first('document_type_id')); ?>

                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 offset-md-2">
                            <div class="form-group row">
                                <label class="col-md-3 label-control" for="userinput1">Document Type:</label>
                                <div class="col-md-9">
                                    <div class="input-group">
                                        <select class="form-control" name="document_type_id" id="documentTypeId">
                                            <option value="">--Select Document Type--</option>
                                            
                                        </select>
                                        <div class="input-group-append">
                                            <span class="input-group-text">
                                                <a href="#" id="addDocumentType"><i class="ft-plus-circle"></i></a>
                                            </span>
                                        </div>
                                    </div>
                                    <?php if($errors->has('document_type_id')): ?>
                                    <span class="text-danger">
                                        <?php echo e($errors->first('document_type_id')); ?>

                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 offset-md-2">
                            <div class="form-group row">
                                <label class="col-md-3 label-control" for="userinput1">Docoument Name</label>
                                <div class="col-md-9">
                                    <input type="text" value="<?php echo e(old('name')); ?>"
                                        placeholder="Enter Document Name"
                                        class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" name="name">
                                    <?php if($errors->has('name')): ?>
                                    <span class="text-danger">
                                        <?php echo e($errors->first('name')); ?>

                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 offset-md-2">
                            <div class="form-group row">
                                <label class="col-md-3 label-control" for="userinput1">Docoument File</label>
                                <div class="col-md-9">
                                    <input type="file"
                                        class="form-control <?php echo e($errors->has('document') ? 'is-invalid' : ''); ?>"
                                        name="document">
                                    <?php if($errors->has('document')): ?>
                                    <span class="text-danger">
                                        <?php echo e($errors->first('document')); ?>

                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-actions ">
                    <input type="submit" value="Add" id="btnAdd" class="btn btn-primary offset-md-5">
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
<script>
    $(document).ready(function(e) {
        $("#course_id").select2();
        $("#documentTypeId").select2();
        //gte course document types
        $("#course_id").change(function(e) {
            var id = $(this).val();
            var route = "<?php echo e(route('course.documentTypesAjax',':id')); ?>";
            var route = route.replace(":id",id);
            $.ajax({
                url:route,
                dataType:'JSON',
                type:'GET',
                complete:function(jqXHR,textSatus) {
                    if(jqXHR.status == 200) {
                        var result = JSON.parse(jqXHR.responseText);
                        var types = result.types;
                        var output = "";
                        types.forEach(function(type) {
                            output += "<option value='"+type.id+"'>"+type.name+"</option>";
                        });
                        $("#documentTypeId > option ~ option").remove();
                        $("#documentTypeId").append(output);
                    }
                }
            })
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>