<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('student-portal/app/css/pages/chat-application.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="app" class="app-content">
    <student-chat-app :asset="'<?php echo e(asset('/')); ?>'" :batch="<?php echo e($batch); ?>" :path="'<?php echo e(url('/student')); ?>'" 
    :teacher="<?php echo e($teacher); ?>" :student="<?php echo e($student); ?>"></student-chat-app>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.student_chat', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>