<?php $__env->startSection('styles'); ?>
<style>
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-lg-12 col-md-12 col-xl-12">
    <div id="accordionWrap2" role="tablist" aria-multiselectable="true">
        <div class="card-header text-bold-700 text-center bg-info text-white" style="font-size:22px;padding:10px;">
          <?php echo e($course->course_name); ?> Documents
        </div>
        <div class="card collapse-icon accordion-icon-rotate left" style="height: auto;">
            <?php if($types->count() == 0): ?>
            <h3 class="text-danger mt-2 text-center">No Document Found</h3>
            <?php else: ?>
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filed=>$type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="heading<?php echo e($filed+1); ?>" class="card-header type">
                <a data-toggle="collapse" data-parent="#accordionWrap2" href="#accordion<?php echo e($filed+1); ?>" aria-expanded="false"
                    aria-controls="accordion<?php echo e($filed+1); ?>" class="collapsed " style="font-size:20px;">
                     &nbsp;<?php echo e($type->name); ?> <span class="fa fa-book"></span>
                </a>
            </div>
            <div id="accordion<?php echo e($filed+1); ?>" role="tabpanel" aria-labelledby="heading<?php echo e($filed+1); ?>" class="collapse" style="">
                <div class="card-content">
                    <div class="card-body" style="font-size:15px;">
                        <table class="table table-striped">
                            <thead class="bg-info">
                                <tr>
                                    <th>Sr.No</th>
                                    <th>Document</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($type->documents->count() == 0): ?>
                                    <tr>
                                        <td colspan="3" class="text-center">No Document Found</td>
                                    </tr>
                                <?php else: ?>
                                    <?php $i = 1; ?>
                                    <?php $__currentLoopData = $type->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($document->name); ?></td>
                                            <td>
                                                <a href="<?php echo e(asset($document->document)); ?>" title="Click to Download" class="btn btn-sm btn-info">Download <i class="fa fa-download"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_student', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>