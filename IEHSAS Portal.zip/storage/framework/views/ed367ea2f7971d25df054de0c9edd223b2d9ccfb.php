


<?php $__env->startSection('header-styles'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-8 offset-md-2">
            <div class="card-body">
                <form method="post" action="<?php echo e(route('cash_account.update',['id'=>$cash->id])); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label><h5 class="mt-2">Opening:</h5></label>
                    <input type="text" name="opening" class="form-control" disabled id="opening" value="<?php echo e($cash->opening); ?>">
                    </div>
                    <div class="form-group">
                        <label><h5 class="mt-2">Debit:</h5></label>
                    <input type="text" name="debit" class="form-control" id="debit" disabled value="<?php echo e($cash->debit); ?>">
                    </div>
                    <div class="form-group">
                        <label><h5 class="mt-2">Credit:</h5></label>
                    <input type="text" name="credit" class="form-control" id="credit" disabled value="<?php echo e($cash->credit); ?>">
                    </div>
                    <div class="form-group">
                        <label><h5 class="mt-2">Deposit Money:</h5></label>
                        <input type="text" name="deposit" value="0" class="form-control <?php echo e($errors->has('deposit') ? 'is-invalid' : ''); ?>" id="deposit" placeholder="Enter Deposit Amount" <?php if(old('deposit')): ?>value="<?php echo e(old('deposit')); ?>" <?php endif; ?>>
                        <span class="text-danger">
                            <?php if($errors->has('deposit')): ?>
                                <?php echo e($errors->first('deposit')); ?>

                            <?php endif; ?>
                        </span>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary offset-md-5 col-md-2" >
                            Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>