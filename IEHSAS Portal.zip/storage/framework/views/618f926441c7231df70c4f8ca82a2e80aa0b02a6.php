


<?php $__env->startSection('header-styles'); ?>
<link href="<?php echo e(asset('css/jasny-bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="row">
        <div class="card col-md-8 offset-md-2">
            <div class="card-body">
                <form method="post" action="<?php echo e(route('user.save_user')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label><h5 class="mt-2">User Name:</h5></label>
                        <input type="text" name="name" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" id="basicInput" placeholder="User Name" value="<?php echo e(old('name')); ?>">
                        <span class="text-danger">
                            <?php if($errors->has('name')): ?>
                                <?php echo e($errors->first('name')); ?>

                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="form-group">
                        <label><h5 class="mt-2">Email:</h5></label>
                        <input type="text" name="email" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" id="basicInput" placeholder="Email" value="<?php echo e(old('email')); ?>">
                        <span class="text-danger">
                            <?php if($errors->has('email')): ?>
                                <?php echo e($errors->first('email')); ?>

                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="form-group">
                        <label><h5 class="mt-2">Password:</h5></label>
                        <input type="password" name="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" id="basicInput" placeholder="Password">
                        <span class="text-danger">
                            <?php if($errors->has('password')): ?>
                                <?php echo e($errors->first('password')); ?>

                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="form-group">
                        <label><h5 class="mt-2">Confirm Password:</h5></label>
                        <input type="password" name="password_confirmation" class="form-control " id="basicInput" placeholder="Confirm Password">
                        <span class="text-danger"></span>
                    </div>

                    <div class="form-group">
                        <label><h5 class="mt-2">Select Branch:</h5></label>
                        <select class="form-control <?php if($errors->has('branch_id')): ?> is-invalid <?php endif; ?>" name="branch_id" >
                            <option value="">--Select Branch--</option>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('branch_id')): ?>
                            <span class="text-danger"><?php echo e($errors->first('branch_id')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label><h5 class="mt-2">Select Role:</h5></label>
                        <select class="form-control <?php if($errors->has('role_id')): ?> is-invalid <?php endif; ?>" name="role_id" >
                            <option value="">--Select Role--</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('branch_id')): ?>
                            <span class="text-danger"><?php echo e($errors->first('branch_id')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label>
                            <h5 class="mt-2">Image:</h5>
                        </label>
                        <!-- Student Image-->
                        <div class="form-group">
                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                <div class="fileinput-preview img-thumbnail" data-trigger="fileinput"
                                    style="width: 300px; height: 200px;">
                                </div>
                                <div>
                                    <span class="btn btn-outline-secondary btn-file">
                                        <span class="fileinput-new">Select image</span>
                                        <span class="fileinput-exists">Change</span>
                                        <input type="file" name="image">
                                    </span>
                                    <a href="#" class="btn btn-outline-secondary fileinput-exists"
                                        data-dismiss="fileinput">Remove</a>
                                </div>
                            </div>
                        </div>
                        <?php if($errors->has('image')): ?>
                        <span class="text-danger offset-md-3"><?php echo e($errors->first('image')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary offset-md-4 col-md-4" >
                            Add User
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
<script src="<?php echo e(asset('js/jasny-bootstrap.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>